import.meta.env = {"VITE_apiKey":"AIzaSyDRyDZKvLHOsjdItTsl6IEqsGcFqtJ4KQo","VITE_authDomain":"pretpark-929b6.firebaseapp.com","VITE_projectId":"pretpark-929b6","VITE_storageBucket":"pretpark-929b6.appspot.com","VITE_messagingSenderId":"69976698416","VITE_appId":"1:69976698416:web:d23a0a7b80c81b6d4c07f5","VITE_measurementId":"G-2GQTGNKRSS","VITE_BACKEND_URL":"http://[::1]:3000/graphql","VITE_EMULATION":"true ","BASE_URL":"/","MODE":"development","DEV":true,"PROD":false,"SSR":false};import { ref } from "/node_modules/.vite/deps/vue.js?v=1470181e";
import { initializeApp } from "/node_modules/.vite/deps/firebase_app.js?v=1470181e";
import {
  browserLocalPersistence,
  connectAuthEmulator,
  createUserWithEmailAndPassword,
  getAuth,
  onAuthStateChanged,
  setPersistence,
  signInWithEmailAndPassword,
  signOut,
  updateProfile
} from "/node_modules/.vite/deps/firebase_auth.js?v=1470181e";
const app = initializeApp({
  apiKey: import.meta.env.VITE_apiKey,
  authDomain: import.meta.env.VITE_authDomain,
  projectId: import.meta.env.VITE_projectId,
  storageBucket: import.meta.env.VITE_storageBucket,
  messagingSenderId: import.meta.env.VITE_messagingSenderId,
  appId: import.meta.env.VITE_appId,
  measurementId: import.meta.env.VITE_measurementId
});
const auth = getAuth(app);
if (import.meta.env.VITE_EMULATION)
  connectAuthEmulator(auth, "http://127.0.0.1:9099");
setPersistence(auth, browserLocalPersistence);
const firebaseUser = ref(auth.currentUser);
const login = async (email, password) => {
  return new Promise((resolve, rejects) => {
    signInWithEmailAndPassword(auth, email, password).then((userCredential) => {
      firebaseUser.value = userCredential.user;
      resolve(userCredential.user);
    }).catch((error) => {
      rejects(error);
    });
  });
};
const register = async (name, email, password) => {
  return new Promise((resolve, reject) => {
    createUserWithEmailAndPassword(auth, email, password).then((userCredential) => {
      firebaseUser.value = userCredential.user;
      updateProfile(firebaseUser.value, { displayName: name });
      resolve(userCredential.user);
    }).catch((error) => {
      reject(error);
    });
  });
};
const restoreUser = async () => {
  return new Promise((resolve) => {
    onAuthStateChanged(auth, (user) => {
      if (user) {
        firebaseUser.value = user;
        resolve(user);
      } else {
        firebaseUser.value = null;
        resolve(null);
      }
    });
  });
};
const logout = async () => {
  return new Promise((resolve, reject) => {
    signOut(auth).then(() => {
      firebaseUser.value = null;
      resolve();
    }).catch((error) => {
      reject(error);
    });
  });
};
export default () => {
  return {
    firebaseUser,
    login,
    logout,
    restoreUser,
    register
  };
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZUZpcmViYXNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHJlZiB9IGZyb20gXCJ2dWVcIlxyXG5cclxuaW1wb3J0IHsgaW5pdGlhbGl6ZUFwcCB9IGZyb20gXCJmaXJlYmFzZS9hcHBcIlxyXG5pbXBvcnQge1xyXG4gIGJyb3dzZXJMb2NhbFBlcnNpc3RlbmNlLFxyXG4gIGNvbm5lY3RBdXRoRW11bGF0b3IsXHJcbiAgY3JlYXRlVXNlcldpdGhFbWFpbEFuZFBhc3N3b3JkLFxyXG4gIGdldEF1dGgsXHJcbiAgb25BdXRoU3RhdGVDaGFuZ2VkLFxyXG4gIHNldFBlcnNpc3RlbmNlLFxyXG4gIHNpZ25JbldpdGhFbWFpbEFuZFBhc3N3b3JkLFxyXG4gIHNpZ25PdXQsXHJcbiAgdXBkYXRlUHJvZmlsZSxcclxuICB0eXBlIFVzZXIsXHJcbn0gZnJvbSBcImZpcmViYXNlL2F1dGhcIlxyXG5cclxuY29uc3QgYXBwID0gaW5pdGlhbGl6ZUFwcCh7XHJcbiAgYXBpS2V5OiBpbXBvcnQubWV0YS5lbnYuVklURV9hcGlLZXksXHJcbiAgYXV0aERvbWFpbjogaW1wb3J0Lm1ldGEuZW52LlZJVEVfYXV0aERvbWFpbixcclxuICBwcm9qZWN0SWQ6IGltcG9ydC5tZXRhLmVudi5WSVRFX3Byb2plY3RJZCxcclxuICBzdG9yYWdlQnVja2V0OiBpbXBvcnQubWV0YS5lbnYuVklURV9zdG9yYWdlQnVja2V0LFxyXG4gIG1lc3NhZ2luZ1NlbmRlcklkOiBpbXBvcnQubWV0YS5lbnYuVklURV9tZXNzYWdpbmdTZW5kZXJJZCxcclxuICBhcHBJZDogaW1wb3J0Lm1ldGEuZW52LlZJVEVfYXBwSWQsXHJcbiAgbWVhc3VyZW1lbnRJZDogaW1wb3J0Lm1ldGEuZW52LlZJVEVfbWVhc3VyZW1lbnRJZCxcclxufSlcclxuXHJcbmNvbnN0IGF1dGggPSBnZXRBdXRoKGFwcClcclxuXHJcbi8vIFdoZW4gdGhlIGVtdWxhdG9yIGlzIHJ1bm5pbmcsIGNvbm5lY3QgdG8gaXRcclxuaWYgKGltcG9ydC5tZXRhLmVudi5WSVRFX0VNVUxBVElPTilcclxuICBjb25uZWN0QXV0aEVtdWxhdG9yKGF1dGgsIFwiaHR0cDovLzEyNy4wLjAuMTo5MDk5XCIpXHJcblxyXG5zZXRQZXJzaXN0ZW5jZShhdXRoLCBicm93c2VyTG9jYWxQZXJzaXN0ZW5jZSkgLy9rZWVwIHRyYWNrIG9mIGxvZ2dlZCBpbiB1c2VyIGluIHRoZSBicm93c2VyXHJcblxyXG5jb25zdCBmaXJlYmFzZVVzZXIgPSByZWY8VXNlciB8IG51bGw+KGF1dGguY3VycmVudFVzZXIpXHJcblxyXG5jb25zdCBsb2dpbiA9IGFzeW5jIChlbWFpbDogc3RyaW5nLCBwYXNzd29yZDogc3RyaW5nKTogUHJvbWlzZTxVc2VyPiA9PiB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3RzKSA9PiB7XHJcbiAgICBzaWduSW5XaXRoRW1haWxBbmRQYXNzd29yZChhdXRoLCBlbWFpbCwgcGFzc3dvcmQpXHJcbiAgICAgIC50aGVuKHVzZXJDcmVkZW50aWFsID0+IHtcclxuICAgICAgICBmaXJlYmFzZVVzZXIudmFsdWUgPSB1c2VyQ3JlZGVudGlhbC51c2VyXHJcbiAgICAgICAgcmVzb2x2ZSh1c2VyQ3JlZGVudGlhbC51c2VyKVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goZXJyb3IgPT4ge1xyXG4gICAgICAgIHJlamVjdHMoZXJyb3IpXHJcbiAgICAgIH0pXHJcbiAgfSlcclxufVxyXG5cclxuY29uc3QgcmVnaXN0ZXIgPSBhc3luYyAoXHJcbiAgbmFtZTogc3RyaW5nLFxyXG4gIGVtYWlsOiBzdHJpbmcsXHJcbiAgcGFzc3dvcmQ6IHN0cmluZyxcclxuKTogUHJvbWlzZTxVc2VyPiA9PiB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgIGNyZWF0ZVVzZXJXaXRoRW1haWxBbmRQYXNzd29yZChhdXRoLCBlbWFpbCwgcGFzc3dvcmQpXHJcbiAgICAgIC50aGVuKHVzZXJDcmVkZW50aWFsID0+IHtcclxuICAgICAgICBmaXJlYmFzZVVzZXIudmFsdWUgPSB1c2VyQ3JlZGVudGlhbC51c2VyXHJcbiAgICAgICAgdXBkYXRlUHJvZmlsZShmaXJlYmFzZVVzZXIudmFsdWUsIHsgZGlzcGxheU5hbWU6IG5hbWUgfSlcclxuICAgICAgICByZXNvbHZlKHVzZXJDcmVkZW50aWFsLnVzZXIpXHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaChlcnJvciA9PiB7XHJcbiAgICAgICAgcmVqZWN0KGVycm9yKVxyXG4gICAgICB9KVxyXG4gIH0pXHJcbn1cclxuXHJcbmNvbnN0IHJlc3RvcmVVc2VyID0gYXN5bmMgKCk6IFByb21pc2U8VXNlciB8IG51bGw+ID0+IHtcclxuICByZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XHJcbiAgICBvbkF1dGhTdGF0ZUNoYW5nZWQoYXV0aCwgdXNlciA9PiB7XHJcbiAgICAgIGlmICh1c2VyKSB7XHJcbiAgICAgICAgZmlyZWJhc2VVc2VyLnZhbHVlID0gdXNlclxyXG4gICAgICAgIHJlc29sdmUodXNlcilcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBmaXJlYmFzZVVzZXIudmFsdWUgPSBudWxsXHJcbiAgICAgICAgcmVzb2x2ZShudWxsKVxyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gIH0pXHJcbn1cclxuXHJcbmNvbnN0IGxvZ291dCA9IGFzeW5jICgpOiBQcm9taXNlPHZvaWQ+ID0+IHtcclxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgc2lnbk91dChhdXRoKVxyXG4gICAgICAudGhlbigoKSA9PiB7XHJcbiAgICAgICAgZmlyZWJhc2VVc2VyLnZhbHVlID0gbnVsbFxyXG4gICAgICAgIHJlc29sdmUoKVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goZXJyb3IgPT4ge1xyXG4gICAgICAgIHJlamVjdChlcnJvcilcclxuICAgICAgfSlcclxuICB9KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCAoKSA9PiB7XHJcbiAgLy9zdGF0ZSBmb3IgZWFjaCBjb21wb3NhYmxlXHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBmaXJlYmFzZVVzZXIsXHJcbiAgICBsb2dpbixcclxuICAgIGxvZ291dCxcclxuICAgIHJlc3RvcmVVc2VyLFxyXG4gICAgcmVnaXN0ZXIsXHJcbiAgfVxyXG59XHJcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXO0FBRXBCLFNBQVMscUJBQXFCO0FBQzlCO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsT0FFSztBQUVQLE1BQU0sTUFBTSxjQUFjO0FBQUEsRUFDeEIsUUFBUSxZQUFZLElBQUk7QUFBQSxFQUN4QixZQUFZLFlBQVksSUFBSTtBQUFBLEVBQzVCLFdBQVcsWUFBWSxJQUFJO0FBQUEsRUFDM0IsZUFBZSxZQUFZLElBQUk7QUFBQSxFQUMvQixtQkFBbUIsWUFBWSxJQUFJO0FBQUEsRUFDbkMsT0FBTyxZQUFZLElBQUk7QUFBQSxFQUN2QixlQUFlLFlBQVksSUFBSTtBQUNqQyxDQUFDO0FBRUQsTUFBTSxPQUFPLFFBQVEsR0FBRztBQUd4QixJQUFJLFlBQVksSUFBSTtBQUNsQixzQkFBb0IsTUFBTSx1QkFBdUI7QUFFbkQsZUFBZSxNQUFNLHVCQUF1QjtBQUU1QyxNQUFNLGVBQWUsSUFBaUIsS0FBSyxXQUFXO0FBRXRELE1BQU0sUUFBUSxPQUFPLE9BQWUsYUFBb0M7QUFDdEUsU0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFlBQVk7QUFDdkMsK0JBQTJCLE1BQU0sT0FBTyxRQUFRLEVBQzdDLEtBQUssb0JBQWtCO0FBQ3RCLG1CQUFhLFFBQVEsZUFBZTtBQUNwQyxjQUFRLGVBQWUsSUFBSTtBQUFBLElBQzdCLENBQUMsRUFDQSxNQUFNLFdBQVM7QUFDZCxjQUFRLEtBQUs7QUFBQSxJQUNmLENBQUM7QUFBQSxFQUNMLENBQUM7QUFDSDtBQUVBLE1BQU0sV0FBVyxPQUNmLE1BQ0EsT0FDQSxhQUNrQjtBQUNsQixTQUFPLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVztBQUN0QyxtQ0FBK0IsTUFBTSxPQUFPLFFBQVEsRUFDakQsS0FBSyxvQkFBa0I7QUFDdEIsbUJBQWEsUUFBUSxlQUFlO0FBQ3BDLG9CQUFjLGFBQWEsT0FBTyxFQUFFLGFBQWEsS0FBSyxDQUFDO0FBQ3ZELGNBQVEsZUFBZSxJQUFJO0FBQUEsSUFDN0IsQ0FBQyxFQUNBLE1BQU0sV0FBUztBQUNkLGFBQU8sS0FBSztBQUFBLElBQ2QsQ0FBQztBQUFBLEVBQ0wsQ0FBQztBQUNIO0FBRUEsTUFBTSxjQUFjLFlBQWtDO0FBQ3BELFNBQU8sSUFBSSxRQUFRLGFBQVc7QUFDNUIsdUJBQW1CLE1BQU0sVUFBUTtBQUMvQixVQUFJLE1BQU07QUFDUixxQkFBYSxRQUFRO0FBQ3JCLGdCQUFRLElBQUk7QUFBQSxNQUNkLE9BQU87QUFDTCxxQkFBYSxRQUFRO0FBQ3JCLGdCQUFRLElBQUk7QUFBQSxNQUNkO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxDQUFDO0FBQ0g7QUFFQSxNQUFNLFNBQVMsWUFBMkI7QUFDeEMsU0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDdEMsWUFBUSxJQUFJLEVBQ1QsS0FBSyxNQUFNO0FBQ1YsbUJBQWEsUUFBUTtBQUNyQixjQUFRO0FBQUEsSUFDVixDQUFDLEVBQ0EsTUFBTSxXQUFTO0FBQ2QsYUFBTyxLQUFLO0FBQUEsSUFDZCxDQUFDO0FBQUEsRUFDTCxDQUFDO0FBQ0g7QUFFQSxlQUFlLE1BQU07QUFHbkIsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGOyIsIm5hbWVzIjpbXX0=