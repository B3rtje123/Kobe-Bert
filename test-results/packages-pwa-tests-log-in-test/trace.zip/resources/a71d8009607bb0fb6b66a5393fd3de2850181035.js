import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.vue");import { provide } from "/node_modules/.vite/deps/vue.js?v=69a8df67";
import { DefaultApolloClient } from "/node_modules/.vite/deps/@vue_apollo-composable.js?v=69a8df67";
import useGraphql from "/src/composables/useGraphql.ts";
import AppFooter from "/src/components/generic/AppFooter.vue";
import AppHeader from "/src/components/generic/AppHeader.vue";
import useLanguage from "/src/composables/useLanguage.ts";
import { useI18n } from "/node_modules/.vite/deps/vue-i18n.js?v=69a8df67";
const _sfc_main = {
  components: {
    AppFooter,
    AppHeader
  },
  setup() {
    const { apolloClient } = useGraphql();
    const { setLocale } = useLanguage();
    const { locale } = useI18n();
    provide(DefaultApolloClient, apolloClient);
    setLocale(locale.value);
    return {
      locale
    };
  }
};
import { resolveComponent as _resolveComponent, createVNode as _createVNode, createElementVNode as _createElementVNode, createCommentVNode as _createCommentVNode, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=69a8df67";
const _hoisted_1 = { class: "font-poppins bg-BgBlack text-MainWhite min-h-screen" };
const _hoisted_2 = { class: "pt-16" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_AppHeader = _resolveComponent("AppHeader");
  const _component_RouterView = _resolveComponent("RouterView");
  return _openBlock(), _createElementBlock("div", _hoisted_1, [
    _createVNode(_component_AppHeader),
    _createElementVNode("div", _hoisted_2, [
      _createVNode(_component_RouterView)
    ]),
    _createCommentVNode(' {{ locale }}\r\n    {{ $t("hallo") }} ')
  ]);
}
_sfc_main.__hmrId = "7a7a37b1";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.accept((mod) => {
  if (!mod)
    return;
  const { default: updated, _rerender_only } = mod;
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
  }
});
import _export_sfc from "/@id/__x00__plugin-vue:export-helper";
export default /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "C:/AFSD/Kobe-Bert/packages/pwa/src/App.vue"]]);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxlQUFlO0FBRXhCLFNBQVMsMkJBQTJCO0FBQ3BDLE9BQU8sZ0JBQWdCO0FBRXZCLE9BQU8sZUFBZTtBQUN0QixPQUFPLGVBQWU7QUFFdEIsT0FBTyxpQkFBaUI7QUFDeEIsU0FBUyxlQUFlO0FBRXhCLE1BQUssWUFBVTtBQUFBLEVBQ2IsWUFBWTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBRUEsUUFBUTtBQUNOLFVBQU0sRUFBRSxhQUFhLElBQUksV0FBVztBQUNwQyxVQUFNLEVBQUUsVUFBVSxJQUFJLFlBQVk7QUFDbEMsVUFBTSxFQUFFLE9BQU8sSUFBSSxRQUFRO0FBRTNCLFlBQVEscUJBQXFCLFlBQVk7QUFDekMsY0FBVSxPQUFPLEtBQUs7QUFFdEIsV0FBTztBQUFBLE1BQ0w7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGOztxQkFJTyxPQUFNLHNEQUFxRDtxQkFJekQsT0FBTSxRQUFPOzs7O3VCQUpwQixvQkFTTSxPQVROLFlBU007QUFBQSxJQU5KLGFBQWE7QUFBQSxJQUNiLG9CQUVNLE9BRk4sWUFFTTtBQUFBLE1BREosYUFBYztBQUFBO0lBRWhCO0FBQUEiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IGxhbmc9XCJ0c1wiPlxyXG5pbXBvcnQgeyBwcm92aWRlIH0gZnJvbSBcInZ1ZVwiXHJcbmltcG9ydCB7IFJvdXRlckxpbmssIFJvdXRlclZpZXcgfSBmcm9tIFwidnVlLXJvdXRlclwiXHJcbmltcG9ydCB7IERlZmF1bHRBcG9sbG9DbGllbnQgfSBmcm9tIFwiQHZ1ZS9hcG9sbG8tY29tcG9zYWJsZVwiXHJcbmltcG9ydCB1c2VHcmFwaHFsIGZyb20gXCIuL2NvbXBvc2FibGVzL3VzZUdyYXBocWxcIlxyXG5cclxuaW1wb3J0IEFwcEZvb3RlciBmcm9tIFwiLi9jb21wb25lbnRzL2dlbmVyaWMvQXBwRm9vdGVyLnZ1ZVwiXHJcbmltcG9ydCBBcHBIZWFkZXIgZnJvbSBcIi4vY29tcG9uZW50cy9nZW5lcmljL0FwcEhlYWRlci52dWVcIlxyXG5cclxuaW1wb3J0IHVzZUxhbmd1YWdlIGZyb20gXCIuL2NvbXBvc2FibGVzL3VzZUxhbmd1YWdlXCJcclxuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gXCJ2dWUtaTE4blwiXHJcblxyXG5leHBvcnQgZGVmYXVsdCB7XHJcbiAgY29tcG9uZW50czoge1xyXG4gICAgQXBwRm9vdGVyLFxyXG4gICAgQXBwSGVhZGVyLFxyXG4gIH0sXHJcblxyXG4gIHNldHVwKCkge1xyXG4gICAgY29uc3QgeyBhcG9sbG9DbGllbnQgfSA9IHVzZUdyYXBocWwoKVxyXG4gICAgY29uc3QgeyBzZXRMb2NhbGUgfSA9IHVzZUxhbmd1YWdlKClcclxuICAgIGNvbnN0IHsgbG9jYWxlIH0gPSB1c2VJMThuKClcclxuXHJcbiAgICBwcm92aWRlKERlZmF1bHRBcG9sbG9DbGllbnQsIGFwb2xsb0NsaWVudClcclxuICAgIHNldExvY2FsZShsb2NhbGUudmFsdWUpXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgbG9jYWxlLFxyXG4gICAgfVxyXG4gIH0sXHJcbn1cclxuPC9zY3JpcHQ+XHJcblxyXG48dGVtcGxhdGU+XHJcbiAgPGRpdiBjbGFzcz1cImZvbnQtcG9wcGlucyBiZy1CZ0JsYWNrIHRleHQtTWFpbldoaXRlIG1pbi1oLXNjcmVlblwiPlxyXG4gIFxyXG5cclxuICAgIDxBcHBIZWFkZXIgLz5cclxuICAgIDxkaXYgY2xhc3M9XCJwdC0xNlwiPlxyXG4gICAgICA8Um91dGVyVmlldyAvPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8IS0tIHt7IGxvY2FsZSB9fVxyXG4gICAge3sgJHQoXCJoYWxsb1wiKSB9fSAtLT5cclxuICA8L2Rpdj5cclxuPC90ZW1wbGF0ZT5cclxuIl0sImZpbGUiOiJDOi9BRlNEL0tvYmUtQmVydC9wYWNrYWdlcy9wd2Evc3JjL0FwcC52dWUifQ==