import __variableDynamicImportRuntimeHelper from "/@id/__x00__vite/dynamic-import-helper";import { SUPPORTED_LOCALES } from "/src/bootstrap/i18n.ts";
import { useI18n } from "/node_modules/.vite/deps/vue-i18n.js?v=1470181e";
export default () => {
  const { locale, t, setLocaleMessage } = useI18n();
  const loadMessages = async (locale2) => {
    if (locale2 in SUPPORTED_LOCALES) {
      const messages = await __variableDynamicImportRuntimeHelper((/* #__PURE__ */ Object.assign({"../locales/en.json": () => import("/src/locales/en.json?import"),"../locales/nl.json": () => import("/src/locales/nl.json?import")})), `../locales/${locale2}.json`).then(
        (m) => m.default[locale2]
      );
      return messages;
    }
    throw new Error(`Locale ${locale2} is not supported`);
  };
  const setLocale = async (targetlocale) => {
    const messages = await loadMessages(targetlocale);
    setLocaleMessage(targetlocale, messages);
    locale.value = targetlocale;
  };
  return {
    locale,
    setLocale
  };
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZUxhbmd1YWdlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIGNvbnN0IGxvYWRNZXNzYWdlcyA9IGFzeW5jICgpXHJcblxyXG5pbXBvcnQgeyBTVVBQT1JURURfTE9DQUxFUyB9IGZyb20gXCJAL2Jvb3RzdHJhcC9pMThuXCJcclxuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gXCJ2dWUtaTE4blwiXHJcblxyXG5leHBvcnQgZGVmYXVsdCAoKSA9PiB7XHJcbiAgY29uc3QgeyBsb2NhbGUsIHQsIHNldExvY2FsZU1lc3NhZ2UgfSA9IHVzZUkxOG4oKVxyXG5cclxuICBjb25zdCBsb2FkTWVzc2FnZXMgPSBhc3luYyAobG9jYWxlOiBzdHJpbmcpID0+IHtcclxuICAgIGlmIChsb2NhbGUgaW4gU1VQUE9SVEVEX0xPQ0FMRVMpIHtcclxuICAgICAgY29uc3QgbWVzc2FnZXMgPSBhd2FpdCBpbXBvcnQoYC4uL2xvY2FsZXMvJHtsb2NhbGV9Lmpzb25gKS50aGVuKFxyXG4gICAgICAgIG0gPT4gbS5kZWZhdWx0W2xvY2FsZV0sXHJcbiAgICAgIClcclxuXHJcbiAgICAgIHJldHVybiBtZXNzYWdlc1xyXG4gICAgfVxyXG5cclxuICAgIHRocm93IG5ldyBFcnJvcihgTG9jYWxlICR7bG9jYWxlfSBpcyBub3Qgc3VwcG9ydGVkYClcclxuICB9XHJcblxyXG4gIGNvbnN0IHNldExvY2FsZSA9IGFzeW5jICh0YXJnZXRsb2NhbGU6IHN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgbWVzc2FnZXMgPSBhd2FpdCBsb2FkTWVzc2FnZXModGFyZ2V0bG9jYWxlKVxyXG5cclxuICAgIHNldExvY2FsZU1lc3NhZ2UodGFyZ2V0bG9jYWxlLCBtZXNzYWdlcylcclxuICAgIGxvY2FsZS52YWx1ZSA9IHRhcmdldGxvY2FsZVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIGxvY2FsZSxcclxuICAgIHNldExvY2FsZSxcclxuICB9XHJcbn1cclxuIl0sIm1hcHBpbmdzIjoiQUFFQSxTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLGVBQWU7QUFFeEIsZUFBZSxNQUFNO0FBQ25CLFFBQU0sRUFBRSxRQUFRLEdBQUcsaUJBQWlCLElBQUksUUFBUTtBQUVoRCxRQUFNLGVBQWUsT0FBT0EsWUFBbUI7QUFDN0MsUUFBSUEsV0FBVSxtQkFBbUI7QUFDL0IsWUFBTSxXQUFXLE1BQU0sT0FBTyxjQUFjQSxPQUFNLFNBQVM7QUFBQSxRQUN6RCxPQUFLLEVBQUUsUUFBUUEsT0FBTTtBQUFBLE1BQ3ZCO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFFQSxVQUFNLElBQUksTUFBTSxVQUFVQSxPQUFNLG1CQUFtQjtBQUFBLEVBQ3JEO0FBRUEsUUFBTSxZQUFZLE9BQU8saUJBQXlCO0FBQ2hELFVBQU0sV0FBVyxNQUFNLGFBQWEsWUFBWTtBQUVoRCxxQkFBaUIsY0FBYyxRQUFRO0FBQ3ZDLFdBQU8sUUFBUTtBQUFBLEVBQ2pCO0FBRUEsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGOyIsIm5hbWVzIjpbImxvY2FsZSJdfQ==