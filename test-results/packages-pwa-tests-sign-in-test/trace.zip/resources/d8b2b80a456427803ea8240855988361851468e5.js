import {
  disableExperimentalFragmentVariables,
  disableFragmentWarnings,
  enableExperimentalFragmentVariables,
  gql,
  lib_default,
  resetCaches
} from "/node_modules/.vite/deps/chunk-7GID56CL.js?v=1470181e";
import "/node_modules/.vite/deps/chunk-NBBOXWME.js?v=1470181e";
import "/node_modules/.vite/deps/chunk-2ODJBQ45.js?v=1470181e";
import "/node_modules/.vite/deps/chunk-47VN6MY4.js?v=1470181e";
import "/node_modules/.vite/deps/chunk-6TJCVOLN.js?v=1470181e";
export {
  lib_default as default,
  disableExperimentalFragmentVariables,
  disableFragmentWarnings,
  enableExperimentalFragmentVariables,
  gql,
  resetCaches
};
//# sourceMappingURL=graphql-tag.js.map
