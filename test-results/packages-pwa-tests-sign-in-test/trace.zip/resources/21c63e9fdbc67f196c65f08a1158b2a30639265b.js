import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/generic/AppHeader.vue");import { ref } from "/node_modules/.vite/deps/vue.js?v=1470181e";
import useFirebase from "/src/composables/useFirebase.ts";
import { useRouter } from "/node_modules/.vite/deps/vue-router.js?v=1470181e";
import Button from "/src/components/generic/CtaButton.vue";
const _sfc_main = {
  components: {
    Button
  },
  setup() {
    const { firebaseUser } = useFirebase();
    const { replace } = useRouter();
    const showMobileMenu = ref(false);
    const links = ref([
      { name: "Ontdek het park", link: "/", state: false },
      { name: "Attracties", link: "/attractie", state: false },
      { name: "Restaurants", link: "/restaurant", state: false },
      { name: "FAQ", link: "/FAQ", state: false },
      { name: "Tickets", link: "/ticket", state: false }
    ]);
    const AccButton = () => {
      firebaseUser.value != null ? replace("/profile") : replace("/auth/login");
    };
    return {
      links,
      showMobileMenu,
      AccButton,
      firebaseUser
    };
  }
};
import { createCommentVNode as _createCommentVNode, createElementVNode as _createElementVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, normalizeClass as _normalizeClass, renderList as _renderList, Fragment as _Fragment, toDisplayString as _toDisplayString, createBlock as _createBlock, createTextVNode as _createTextVNode } from "/node_modules/.vite/deps/vue.js?v=1470181e";
const _hoisted_1 = { class: "z-50 fixed w-full flex bg-BgBlack text-MainWhite py-3.5 px-6 shadow-lg lg:flex justify-between items-center" };
const _hoisted_2 = /* @__PURE__ */ _createElementVNode(
  "svg",
  {
    class: "h-5 w-5 text-MainWhite",
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    "stroke-width": "1.5",
    stroke: "currentColor"
  },
  [
    /* @__PURE__ */ _createElementVNode("path", {
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      d: "M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.894 20.567L16.5 21.75l-.394-1.183a2.25 2.25 0 00-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 001.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 001.423 1.423l1.183.394-1.183.394a2.25 2.25 0 00-1.423 1.423z"
    })
  ],
  -1
  /* HOISTED */
);
const _hoisted_3 = /* @__PURE__ */ _createElementVNode(
  "span",
  { class: "text-xl font-extrabold text-MainWhite" },
  "Themepark",
  -1
  /* HOISTED */
);
const _hoisted_4 = /* @__PURE__ */ _createElementVNode(
  "span",
  { class: "sr-only" },
  "Open main menu",
  -1
  /* HOISTED */
);
const _hoisted_5 = { class: "block absolute left-1/2 top-1/2 w-5 transform -translate-x-1/2 -translate-y-1/2" };
const _hoisted_6 = { class: "my-6 lg:my-0" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_RouterLink = _resolveComponent("RouterLink");
  const _component_Button = _resolveComponent("Button");
  return _openBlock(), _createElementBlock("nav", _hoisted_1, [
    _createCommentVNode(" Logo "),
    _createVNode(_component_RouterLink, {
      to: "/",
      class: "flex items-center space-x-2 cursor-pointer"
    }, {
      default: _withCtx(() => [
        _hoisted_2,
        _hoisted_3
      ]),
      _: 1
      /* STABLE */
    }),
    _createCommentVNode(" HamburgerMenu Symbol (animated) "),
    _createElementVNode("button", {
      onClick: _cache[0] || (_cache[0] = ($event) => $setup.showMobileMenu = !$setup.showMobileMenu),
      class: "relative w-10 h-10 cursor-pointer text-4xl lg:hidden"
    }, [
      _hoisted_4,
      _createElementVNode("div", _hoisted_5, [
        _createElementVNode(
          "span",
          {
            "aria-hidden": "true",
            class: _normalizeClass(["block absolute h-0.75 w-5 bg-current transform transition duration-500 ease-in-out", { "rotate-45": $setup.showMobileMenu, " -translate-y-1.5": !$setup.showMobileMenu }])
          },
          null,
          2
          /* CLASS */
        ),
        _createElementVNode(
          "span",
          {
            "aria-hidden": "true",
            class: _normalizeClass(["block absolute h-0.75 w-5 bg-current transform transition duration-500 ease-in-out", { "opacity-0": $setup.showMobileMenu }])
          },
          null,
          2
          /* CLASS */
        ),
        _createElementVNode(
          "span",
          {
            "aria-hidden": "true",
            class: _normalizeClass(["block absolute h-0.75 w-5 bg-current transform transition duration-500 ease-in-out", { "-rotate-45": $setup.showMobileMenu, " translate-y-1.5": !$setup.showMobileMenu }])
          },
          null,
          2
          /* CLASS */
        )
      ])
    ]),
    _createCommentVNode(" Navigation titles "),
    _createElementVNode(
      "div",
      {
        class: _normalizeClass(["px-6 pb-10 absolute bg-BgBlack w-full top-14 duration-700 ease-in-out min-h-screen text-right text-2xl lg:flex lg:items-center lg:px-0 lg:pb-0 lg:static lg:w-auto lg:min-h-full lg:text-lg", [$setup.showMobileMenu ? "left-0 " : "left-[-100%]"]])
      },
      [
        (_openBlock(true), _createElementBlock(
          _Fragment,
          null,
          _renderList($setup.links, (link) => {
            return _openBlock(), _createBlock(_component_RouterLink, {
              to: link.link,
              class: "relative group hover:text-sky-600 focus:outline-none focus:text-sky-600 lg:mx-4 lg:my-0"
            }, {
              default: _withCtx(() => [
                _createElementVNode("div", _hoisted_6, [
                  _createElementVNode(
                    "p",
                    null,
                    _toDisplayString(link.name),
                    1
                    /* TEXT */
                  ),
                  _createElementVNode(
                    "span",
                    {
                      class: _normalizeClass(["absolute -bottom-1 left-0 w-0 h-0.5 bg-sky-600 transition-all ease-in-out duration-500 group-hover:w-full group-focus:w-full group-active:w-full", { "w-full": link.state }])
                    },
                    null,
                    2
                    /* CLASS */
                  )
                ])
              ]),
              _: 2
              /* DYNAMIC */
            }, 1032, ["to"]);
          }),
          256
          /* UNKEYED_FRAGMENT */
        )),
        _createVNode(_component_Button, {
          onClick: $setup.AccButton,
          class: "font-bold lg:hidden"
        }, {
          default: _withCtx(() => [
            _createTextVNode(
              _toDisplayString($setup.firebaseUser ? "Account" : "Login"),
              1
              /* TEXT */
            )
          ]),
          _: 1
          /* STABLE */
        }, 8, ["onClick"])
      ],
      2
      /* CLASS */
    ),
    _createCommentVNode(" Account / Login button "),
    _createVNode(_component_Button, {
      onClick: $setup.AccButton,
      class: "hidden lg:flex"
    }, {
      default: _withCtx(() => [
        _createTextVNode(
          _toDisplayString($setup.firebaseUser ? "Account" : "Login"),
          1
          /* TEXT */
        )
      ]),
      _: 1
      /* STABLE */
    }, 8, ["onClick"])
  ]);
}
_sfc_main.__hmrId = "c71bad3f";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.accept((mod) => {
  if (!mod)
    return;
  const { default: updated, _rerender_only } = mod;
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
  }
});
import _export_sfc from "/@id/__x00__plugin-vue:export-helper";
export default /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "C:/AFSD/Kobe-Bert/packages/pwa/src/components/generic/AppHeader.vue"]]);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0RJLFNBQVMsV0FBVztBQUNwQixPQUFPLGlCQUFpQjtBQUN4QixTQUFTLGlCQUFpQjtBQUMxQixPQUFPLFlBQVk7QUFFbkIsTUFBSyxZQUFTO0FBQUEsRUFDVixZQUFXO0FBQUEsSUFDUDtBQUFBLEVBQ0o7QUFBQSxFQUNBLFFBQU87QUFFSCxVQUFNLEVBQUUsYUFBYSxJQUFJLFlBQVk7QUFDckMsVUFBTSxFQUFFLFFBQVEsSUFBSSxVQUFVO0FBRTlCLFVBQU0saUJBQWlCLElBQUksS0FBSztBQUNoQyxVQUFNLFFBQVEsSUFBSTtBQUFBLE1BQ2QsRUFBQyxNQUFNLG1CQUFtQixNQUFPLEtBQUssT0FBTyxNQUFLO0FBQUEsTUFDbEQsRUFBQyxNQUFNLGNBQWMsTUFBTSxjQUFjLE9BQU8sTUFBSztBQUFBLE1BQ3JELEVBQUMsTUFBTSxlQUFlLE1BQU0sZUFBZSxPQUFPLE1BQUs7QUFBQSxNQUN2RCxFQUFDLE1BQU0sT0FBTyxNQUFNLFFBQVEsT0FBTyxNQUFLO0FBQUEsTUFDeEMsRUFBQyxNQUFNLFdBQVcsTUFBTSxXQUFXLE9BQU8sTUFBSztBQUFBLElBQ25ELENBQUM7QUFHRCxVQUFNLFlBQVksTUFBTTtBQUNwQixtQkFBYSxTQUFTLE9BQU8sUUFBUSxVQUFVLElBQUksUUFBUSxhQUFhO0FBQUEsSUFDNUU7QUFFQSxXQUFNO0FBQUEsTUFDRjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0o7QUFBQSxFQUNKO0FBQ0o7O3FCQXRGSyxPQUFNLDhHQUE2RzttQkFHaEg7QUFBQSxFQUVNO0FBQUE7QUFBQSxJQUZELE9BQU07QUFBQSxJQUF5QixPQUFNO0FBQUEsSUFBNkIsTUFBSztBQUFBLElBQU8sU0FBUTtBQUFBLElBQVksZ0JBQWE7QUFBQSxJQUFNLFFBQU87QUFBQTs7SUFDN0gsb0NBQTZvQjtBQUFBLE1BQXZvQixrQkFBZTtBQUFBLE1BQVEsbUJBQWdCO0FBQUEsTUFBUSxHQUFFO0FBQUE7Ozs7O21CQUUzRDtBQUFBLEVBQW9FO0FBQUEsSUFBOUQsT0FBTSx3Q0FBdUM7QUFBQSxFQUFDO0FBQUEsRUFBUztBQUFBO0FBQUE7bUJBTTdEO0FBQUEsRUFBMkM7QUFBQSxJQUFyQyxPQUFNLFVBQVM7QUFBQSxFQUFDO0FBQUEsRUFBYztBQUFBO0FBQUE7cUJBQy9CLE9BQU0sa0ZBQWlGO3FCQWlCbkYsT0FBTSxlQUFjOzs7O3VCQTlCckMsb0JBK0NNLE9BL0NOLFlBK0NNO0FBQUEsSUE5Q0Y7QUFBQSxJQUNBLGFBS2E7QUFBQSxNQUxELElBQUc7QUFBQSxNQUFJLE9BQU07QUFBQTt3QkFDckIsTUFFTTtBQUFBLFFBRk47QUFBQSxRQUdBO0FBQUE7Ozs7SUFHSjtBQUFBLElBQ0Esb0JBUVM7QUFBQSxNQVJBLFNBQUssc0NBQUUsd0JBQWMsQ0FBSTtBQUFBLE1BQWdCLE9BQU07QUFBQTtNQUVwRDtBQUFBLE1BQ0Esb0JBSU0sT0FKTixZQUlNO0FBQUEsUUFIRjtBQUFBLFVBQXdNO0FBQUE7QUFBQSxZQUFsTSxlQUFZO0FBQUEsWUFBTyxPQUFLLGlCQUFDLHNGQUFvRixlQUF1Qix1QkFBYyxzQkFBdUIsc0JBQWM7QUFBQTs7Ozs7UUFDN0w7QUFBQSxVQUFvSztBQUFBO0FBQUEsWUFBOUosZUFBWTtBQUFBLFlBQU8sT0FBSyxpQkFBQyxzRkFBb0YsZUFBdUIsc0JBQWM7QUFBQTs7Ozs7UUFDeEo7QUFBQSxVQUF3TTtBQUFBO0FBQUEsWUFBbE0sZUFBWTtBQUFBLFlBQU8sT0FBSyxpQkFBQyxzRkFBb0YsZ0JBQXdCLHVCQUFjLHFCQUF1QixzQkFBYztBQUFBOzs7Ozs7O0lBSXRNO0FBQUEsSUFDQTtBQUFBLE1Bb0JNO0FBQUE7QUFBQSxRQXBCRCxPQUFLLGlCQUFDLCtMQUMwRSxDQUM1RSx3QkFBYztBQUFBOzsyQkFFbkI7QUFBQSxVQVdhO0FBQUE7QUFBQSxzQkFYYyxjQUFLLENBQWIsU0FBSTtpQ0FBdkIsYUFXYTtBQUFBLGNBWHNCLElBQUksS0FBSztBQUFBLGNBQzVDLE9BQU07QUFBQTtnQ0FJRixNQUlNO0FBQUEsZ0JBSk4sb0JBSU0sT0FKTixZQUlNO0FBQUEsa0JBSEY7QUFBQSxvQkFBc0I7QUFBQTtBQUFBLHFDQUFoQixLQUFLLElBQUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDZjtBQUFBLG9CQUNzQztBQUFBO0FBQUEsc0JBRGhDLE9BQUssaUJBQUMsb0pBQWtKLFlBQzVJLEtBQUssTUFBSztBQUFBOzs7Ozs7Ozs7Ozs7OztRQUtwQyxhQUVTO0FBQUEsVUFGQSxTQUFPO0FBQUEsVUFBVyxPQUFNO0FBQUE7NEJBQzdCLE1BQXdDO0FBQUE7K0JBQXJDLHNCQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7Ozs7Ozs7O0lBSXZCO0FBQUEsSUFDQSxhQUVTO0FBQUEsTUFGQSxTQUFPO0FBQUEsTUFBVyxPQUFNO0FBQUE7d0JBQzdCLE1BQXdDO0FBQUE7MkJBQXJDLHNCQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwSGVhZGVyLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XHJcbiAgICA8bmF2IGNsYXNzPVwiei01MCBmaXhlZCB3LWZ1bGwgZmxleCBiZy1CZ0JsYWNrIHRleHQtTWFpbldoaXRlIHB5LTMuNSBweC02IHNoYWRvdy1sZyBsZzpmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICA8IS0tIExvZ28gLS0+XHJcbiAgICAgICAgPFJvdXRlckxpbmsgdG89XCIvXCIgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgPHN2ZyBjbGFzcz1cImgtNSB3LTUgdGV4dC1NYWluV2hpdGVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgZmlsbD1cIm5vbmVcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgc3Ryb2tlLXdpZHRoPVwiMS41XCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCI+XHJcbiAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBkPVwiTTkuODEzIDE1LjkwNEw5IDE4Ljc1bC0uODEzLTIuODQ2YTQuNSA0LjUgMCAwMC0zLjA5LTMuMDlMMi4yNSAxMmwyLjg0Ni0uODEzYTQuNSA0LjUgMCAwMDMuMDktMy4wOUw5IDUuMjVsLjgxMyAyLjg0NmE0LjUgNC41IDAgMDAzLjA5IDMuMDlMMTUuNzUgMTJsLTIuODQ2LjgxM2E0LjUgNC41IDAgMDAtMy4wOSAzLjA5ek0xOC4yNTkgOC43MTVMMTggOS43NWwtLjI1OS0xLjAzNWEzLjM3NSAzLjM3NSAwIDAwLTIuNDU1LTIuNDU2TDE0LjI1IDZsMS4wMzYtLjI1OWEzLjM3NSAzLjM3NSAwIDAwMi40NTUtMi40NTZMMTggMi4yNWwuMjU5IDEuMDM1YTMuMzc1IDMuMzc1IDAgMDAyLjQ1NiAyLjQ1NkwyMS43NSA2bC0xLjAzNS4yNTlhMy4zNzUgMy4zNzUgMCAwMC0yLjQ1NiAyLjQ1NnpNMTYuODk0IDIwLjU2N0wxNi41IDIxLjc1bC0uMzk0LTEuMTgzYTIuMjUgMi4yNSAwIDAwLTEuNDIzLTEuNDIzTDEzLjUgMTguNzVsMS4xODMtLjM5NGEyLjI1IDIuMjUgMCAwMDEuNDIzLTEuNDIzbC4zOTQtMS4xODMuMzk0IDEuMTgzYTIuMjUgMi4yNSAwIDAwMS40MjMgMS40MjNsMS4xODMuMzk0LTEuMTgzLjM5NGEyLjI1IDIuMjUgMCAwMC0xLjQyMyAxLjQyM3pcIiAvPlxyXG4gICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtTWFpbldoaXRlXCI+VGhlbWVwYXJrPC9zcGFuPlxyXG4gICAgICAgIDwvUm91dGVyTGluaz5cclxuXHJcbiAgICAgICAgPCEtLSBIYW1idXJnZXJNZW51IFN5bWJvbCAoYW5pbWF0ZWQpIC0tPlxyXG4gICAgICAgIDxidXR0b24gQGNsaWNrPVwic2hvd01vYmlsZU1lbnUgPSAhc2hvd01vYmlsZU1lbnVcIiBjbGFzcz1cInJlbGF0aXZlIHctMTAgaC0xMCBjdXJzb3ItcG9pbnRlciB0ZXh0LTR4bFxyXG4gICAgICAgIGxnOmhpZGRlblwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInNyLW9ubHlcIj5PcGVuIG1haW4gbWVudTwvc3Bhbj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJsb2NrIGFic29sdXRlIGxlZnQtMS8yIHRvcC0xLzIgdy01IHRyYW5zZm9ybSAtdHJhbnNsYXRlLXgtMS8yIC10cmFuc2xhdGUteS0xLzJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGNsYXNzPVwiYmxvY2sgYWJzb2x1dGUgaC0wLjc1IHctNSBiZy1jdXJyZW50IHRyYW5zZm9ybSB0cmFuc2l0aW9uIGR1cmF0aW9uLTUwMCBlYXNlLWluLW91dFwiIDpjbGFzcz1cInsncm90YXRlLTQ1Jzogc2hvd01vYmlsZU1lbnUsJyAtdHJhbnNsYXRlLXktMS41JzogIXNob3dNb2JpbGVNZW51IH1cIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIiBjbGFzcz1cImJsb2NrIGFic29sdXRlIGgtMC43NSB3LTUgYmctY3VycmVudCB0cmFuc2Zvcm0gdHJhbnNpdGlvbiBkdXJhdGlvbi01MDAgZWFzZS1pbi1vdXRcIiA6Y2xhc3M9XCJ7J29wYWNpdHktMCc6IHNob3dNb2JpbGVNZW51IH0gXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW49XCJ0cnVlXCIgY2xhc3M9XCJibG9jayBhYnNvbHV0ZSBoLTAuNzUgdy01IGJnLWN1cnJlbnQgdHJhbnNmb3JtIHRyYW5zaXRpb24gZHVyYXRpb24tNTAwIGVhc2UtaW4tb3V0XCIgOmNsYXNzPVwieyctcm90YXRlLTQ1Jzogc2hvd01vYmlsZU1lbnUsICcgdHJhbnNsYXRlLXktMS41JzogIXNob3dNb2JpbGVNZW51fVwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgIDwhLS0gTmF2aWdhdGlvbiB0aXRsZXMgLS0+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInB4LTYgcGItMTAgYWJzb2x1dGUgYmctQmdCbGFjayB3LWZ1bGwgdG9wLTE0IGR1cmF0aW9uLTcwMCBlYXNlLWluLW91dCBtaW4taC1zY3JlZW4gdGV4dC1yaWdodCB0ZXh0LTJ4bFxyXG4gICAgICAgIGxnOmZsZXggbGc6aXRlbXMtY2VudGVyIGxnOnB4LTAgbGc6cGItMCBsZzpzdGF0aWMgbGc6dy1hdXRvIGxnOm1pbi1oLWZ1bGwgbGc6dGV4dC1sZ1wiXHJcbiAgICAgICAgOmNsYXNzPVwiW3Nob3dNb2JpbGVNZW51ID8gJ2xlZnQtMCAnIDogJ2xlZnQtWy0xMDAlXSddXCI+XHJcblxyXG4gICAgICAgICAgICA8Um91dGVyTGluayB2LWZvcj1cImxpbmsgaW4gbGlua3NcIiA6dG89XCJsaW5rLmxpbmtcIiBcclxuICAgICAgICAgICAgY2xhc3M9XCJyZWxhdGl2ZSBncm91cCBcclxuICAgICAgICAgICAgaG92ZXI6dGV4dC1za3ktNjAwXHJcbiAgICAgICAgICAgIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czp0ZXh0LXNreS02MDBcclxuICAgICAgICAgICAgbGc6bXgtNCBsZzpteS0wXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibXktNiBsZzpteS0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHA+e3sgbGluay5uYW1lIH19PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYWJzb2x1dGUgLWJvdHRvbS0xIGxlZnQtMCB3LTAgaC0wLjUgYmctc2t5LTYwMCB0cmFuc2l0aW9uLWFsbCBlYXNlLWluLW91dCBkdXJhdGlvbi01MDAgZ3JvdXAtaG92ZXI6dy1mdWxsIGdyb3VwLWZvY3VzOnctZnVsbCBncm91cC1hY3RpdmU6dy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICA6Y2xhc3M9XCJ7J3ctZnVsbCc6bGluay5zdGF0ZX1cIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8L1JvdXRlckxpbms+XHJcblxyXG4gICAgICAgICAgICA8QnV0dG9uIEBjbGljaz1cIkFjY0J1dHRvblwiIGNsYXNzPVwiZm9udC1ib2xkIGxnOmhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAge3sgZmlyZWJhc2VVc2VyID8gXCJBY2NvdW50XCIgOiBcIkxvZ2luXCIgfX1cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDwhLS0gQWNjb3VudCAvIExvZ2luIGJ1dHRvbiAtLT5cclxuICAgICAgICA8QnV0dG9uIEBjbGljaz1cIkFjY0J1dHRvblwiIGNsYXNzPVwiaGlkZGVuIGxnOmZsZXhcIj5cclxuICAgICAgICAgICAge3sgZmlyZWJhc2VVc2VyID8gXCJBY2NvdW50XCIgOiBcIkxvZ2luXCIgfX0gXHJcbiAgICAgICAgPC9CdXR0b24+XHJcbiAgICA8L25hdj5cclxuPC90ZW1wbGF0ZT5cclxuXHJcbjxzY3JpcHQgbGFuZz1cInRzXCI+XHJcbiAgICBpbXBvcnQgeyByZWYgfSBmcm9tICd2dWUnXHJcbiAgICBpbXBvcnQgdXNlRmlyZWJhc2UgZnJvbSAnQC9jb21wb3NhYmxlcy91c2VGaXJlYmFzZSdcclxuICAgIGltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ3Z1ZS1yb3V0ZXInXHJcbiAgICBpbXBvcnQgQnV0dG9uIGZyb20gJy4vQ3RhQnV0dG9uLnZ1ZSdcclxuXHJcbiAgICBleHBvcnQgZGVmYXVsdHtcclxuICAgICAgICBjb21wb25lbnRzOntcclxuICAgICAgICAgICAgQnV0dG9uXHJcbiAgICAgICAgfSxcclxuICAgICAgICBzZXR1cCgpe1xyXG5cclxuICAgICAgICAgICAgY29uc3QgeyBmaXJlYmFzZVVzZXIgfSA9IHVzZUZpcmViYXNlKClcclxuICAgICAgICAgICAgY29uc3QgeyByZXBsYWNlIH0gPSB1c2VSb3V0ZXIoKVxyXG5cclxuICAgICAgICAgICAgY29uc3Qgc2hvd01vYmlsZU1lbnUgPSByZWYoZmFsc2UpXHJcbiAgICAgICAgICAgIGNvbnN0IGxpbmtzID0gcmVmKFtcclxuICAgICAgICAgICAgICAgIHtuYW1lOiBcIk9udGRlayBoZXQgcGFya1wiLCBsaW5rIDogXCIvXCIsIHN0YXRlOiBmYWxzZX0sXHJcbiAgICAgICAgICAgICAgICB7bmFtZTogXCJBdHRyYWN0aWVzXCIsIGxpbms6IFwiL2F0dHJhY3RpZVwiLCBzdGF0ZTogZmFsc2V9LFxyXG4gICAgICAgICAgICAgICAge25hbWU6IFwiUmVzdGF1cmFudHNcIiwgbGluazogXCIvcmVzdGF1cmFudFwiLCBzdGF0ZTogZmFsc2V9LFxyXG4gICAgICAgICAgICAgICAge25hbWU6IFwiRkFRXCIsIGxpbms6IFwiL0ZBUVwiLCBzdGF0ZTogZmFsc2V9LFxyXG4gICAgICAgICAgICAgICAge25hbWU6IFwiVGlja2V0c1wiLCBsaW5rOiBcIi90aWNrZXRcIiwgc3RhdGU6IGZhbHNlfSxcclxuICAgICAgICAgICAgXSlcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBjb25zdCBBY2NCdXR0b24gPSAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBmaXJlYmFzZVVzZXIudmFsdWUgIT0gbnVsbCA/IHJlcGxhY2UoJy9wcm9maWxlJykgOiByZXBsYWNlKCcvYXV0aC9sb2dpbicpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybntcclxuICAgICAgICAgICAgICAgIGxpbmtzLFxyXG4gICAgICAgICAgICAgICAgc2hvd01vYmlsZU1lbnUsXHJcbiAgICAgICAgICAgICAgICBBY2NCdXR0b24sXHJcbiAgICAgICAgICAgICAgICBmaXJlYmFzZVVzZXIsXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbjwvc2NyaXB0PlxyXG4iXSwiZmlsZSI6IkM6L0FGU0QvS29iZS1CZXJ0L3BhY2thZ2VzL3B3YS9zcmMvY29tcG9uZW50cy9nZW5lcmljL0FwcEhlYWRlci52dWUifQ==