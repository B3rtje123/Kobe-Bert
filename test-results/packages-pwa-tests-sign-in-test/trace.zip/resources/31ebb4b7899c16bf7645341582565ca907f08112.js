import {
  ApolloLink,
  Observable
} from "/node_modules/.vite/deps/chunk-27PNIARD.js?v=1470181e";
import "/node_modules/.vite/deps/chunk-NBBOXWME.js?v=1470181e";
import "/node_modules/.vite/deps/chunk-2ODJBQ45.js?v=1470181e";
import {
  __rest
} from "/node_modules/.vite/deps/chunk-47VN6MY4.js?v=1470181e";
import "/node_modules/.vite/deps/chunk-6TJCVOLN.js?v=1470181e";

// ../../node_modules/@apollo/client/link/context/index.js
function setContext(setter) {
  return new ApolloLink(function(operation, forward) {
    var request = __rest(operation, []);
    return new Observable(function(observer) {
      var handle;
      var closed = false;
      Promise.resolve(request).then(function(req) {
        return setter(req, operation.getContext());
      }).then(operation.setContext).then(function() {
        if (closed)
          return;
        handle = forward(operation).subscribe({
          next: observer.next.bind(observer),
          error: observer.error.bind(observer),
          complete: observer.complete.bind(observer)
        });
      }).catch(observer.error.bind(observer));
      return function() {
        closed = true;
        if (handle)
          handle.unsubscribe();
      };
    });
  });
}
export {
  setContext
};
//# sourceMappingURL=@apollo_client_link_context.js.map
