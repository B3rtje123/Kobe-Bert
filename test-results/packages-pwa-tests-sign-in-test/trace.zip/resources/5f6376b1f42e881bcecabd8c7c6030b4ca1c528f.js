export const nl = {
	Key: "nl",
	"navigation.home": "Home",
	"navigation.birds": "Vogels",
	"navigation.observations": "Observaties",
	"navigation.user": "Gebruiker",
	"footer.disclaimer": "Disclaimer",
	"birds.title.observation": "Observaties",
	"birds.description.spotted": "Deze vogel is nog niet gespot. | Deze vogel is een keer gepot. | Deze vogel is {n} keer gespot.",
	"account.welcome": "Hallo, {user}",
	"account.stats": "Statistieken",
	"account.realtime": "Realtime",
	"account.settings": "Instellingen",
	"account.log.out": "Afmelden"
};
export default {
	nl: nl
};
