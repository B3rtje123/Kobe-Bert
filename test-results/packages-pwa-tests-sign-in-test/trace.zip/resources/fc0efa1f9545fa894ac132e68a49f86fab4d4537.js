import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/auth/login.vue");import { defineComponent as _defineComponent } from "/node_modules/.vite/deps/vue.js?v=1470181e";
import { ref } from "/node_modules/.vite/deps/vue.js?v=1470181e";
import useFirebase from "/src/composables/useFirebase.ts";
import { useRouter } from "/node_modules/.vite/deps/vue-router.js?v=1470181e";
const _sfc_main = /* @__PURE__ */ _defineComponent({
  __name: "login",
  setup(__props, { expose: __expose }) {
    __expose();
    const { login, firebaseUser } = useFirebase();
    const { replace } = useRouter();
    const loginCredentials = ref({
      email: "",
      password: ""
    });
    const error = ref(null);
    const showError = ref(false);
    const tooMany = ref(false);
    const wrongLogin = ref(false);
    const isValidEmail = (EmailParameter) => {
      return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(EmailParameter) ? true : false;
    };
    const handleLogin = () => {
      tooMany.value = false;
      wrongLogin.value = false;
      if (isValidEmail(loginCredentials.value.email) == true) {
        login(loginCredentials.value.email, loginCredentials.value.password).then(() => {
          replace("/");
        }).catch((err) => {
          error.value = err;
          console.log(error.value.code);
          if (error.value.code == "auth/invalid-login-credentials") {
            wrongLogin.value = true;
          }
          if (error.value.code == "auth/too-many-requests") {
            tooMany.value = true;
          }
        });
      } else {
        showError.value = true;
        console.log("email of password is niet goed");
      }
    };
    const __returned__ = { login, firebaseUser, replace, loginCredentials, error, showError, tooMany, wrongLogin, isValidEmail, handleLogin };
    Object.defineProperty(__returned__, "__isScriptSetup", { enumerable: false, value: true });
    return __returned__;
  }
});
import { createElementVNode as _createElementVNode, toDisplayString as _toDisplayString, vModelText as _vModelText, withDirectives as _withDirectives, vShow as _vShow, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, withModifiers as _withModifiers, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=1470181e";
const _hoisted_1 = ["onSubmit"];
const _hoisted_2 = { class: "rounded-lg max-w-sm shadow-[0_0_60px_-25px_rgba(0,0,0,0.3)] shadow-AccentBlue p-12 bg-MainWhite" };
const _hoisted_3 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "text-center m-8" },
  [
    /* @__PURE__ */ _createElementVNode("h1", { class: "text-3xl font-semibold" }, "Log in"),
    /* @__PURE__ */ _createElementVNode("h2", { class: "text-xs mt-1" }, "Enter your account details below")
  ],
  -1
  /* HOISTED */
);
const _hoisted_4 = { class: "text-red-500 font-medium text-center" };
const _hoisted_5 = { class: "text-red-500 font-medium text-center" };
const _hoisted_6 = { class: "mb-6" };
const _hoisted_7 = /* @__PURE__ */ _createElementVNode(
  "label",
  {
    for: "email",
    class: "mb-4 font-medium"
  },
  "Email",
  -1
  /* HOISTED */
);
const _hoisted_8 = { class: "mb-6" };
const _hoisted_9 = /* @__PURE__ */ _createElementVNode(
  "label",
  {
    for: "password",
    class: "mb-4 font-medium"
  },
  "Password",
  -1
  /* HOISTED */
);
const _hoisted_10 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "" },
  [
    /* @__PURE__ */ _createElementVNode("button", {
      type: "submit",
      class: "w-full py-2 border border-hidden rounded-lg mb-8 font-semibold bg-AccentBlue text-MainWhite transition ease-in-out duration-300 hover:bg-BgBlack/25 hover:text-BgBlack focus:outline-none focus:ring-4 focus:ring-AccentBlue focus:bg-[#1B8ACC]"
    }, " Log in ")
  ],
  -1
  /* HOISTED */
);
const _hoisted_11 = /* @__PURE__ */ _createElementVNode(
  "p",
  { class: "p-1" },
  [
    /* @__PURE__ */ _createTextVNode("Don't have an account yet? "),
    /* @__PURE__ */ _createElementVNode("span", { class: "text-AccentBlue" }, "Sign up")
  ],
  -1
  /* HOISTED */
);
const _hoisted_12 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "inline-flex items-center justify-center w-full" },
  [
    /* @__PURE__ */ _createElementVNode("hr", { class: "w-full h-px translate-y-0.5 my-8 bg-BgBlack border-0" }),
    /* @__PURE__ */ _createElementVNode("span", { class: "absolute px-3 font-medium text-BgBlack -translate-x-1/2 bg-MainWhite left-1/2" }, "or")
  ],
  -1
  /* HOISTED */
);
const _hoisted_13 = /* @__PURE__ */ _createElementVNode(
  "p",
  null,
  "Continue without logging in",
  -1
  /* HOISTED */
);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_RouterLink = _resolveComponent("RouterLink");
  return _openBlock(), _createElementBlock("form", {
    onSubmit: _withModifiers($setup.handleLogin, ["prevent"]),
    class: "flex mt-16 justify-center items-center text-BgBlack"
  }, [
    _createElementVNode("div", _hoisted_2, [
      _hoisted_3,
      _createElementVNode(
        "p",
        _hoisted_4,
        _toDisplayString($setup.tooMany ? "You have tried too many times.\nTry again later!" : ""),
        1
        /* TEXT */
      ),
      _createElementVNode(
        "p",
        _hoisted_5,
        _toDisplayString($setup.wrongLogin ? "Email or password is wrong!" : ""),
        1
        /* TEXT */
      ),
      _createElementVNode("div", _hoisted_6, [
        _hoisted_7,
        _withDirectives(_createElementVNode(
          "input",
          {
            type: "text",
            name: "email",
            id: "email",
            placeholder: "example@domain.com",
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => $setup.loginCredentials.email = $event),
            required: "",
            autocomplete: "off",
            class: "block rounded-lg border-2 p-2 shadow-inner shadow-gray-400 w-full transition-colors ease-in-out duration-300 hover:border-AccentBlue focus:outline-none focus:ring-4 focus:ring-AccentBlue",
            onInput: _cache[1] || (_cache[1] = () => {
            })
          },
          null,
          544
          /* HYDRATE_EVENTS, NEED_PATCH */
        ), [
          [_vModelText, $setup.loginCredentials.email]
        ]),
        _withDirectives(_createElementVNode(
          "p",
          { class: "text-red-500" },
          _toDisplayString($setup.isValidEmail($setup.loginCredentials.email) ? "" : "Ongeldig e-mail adres"),
          513
          /* TEXT, NEED_PATCH */
        ), [
          [_vShow, $setup.showError]
        ])
      ]),
      _createElementVNode("div", _hoisted_8, [
        _hoisted_9,
        _withDirectives(_createElementVNode(
          "input",
          {
            type: "text",
            name: "password",
            id: "password",
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => $setup.loginCredentials.password = $event),
            autocomplete: "off",
            class: "block rounded-lg border-2 p-2 shadow-inner shadow-gray-400 w-full transition-colors ease-in-out duration-300 hover:border-AccentBlue focus:outline-none focus:ring-4 focus:ring-AccentBlue"
          },
          null,
          512
          /* NEED_PATCH */
        ), [
          [_vModelText, $setup.loginCredentials.password]
        ])
      ]),
      _hoisted_10,
      _createElementVNode("div", null, [
        _createVNode(_component_RouterLink, {
          to: "/auth/register",
          class: "font-normal text-sm focus:outline-AccentBlue"
        }, {
          default: _withCtx(() => [
            _hoisted_11
          ]),
          _: 1
          /* STABLE */
        })
      ]),
      _hoisted_12,
      _createVNode(_component_RouterLink, {
        to: "/",
        class: "flex border border-BgBlack justify-center py-3 rounded-lg w-full hover:font-semibold focus:outline-none focus:ring-4 focus:ring-AccentBlue focus:border-AccentBlue focus:font-medium"
      }, {
        default: _withCtx(() => [
          _hoisted_13
        ]),
        _: 1
        /* STABLE */
      })
    ])
  ], 40, _hoisted_1);
}
_sfc_main.__hmrId = "50c09a87";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.accept((mod) => {
  if (!mod)
    return;
  const { default: updated, _rerender_only } = mod;
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
  }
});
import _export_sfc from "/@id/__x00__plugin-vue:export-helper";
export default /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "C:/AFSD/Kobe-Bert/packages/pwa/src/views/auth/login.vue"]]);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQThFRSxTQUFTLFdBQVc7QUFHcEIsT0FBTyxpQkFBaUI7QUFDeEIsU0FBUyxpQkFBaUI7Ozs7O0FBRzFCLFVBQU0sRUFBRSxPQUFPLGFBQWEsSUFBSSxZQUFZO0FBQzVDLFVBQU0sRUFBRSxRQUFRLElBQUksVUFBVTtBQUc5QixVQUFNLG1CQUFtQixJQUFJO0FBQUEsTUFDM0IsT0FBTztBQUFBLE1BQ1AsVUFBUztBQUFBLElBQ1gsQ0FBQztBQUNELFVBQU0sUUFBUSxJQUFzQixJQUFJO0FBQ3hDLFVBQU0sWUFBWSxJQUFJLEtBQUs7QUFDM0IsVUFBTSxVQUFVLElBQUksS0FBSztBQUN6QixVQUFNLGFBQWEsSUFBSSxLQUFLO0FBRTVCLFVBQU0sZUFBZSxDQUFDLG1CQUE0QjtBQUNoRCxhQUFPLGdEQUFnRCxLQUFLLGNBQWMsSUFBSSxPQUFRO0FBQUEsSUFDeEY7QUFFQSxVQUFNLGNBQWMsTUFBTTtBQUN4QixjQUFRLFFBQVE7QUFDaEIsaUJBQVcsUUFBUTtBQUNuQixVQUFHLGFBQWEsaUJBQWlCLE1BQU0sS0FBSyxLQUFLLE1BQUs7QUFDcEQsY0FBTSxpQkFBaUIsTUFBTSxPQUFPLGlCQUFpQixNQUFNLFFBQVEsRUFDbEUsS0FBSyxNQUFNO0FBQ1Ysa0JBQVEsR0FBRztBQUFBLFFBQ2IsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxRQUFtQjtBQUN6QixnQkFBTSxRQUFRO0FBQ2Qsa0JBQVEsSUFBSSxNQUFNLE1BQU0sSUFBSTtBQUM1QixjQUFHLE1BQU0sTUFBTSxRQUFRLGtDQUFpQztBQUN0RCx1QkFBVyxRQUFRO0FBQUEsVUFDckI7QUFDQSxjQUFHLE1BQU0sTUFBTSxRQUFRLDBCQUF5QjtBQUM5QyxvQkFBUSxRQUFRO0FBQUEsVUFDbEI7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNILE9BQ0k7QUFFRixrQkFBVSxRQUFRO0FBQ2xCLGdCQUFRLElBQUksZ0NBQWdDO0FBQUEsTUFDOUM7QUFBQSxJQUVGOzs7Ozs7OztxQkE1SE8sT0FBTSxrR0FBaUc7bUJBRTFHO0FBQUEsRUFHTTtBQUFBLElBSEQsT0FBTSxrQkFBaUI7QUFBQTtBQUFBLElBQzFCLG9DQUE4QyxRQUExQyxPQUFNLHlCQUF3QixHQUFDLFFBQU07QUFBQSxJQUN6QyxvQ0FBOEQsUUFBMUQsT0FBTSxlQUFjLEdBQUMsa0NBQWdDO0FBQUE7Ozs7cUJBR3hELE9BQU0sdUNBQXNDO3FCQUM1QyxPQUFNLHVDQUFzQztxQkFFMUMsT0FBTSxPQUFNO21CQUNmO0FBQUEsRUFBeUQ7QUFBQTtBQUFBLElBQWxELEtBQUk7QUFBQSxJQUFRLE9BQU07QUFBQTtFQUFtQjtBQUFBLEVBQUs7QUFBQTtBQUFBO3FCQWlCOUMsT0FBTSxPQUFNO21CQUNmO0FBQUEsRUFBK0Q7QUFBQTtBQUFBLElBQXhELEtBQUk7QUFBQSxJQUFXLE9BQU07QUFBQTtFQUFtQjtBQUFBLEVBQVE7QUFBQTtBQUFBO29CQWF6RDtBQUFBLEVBU007QUFBQSxJQVRELE9BQU0sR0FBRTtBQUFBO0FBQUEsSUFDWCxvQ0FPUztBQUFBLE1BTkwsTUFBSztBQUFBLE1BQ0wsT0FBTTtBQUFBLE9BR1QsVUFFRDtBQUFBOzs7O29CQU1FO0FBQUEsRUFBMEY7QUFBQSxJQUF2RixPQUFNLE1BQUs7QUFBQTtBQUFBLHFDQUFDLDZCQUEyQjtBQUFBLHdDQUE0QyxVQUF0QyxPQUFNLGtCQUFpQixHQUFDLFNBQU87QUFBQTs7OztvQkFJbkY7QUFBQSxFQUdNO0FBQUEsSUFIRCxPQUFNLGlEQUFnRDtBQUFBO0FBQUEsSUFDekQsb0NBQWlFLFFBQTdELE9BQU0sdURBQXNEO0FBQUEsSUFDaEUsb0NBQXFHLFVBQS9GLE9BQU0sZ0ZBQStFLEdBQUMsSUFBRTtBQUFBOzs7O29CQU01RjtBQUFBLEVBQWtDO0FBQUE7QUFBQSxFQUEvQjtBQUFBLEVBQTJCO0FBQUE7QUFBQTs7O3VCQXRFdEMsb0JBeUVPO0FBQUEsSUF6RUEsVUFBTSxlQUFVLG9CQUFXO0FBQUEsSUFDbEMsT0FBTTtBQUFBO0lBQ0osb0JBc0VNLE9BdEVOLFlBc0VNO0FBQUEsTUFwRUo7QUFBQSxNQUtBO0FBQUEsUUFBMkg7QUFBQSxRQUEzSDtBQUFBLFFBQTJILGlCQUF4RSxpQkFBTztBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQzFEO0FBQUEsUUFBeUc7QUFBQSxRQUF6RztBQUFBLFFBQXlHLGlCQUF0RCxvQkFBVTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRTdELG9CQWdCTSxPQWhCTixZQWdCTTtBQUFBLFFBZko7QUFBQSx3QkFDQTtBQUFBLFVBWUU7QUFBQTtBQUFBLFlBWEUsTUFBSztBQUFBLFlBQ0wsTUFBSztBQUFBLFlBQ0wsSUFBRztBQUFBLFlBQ0gsYUFBWTtBQUFBLHlFQUNILHdCQUFpQixRQUFLO0FBQUEsWUFDL0I7QUFBQSxZQUNBLGNBQWE7QUFBQSxZQUNiLE9BQU07QUFBQSxZQUdMLFNBQUssMEJBQU47QUFBQTtBQUFBOzs7Ozt3QkFOUyx3QkFBaUIsS0FBSztBQUFBO3dCQVFuQztBQUFBLFVBQXdIO0FBQUEsWUFBbEcsT0FBTSxlQUFjO0FBQUEsMkJBQUksb0JBQWEsd0JBQWlCLEtBQUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdEUsZ0JBQVM7QUFBQTs7TUFHdEIsb0JBWU0sT0FaTixZQVlNO0FBQUEsUUFYSjtBQUFBLHdCQUNBO0FBQUEsVUFTRTtBQUFBO0FBQUEsWUFSQSxNQUFLO0FBQUEsWUFDTCxNQUFLO0FBQUEsWUFDTCxJQUFHO0FBQUEseUVBQ00sd0JBQWlCLFdBQVE7QUFBQSxZQUNsQyxjQUFhO0FBQUEsWUFDYixPQUFNO0FBQUE7Ozs7O3dCQUZHLHdCQUFpQixRQUFRO0FBQUE7O01BUXRDO0FBQUEsTUFXQSxvQkFLTTtBQUFBLFFBSkosYUFHYTtBQUFBLFVBSEQsSUFBRztBQUFBLFVBQWlCLE9BQU07QUFBQTs0QkFFcEMsTUFBMEY7QUFBQSxZQUExRjtBQUFBOzs7OztNQUlKO0FBQUEsTUFLQSxhQUlhO0FBQUEsUUFKRCxJQUFHO0FBQUEsUUFBSSxPQUFNO0FBQUE7MEJBR3JCLE1BQWtDO0FBQUEsVUFBbEM7QUFBQSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJsb2dpbi52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxyXG4gIDxmb3JtIEBzdWJtaXQucHJldmVudD1cImhhbmRsZUxvZ2luXCJcclxuICBjbGFzcz1cImZsZXggbXQtMTYganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHRleHQtQmdCbGFja1wiPlxyXG4gICAgPGRpdiBjbGFzcz1cInJvdW5kZWQtbGcgbWF4LXctc20gc2hhZG93LVswXzBfNjBweF8tMjVweF9yZ2JhKDAsMCwwLDAuMyldIHNoYWRvdy1BY2NlbnRCbHVlIHAtMTIgYmctTWFpbldoaXRlXCI+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzPVwidGV4dC1jZW50ZXIgbS04XCI+XHJcbiAgICAgICAgPGgxIGNsYXNzPVwidGV4dC0zeGwgZm9udC1zZW1pYm9sZFwiPkxvZyBpbjwvaDE+XHJcbiAgICAgICAgPGgyIGNsYXNzPVwidGV4dC14cyBtdC0xXCI+RW50ZXIgeW91ciBhY2NvdW50IGRldGFpbHMgYmVsb3c8L2gyPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxwIGNsYXNzPVwidGV4dC1yZWQtNTAwIGZvbnQtbWVkaXVtIHRleHQtY2VudGVyXCI+e3sgdG9vTWFueSA/ICdZb3UgaGF2ZSB0cmllZCB0b28gbWFueSB0aW1lcy5cXG5UcnkgYWdhaW4gbGF0ZXIhJyA6ICcnIH19PC9wPlxyXG4gICAgICA8cCBjbGFzcz1cInRleHQtcmVkLTUwMCBmb250LW1lZGl1bSB0ZXh0LWNlbnRlclwiPnt7IHdyb25nTG9naW4gPyAnRW1haWwgb3IgcGFzc3dvcmQgaXMgd3JvbmchJyA6ICcnIH19PC9wPlxyXG5cclxuICAgICAgPGRpdiBjbGFzcz1cIm1iLTZcIj5cclxuICAgICAgICA8bGFiZWwgZm9yPVwiZW1haWxcIiBjbGFzcz1cIm1iLTQgZm9udC1tZWRpdW1cIj5FbWFpbDwvbGFiZWw+XHJcbiAgICAgICAgPGlucHV0IFxyXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgIG5hbWU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgIGlkPVwiZW1haWxcIlxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cImV4YW1wbGVAZG9tYWluLmNvbVwiXHJcbiAgICAgICAgICAgIHYtbW9kZWw9XCJsb2dpbkNyZWRlbnRpYWxzLmVtYWlsXCJcclxuICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgYXV0b2NvbXBsZXRlPVwib2ZmXCJcclxuICAgICAgICAgICAgY2xhc3M9XCJibG9jayByb3VuZGVkLWxnIGJvcmRlci0yIHAtMiBzaGFkb3ctaW5uZXIgc2hhZG93LWdyYXktNDAwIHctZnVsbCB0cmFuc2l0aW9uLWNvbG9ycyBlYXNlLWluLW91dCBkdXJhdGlvbi0zMDBcclxuICAgICAgICAgICAgaG92ZXI6Ym9yZGVyLUFjY2VudEJsdWUgXHJcbiAgICAgICAgICAgIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTQgZm9jdXM6cmluZy1BY2NlbnRCbHVlXCIgICBcclxuICAgICAgICAgICAgQGlucHV0PVwiXCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIDxwIHYtc2hvdz1cInNob3dFcnJvclwiIGNsYXNzPVwidGV4dC1yZWQtNTAwXCI+e3sgaXNWYWxpZEVtYWlsKGxvZ2luQ3JlZGVudGlhbHMuZW1haWwpID8gXCJcIiA6IFwiT25nZWxkaWcgZS1tYWlsIGFkcmVzXCIgfX08L3A+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzcz1cIm1iLTZcIj5cclxuICAgICAgICA8bGFiZWwgZm9yPVwicGFzc3dvcmRcIiBjbGFzcz1cIm1iLTQgZm9udC1tZWRpdW1cIj5QYXNzd29yZDwvbGFiZWw+XHJcbiAgICAgICAgPGlucHV0IFxyXG4gICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgbmFtZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgdi1tb2RlbD1cImxvZ2luQ3JlZGVudGlhbHMucGFzc3dvcmRcIlxyXG4gICAgICAgICAgYXV0b2NvbXBsZXRlPVwib2ZmXCJcclxuICAgICAgICAgIGNsYXNzPVwiYmxvY2sgcm91bmRlZC1sZyBib3JkZXItMiBwLTIgc2hhZG93LWlubmVyIHNoYWRvdy1ncmF5LTQwMCB3LWZ1bGwgdHJhbnNpdGlvbi1jb2xvcnMgZWFzZS1pbi1vdXQgZHVyYXRpb24tMzAwXHJcbiAgICAgICAgICAgIGhvdmVyOmJvcmRlci1BY2NlbnRCbHVlIFxyXG4gICAgICAgICAgICBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctQWNjZW50Qmx1ZSBcIiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzPVwiXCI+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgY2xhc3M9XCJ3LWZ1bGwgcHktMiBib3JkZXIgYm9yZGVyLWhpZGRlbiByb3VuZGVkLWxnIG1iLTggZm9udC1zZW1pYm9sZCBiZy1BY2NlbnRCbHVlIHRleHQtTWFpbldoaXRlIHRyYW5zaXRpb24gZWFzZS1pbi1vdXQgZHVyYXRpb24tMzAwXHJcbiAgICAgICAgICAgIGhvdmVyOmJnLUJnQmxhY2svMjUgaG92ZXI6dGV4dC1CZ0JsYWNrIFxyXG4gICAgICAgICAgICBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctQWNjZW50Qmx1ZSBmb2N1czpiZy1bIzFCOEFDQ11cIlxyXG4gICAgICAgID5cclxuICAgICAgICAgICAgTG9nIGluXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8Um91dGVyTGluayB0bz1cIi9hdXRoL3JlZ2lzdGVyXCIgY2xhc3M9XCJmb250LW5vcm1hbCB0ZXh0LXNtIFxyXG4gICAgICAgIGZvY3VzOm91dGxpbmUtQWNjZW50Qmx1ZSBcIj5cclxuICAgICAgICAgIDxwIGNsYXNzPVwicC0xXCI+RG9uJ3QgaGF2ZSBhbiBhY2NvdW50IHlldD8gPHNwYW4gY2xhc3M9XCJ0ZXh0LUFjY2VudEJsdWVcIj5TaWduIHVwPC9zcGFuPjwvcD5cclxuICAgICAgICA8L1JvdXRlckxpbms+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzcz1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LWZ1bGxcIj5cclxuICAgICAgICA8aHIgY2xhc3M9XCJ3LWZ1bGwgaC1weCB0cmFuc2xhdGUteS0wLjUgbXktOCBiZy1CZ0JsYWNrIGJvcmRlci0wXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJhYnNvbHV0ZSBweC0zIGZvbnQtbWVkaXVtIHRleHQtQmdCbGFjayAtdHJhbnNsYXRlLXgtMS8yIGJnLU1haW5XaGl0ZSBsZWZ0LTEvMlwiPm9yPC9zcGFuPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxSb3V0ZXJMaW5rIHRvPVwiL1wiIGNsYXNzPVwiZmxleCBib3JkZXIgYm9yZGVyLUJnQmxhY2sganVzdGlmeS1jZW50ZXIgcHktMyByb3VuZGVkLWxnIHctZnVsbFxyXG4gICAgICBob3Zlcjpmb250LXNlbWlib2xkIFxyXG4gICAgICBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctQWNjZW50Qmx1ZSBmb2N1czpib3JkZXItQWNjZW50Qmx1ZSBmb2N1czpmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgPHA+Q29udGludWUgd2l0aG91dCBsb2dnaW5nIGluPC9wPlxyXG4gICAgICA8L1JvdXRlckxpbms+XHJcbiAgICA8L2Rpdj5cclxuICA8L2Zvcm0+XHJcbjwvdGVtcGxhdGU+XHJcblxyXG48c2NyaXB0IHNldHVwIGxhbmc9XCJ0c1wiPlxyXG4gIGltcG9ydCB7IHJlZiB9IGZyb20gJ3Z1ZSdcclxuICBpbXBvcnQgeyBBdXRoRXJyb3JDb2RlcywgdHlwZSBBdXRoRXJyb3IgfSBmcm9tICdmaXJlYmFzZS9hdXRoJ1xyXG5cclxuICBpbXBvcnQgdXNlRmlyZWJhc2UgZnJvbSAnQC9jb21wb3NhYmxlcy91c2VGaXJlYmFzZSdcclxuICBpbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICd2dWUtcm91dGVyJ1xyXG5cclxuICAvL2NvbXBvc2FibGVzXHJcbiAgY29uc3QgeyBsb2dpbiwgZmlyZWJhc2VVc2VyIH0gPSB1c2VGaXJlYmFzZSgpXHJcbiAgY29uc3QgeyByZXBsYWNlIH0gPSB1c2VSb3V0ZXIoKVxyXG5cclxuICAvL2xvZ2ljXHJcbiAgY29uc3QgbG9naW5DcmVkZW50aWFscyA9IHJlZih7XHJcbiAgICBlbWFpbDogJycsXHJcbiAgICBwYXNzd29yZDonJyxcclxuICB9KVxyXG4gIGNvbnN0IGVycm9yID0gcmVmPEF1dGhFcnJvciB8IG51bGw+KG51bGwpXHJcbiAgY29uc3Qgc2hvd0Vycm9yID0gcmVmKGZhbHNlKVxyXG4gIGNvbnN0IHRvb01hbnkgPSByZWYoZmFsc2UpXHJcbiAgY29uc3Qgd3JvbmdMb2dpbiA9IHJlZihmYWxzZSlcclxuXHJcbiAgY29uc3QgaXNWYWxpZEVtYWlsID0gKEVtYWlsUGFyYW1ldGVyIDogc3RyaW5nKSA9PiB7XHJcbiAgICByZXR1cm4gL15cXHcrKFtcXC4tXT9cXHcrKSpAXFx3KyhbXFwuLV0/XFx3KykqKFxcLlxcd3syLDN9KSskLy50ZXN0KEVtYWlsUGFyYW1ldGVyKSA/IHRydWUgIDogZmFsc2VcclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gKCkgPT4ge1xyXG4gICAgdG9vTWFueS52YWx1ZSA9IGZhbHNlXHJcbiAgICB3cm9uZ0xvZ2luLnZhbHVlID0gZmFsc2VcclxuICAgIGlmKGlzVmFsaWRFbWFpbChsb2dpbkNyZWRlbnRpYWxzLnZhbHVlLmVtYWlsKSA9PSB0cnVlKXtcclxuICAgICAgbG9naW4obG9naW5DcmVkZW50aWFscy52YWx1ZS5lbWFpbCwgbG9naW5DcmVkZW50aWFscy52YWx1ZS5wYXNzd29yZClcclxuICAgICAgLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgIHJlcGxhY2UoJy8nKVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycjogQXV0aEVycm9yKSA9PiB7XHJcbiAgICAgICAgZXJyb3IudmFsdWUgPSBlcnJcclxuICAgICAgICBjb25zb2xlLmxvZyhlcnJvci52YWx1ZS5jb2RlKVxyXG4gICAgICAgIGlmKGVycm9yLnZhbHVlLmNvZGUgPT0gJ2F1dGgvaW52YWxpZC1sb2dpbi1jcmVkZW50aWFscycpe1xyXG4gICAgICAgICAgd3JvbmdMb2dpbi52YWx1ZSA9IHRydWVcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYoZXJyb3IudmFsdWUuY29kZSA9PSAnYXV0aC90b28tbWFueS1yZXF1ZXN0cycpe1xyXG4gICAgICAgICAgdG9vTWFueS52YWx1ZSA9IHRydWVcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICB9XHJcbiAgICBlbHNle1xyXG4gICAgICBcclxuICAgICAgc2hvd0Vycm9yLnZhbHVlID0gdHJ1ZVxyXG4gICAgICBjb25zb2xlLmxvZyhcImVtYWlsIG9mIHBhc3N3b3JkIGlzIG5pZXQgZ29lZFwiKVxyXG4gICAgfVxyXG5cclxuICB9XHJcbjwvc2NyaXB0PlxyXG4iXSwiZmlsZSI6IkM6L0FGU0QvS29iZS1CZXJ0L3BhY2thZ2VzL3B3YS9zcmMvdmlld3MvYXV0aC9sb2dpbi52dWUifQ==