import gql from "/node_modules/.vite/deps/graphql-tag.js?v=1470181e";
export const ADD_USER = gql`
  mutation createUser($createUserInput: CreateUserInput!) {
    createUser(createUserInput: $createUserInput) {
      id
      uid
      locale
      role
    }
  }
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXIubXV0YXRpb24udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGdxbCBmcm9tICdncmFwaHFsLXRhZydcclxuXHJcbmV4cG9ydCBjb25zdCBBRERfVVNFUiA9IGdxbGBcclxuICBtdXRhdGlvbiBjcmVhdGVVc2VyKCRjcmVhdGVVc2VySW5wdXQ6IENyZWF0ZVVzZXJJbnB1dCEpIHtcclxuICAgIGNyZWF0ZVVzZXIoY3JlYXRlVXNlcklucHV0OiAkY3JlYXRlVXNlcklucHV0KSB7XHJcbiAgICAgIGlkXHJcbiAgICAgIHVpZFxyXG4gICAgICBsb2NhbGVcclxuICAgICAgcm9sZVxyXG4gICAgfVxyXG4gIH1cclxuYCJdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTO0FBRVQsYUFBTSxXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOyIsIm5hbWVzIjpbXX0=