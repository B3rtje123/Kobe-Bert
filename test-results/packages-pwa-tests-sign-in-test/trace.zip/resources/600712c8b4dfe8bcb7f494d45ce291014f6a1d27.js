import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/generic/AppFooter.vue");const _sfc_main = {}

function _sfc_render(_ctx, _cache) {
  return "appfooter"
}


_sfc_main.__hmrId = "4b9af5d7"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/AFSD/Kobe-Bert/packages/pwa/src/components/generic/AppFooter.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkFwcEZvb3Rlci52dWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7U0FBQSxXQUFTIiwiZmlsZSI6IkM6L0FGU0QvS29iZS1CZXJ0L3BhY2thZ2VzL3B3YS9zcmMvY29tcG9uZW50cy9nZW5lcmljL0FwcEZvb3Rlci52dWUiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPmFwcGZvb3RlcjwvdGVtcGxhdGU+XHJcbiJdfQ==