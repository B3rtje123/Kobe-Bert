import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/auth/register.vue");import { defineComponent as _defineComponent } from "/node_modules/.vite/deps/vue.js?v=1470181e";
import { ref } from "/node_modules/.vite/deps/vue.js?v=1470181e";
import useFirebase from "/src/composables/useFirebase.ts";
import useCustomUser from "/src/composables/useCustomUser.ts";
import { useMutation } from "/node_modules/.vite/deps/@vue_apollo-composable.js?v=1470181e";
import { ADD_USER } from "/src/graphql/user.mutation.ts";
import { useI18n } from "/node_modules/.vite/deps/vue-i18n.js?v=1470181e";
import { useRouter } from "/node_modules/.vite/deps/vue-router.js?v=1470181e";
const _sfc_main = /* @__PURE__ */ _defineComponent({
  __name: "register",
  setup(__props, { expose: __expose }) {
    __expose();
    const { register } = useFirebase();
    const { locale } = useI18n();
    const { customUser } = useCustomUser();
    const { replace } = useRouter();
    const error = ref(null);
    const startValidation = ref(false);
    const showError = ref(false);
    const newUser = ref({
      name: "",
      password: "",
      email: ""
    });
    const checker = ref({
      has_number: false,
      has_lowercase: false,
      has_uppercase: false,
      has_special: false
    });
    const { mutate: addUser, loading: addUserLoading } = useMutation(ADD_USER);
    const isValidEmail = (EmailParameter) => {
      return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(EmailParameter) ? true : false;
    };
    const isStrongPassword = (PasswordParameter) => {
      if (/\d/.test(PasswordParameter)) {
        checker.value.has_number = true;
      } else {
        checker.value.has_number = false;
      }
      if (/[a-z]/.test(PasswordParameter)) {
        checker.value.has_lowercase = true;
      } else {
        checker.value.has_lowercase = false;
      }
      if (/[A-Z]/.test(PasswordParameter)) {
        checker.value.has_uppercase = true;
      } else {
        checker.value.has_uppercase = false;
      }
      if (/[!@#\$%\^\&*\)\(+=._-]/.test(PasswordParameter)) {
        checker.value.has_special = true;
      } else {
        checker.value.has_special = false;
      }
    };
    const passwordLength = (Password) => {
      return Password.length >= 8 ? true : false;
    };
    const handleRegister = () => {
      if (isValidEmail(newUser.value.email) == true && passwordLength(newUser.value.password) == true) {
        register(newUser.value.name, newUser.value.email, newUser.value.password).then(() => {
          addUser({
            createUserInput: {
              name: newUser.value.name,
              email: newUser.value.email,
              role: "CLIENT",
              locale: locale.value
            }
          }).then((result) => {
            if (!result?.data)
              throw new Error("Custom user creation failed");
            customUser.value = result.data;
            console.log(newUser);
            replace("/");
          });
        }).catch((err) => {
          error.value = err;
        });
      } else {
        showError.value = true;
        console.log("email of password is niet goed");
      }
    };
    const __returned__ = { register, locale, customUser, replace, error, startValidation, showError, newUser, checker, addUser, addUserLoading, isValidEmail, isStrongPassword, passwordLength, handleRegister };
    Object.defineProperty(__returned__, "__isScriptSetup", { enumerable: false, value: true });
    return __returned__;
  }
});
import { createElementVNode as _createElementVNode, vModelText as _vModelText, withDirectives as _withDirectives, normalizeClass as _normalizeClass, createTextVNode as _createTextVNode, toDisplayString as _toDisplayString, vShow as _vShow, createCommentVNode as _createCommentVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, withModifiers as _withModifiers, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=1470181e";
const _hoisted_1 = ["onSubmit"];
const _hoisted_2 = { class: "rounded-lg max-w-sm shadow-[0_0_60px_-25px_rgba(0,0,0,0.3)] shadow-AccentBlue p-12 bg-MainWhite" };
const _hoisted_3 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "text-center m-8" },
  [
    /* @__PURE__ */ _createElementVNode("h1", { class: "text-3xl font-semibold" }, "Sign up"),
    /* @__PURE__ */ _createElementVNode("h2", { class: "text-xs mt-1" }, "Enter your account details below")
  ],
  -1
  /* HOISTED */
);
const _hoisted_4 = { class: "mb-6" };
const _hoisted_5 = /* @__PURE__ */ _createElementVNode(
  "label",
  {
    for: "nickname",
    class: "mb-4 font-medium"
  },
  "Username",
  -1
  /* HOISTED */
);
const _hoisted_6 = { class: "mb-6" };
const _hoisted_7 = {
  for: "email",
  class: "mb-4 font-medium"
};
const _hoisted_8 = { class: "mb-6" };
const _hoisted_9 = {
  for: "password",
  class: "mb-4 font-medium"
};
const _hoisted_10 = { class: "text-sm" };
const _hoisted_11 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "" },
  [
    /* @__PURE__ */ _createElementVNode("button", {
      type: "submit",
      class: "w-full py-2 rounded-lg mb-8 font-semibold bg-AccentBlue text-MainWhite"
    }, " Sign up ")
  ],
  -1
  /* HOISTED */
);
const _hoisted_12 = /* @__PURE__ */ _createElementVNode(
  "p",
  null,
  [
    /* @__PURE__ */ _createTextVNode("Do you have an account? "),
    /* @__PURE__ */ _createElementVNode("span", { class: "text-AccentBlue" }, "Log in")
  ],
  -1
  /* HOISTED */
);
const _hoisted_13 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "inline-flex items-center justify-center w-full" },
  [
    /* @__PURE__ */ _createElementVNode("hr", { class: "w-full h-px translate-y-0.5 my-8 bg-BgBlack border-0" }),
    /* @__PURE__ */ _createElementVNode("span", { class: "absolute px-3 font-medium text-BgBlack -translate-x-1/2 bg-MainWhite left-1/2" }, "or")
  ],
  -1
  /* HOISTED */
);
const _hoisted_14 = { class: "flex justify-center items-center" };
const _hoisted_15 = { class: "border border-BgBlack px-6 py-3 rounded-lg" };
const _hoisted_16 = /* @__PURE__ */ _createElementVNode(
  "p",
  null,
  "Continue without logging in",
  -1
  /* HOISTED */
);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_RouterLink = _resolveComponent("RouterLink");
  return _openBlock(), _createElementBlock("form", {
    onSubmit: _withModifiers($setup.handleRegister, ["prevent"]),
    class: "flex mt-16 justify-center items-center text-BgBlack"
  }, [
    _createElementVNode("div", _hoisted_2, [
      _hoisted_3,
      _createElementVNode("div", _hoisted_4, [
        _hoisted_5,
        _withDirectives(_createElementVNode(
          "input",
          {
            type: "text",
            name: "nickname",
            id: "nickname",
            placeholder: "Joey",
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => $setup.newUser.name = $event),
            required: "",
            autocomplete: "off",
            class: "block rounded-lg border-2 p-2 shadow-inner shadow-gray-400 w-full transition-colors ease-in-out duration-300 hover:border-AccentBlue focus:outline-none focus:ring-4 focus:ring-AccentBlue"
          },
          null,
          512
          /* NEED_PATCH */
        ), [
          [_vModelText, $setup.newUser.name]
        ])
      ]),
      _createElementVNode("div", _hoisted_6, [
        _createElementVNode("label", _hoisted_7, [
          _createTextVNode("Email"),
          _createElementVNode(
            "span",
            {
              class: _normalizeClass({ "animate-pulse text-red-500 font-semibold": !$setup.isValidEmail($setup.newUser.email), "text-BgBlack font-normal animate-none": $setup.isValidEmail($setup.newUser.email) })
            },
            "*",
            2
            /* CLASS */
          )
        ]),
        _withDirectives(_createElementVNode(
          "input",
          {
            type: "text",
            name: "email",
            id: "email",
            placeholder: "example@domain.com",
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => $setup.newUser.email = $event),
            required: "",
            autocomplete: "off",
            class: "block rounded-lg border-2 p-2 shadow-inner shadow-gray-400 w-full transition-colors ease-in-out duration-300 hover:border-AccentBlue focus:outline-none focus:ring-4 focus:ring-AccentBlue",
            onInput: _cache[2] || (_cache[2] = () => {
            })
          },
          null,
          544
          /* HYDRATE_EVENTS, NEED_PATCH */
        ), [
          [_vModelText, $setup.newUser.email]
        ]),
        _withDirectives(_createElementVNode(
          "p",
          { class: "text-red-500" },
          _toDisplayString($setup.isValidEmail($setup.newUser.email) ? "" : "Ongeldig e-mail adres"),
          513
          /* TEXT, NEED_PATCH */
        ), [
          [_vShow, $setup.showError]
        ])
      ]),
      _createElementVNode("div", _hoisted_8, [
        _createElementVNode("label", _hoisted_9, [
          _createTextVNode("Password"),
          _createElementVNode(
            "span",
            {
              class: _normalizeClass({ "animate-pulse text-red-500 font-semibold": !$setup.passwordLength($setup.newUser.password), "text-BgBlack font-normal animate-none": $setup.passwordLength($setup.newUser.password) })
            },
            "*",
            2
            /* CLASS */
          )
        ]),
        _withDirectives(_createElementVNode(
          "input",
          {
            type: "text",
            name: "password",
            id: "password",
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => $setup.newUser.password = $event),
            autocomplete: "off",
            class: "block rounded-lg border-2 p-2 shadow-inner shadow-gray-400 w-full transition-colors ease-in-out duration-300 hover:border-AccentBlue focus:outline-none focus:ring-4 focus:ring-AccentBlue",
            onInput: _cache[4] || (_cache[4] = ($event) => ($setup.isStrongPassword($setup.newUser.password), $setup.passwordLength($setup.newUser.password)))
          },
          null,
          544
          /* HYDRATE_EVENTS, NEED_PATCH */
        ), [
          [_vModelText, $setup.newUser.password]
        ]),
        _createElementVNode("div", _hoisted_10, [
          _createElementVNode(
            "p",
            {
              class: _normalizeClass(["font-semibold", { "text-green-700": $setup.passwordLength($setup.newUser.password), "text-red-500": !$setup.passwordLength($setup.newUser.password) }])
            },
            _toDisplayString($setup.passwordLength($setup.newUser.password) ? "Je wachtwoord bevat 8 tekens" : "Moet minstens 8 tekens bevatten"),
            3
            /* TEXT, CLASS */
          ),
          _createCommentVNode(' <p>Make sure your password has the following:</p>\r\n                    <ul class="">\r\n                        <li class="list-disc">{{ checker.has_lowercase ? "Has lowercase letters" : "Has NO lowercase letters" }}</li>\r\n                        <li class="list-disc">{{ checker.has_uppercase ? "Has uppercase letters" : "Has NO uppercase letters" }}</li>\r\n                        <li class="list-disc">{{ checker.has_number ? "Has numbers" : "Has NO numbers" }}</li>\r\n                        <li class="list-disc">{{ checker.has_special ? "Has special characters" : "Has NO special characters" }}</li>\r\n                    </ul> ')
        ])
      ]),
      _hoisted_11,
      _createElementVNode("div", null, [
        _createVNode(_component_RouterLink, {
          to: "/auth/login",
          class: "font-normal text-sm"
        }, {
          default: _withCtx(() => [
            _hoisted_12
          ]),
          _: 1
          /* STABLE */
        })
      ]),
      _hoisted_13,
      _createElementVNode("div", _hoisted_14, [
        _createElementVNode("button", _hoisted_15, [
          _createVNode(_component_RouterLink, {
            to: "/",
            class: ""
          }, {
            default: _withCtx(() => [
              _hoisted_16
            ]),
            _: 1
            /* STABLE */
          })
        ])
      ])
    ])
  ], 40, _hoisted_1);
}
_sfc_main.__hmrId = "1046051f";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.accept((mod) => {
  if (!mod)
    return;
  const { default: updated, _rerender_only } = mod;
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
  }
});
import _export_sfc from "/@id/__x00__plugin-vue:export-helper";
export default /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "C:/AFSD/Kobe-Bert/packages/pwa/src/views/auth/register.vue"]]);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQXNHSSxTQUFtQixXQUFXO0FBRzlCLE9BQU8saUJBQWlCO0FBQ3hCLE9BQU8sbUJBQW1CO0FBQzFCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsZUFBZTtBQUd4QixTQUFTLGlCQUFpQjs7Ozs7QUFJMUIsVUFBTSxFQUFFLFNBQVMsSUFBSSxZQUFZO0FBQ2pDLFVBQU0sRUFBRSxPQUFPLElBQUksUUFBUTtBQUMzQixVQUFNLEVBQUUsV0FBVyxJQUFJLGNBQWM7QUFDckMsVUFBTSxFQUFFLFFBQVEsSUFBSSxVQUFVO0FBRzlCLFVBQU0sUUFBUSxJQUFzQixJQUFJO0FBQ3hDLFVBQU0sa0JBQWtCLElBQUksS0FBSztBQUNqQyxVQUFNLFlBQVksSUFBSSxLQUFLO0FBQzNCLFVBQU0sVUFBVSxJQUFJO0FBQUEsTUFDaEIsTUFBTTtBQUFBLE1BQ04sVUFBVTtBQUFBLE1BQ1YsT0FBTztBQUFBLElBQ1gsQ0FBQztBQUNELFVBQU0sVUFBVSxJQUFJO0FBQUEsTUFDaEIsWUFBWTtBQUFBLE1BQ1osZUFBZTtBQUFBLE1BQ2YsZUFBZTtBQUFBLE1BQ2YsYUFBYTtBQUFBLElBQ2pCLENBQUM7QUFFRCxVQUFNLEVBQUUsUUFBUSxTQUFTLFNBQVMsZUFBZSxJQUFJLFlBQXdCLFFBQVE7QUFFckYsVUFBTSxlQUFlLENBQUMsbUJBQTRCO0FBQzlDLGFBQU8sZ0RBQWdELEtBQUssY0FBYyxJQUFJLE9BQVE7QUFBQSxJQUMxRjtBQUVBLFVBQU0sbUJBQW1CLENBQUMsc0JBQStCO0FBQ3JELFVBQUcsS0FBSyxLQUFLLGlCQUFpQixHQUFFO0FBQzVCLGdCQUFRLE1BQU0sYUFBYTtBQUFBLE1BQy9CLE9BQ0k7QUFDQSxnQkFBUSxNQUFNLGFBQWE7QUFBQSxNQUMvQjtBQUNBLFVBQUcsUUFBUSxLQUFLLGlCQUFpQixHQUFFO0FBQy9CLGdCQUFRLE1BQU0sZ0JBQWdCO0FBQUEsTUFDbEMsT0FDSTtBQUNBLGdCQUFRLE1BQU0sZ0JBQWdCO0FBQUEsTUFDbEM7QUFDQSxVQUFHLFFBQVEsS0FBSyxpQkFBaUIsR0FBRTtBQUMvQixnQkFBUSxNQUFNLGdCQUFnQjtBQUFBLE1BQ2xDLE9BQ0k7QUFDQSxnQkFBUSxNQUFNLGdCQUFnQjtBQUFBLE1BQ2xDO0FBQ0EsVUFBRyx5QkFBeUIsS0FBSyxpQkFBaUIsR0FBRTtBQUNoRCxnQkFBUSxNQUFNLGNBQWM7QUFBQSxNQUNoQyxPQUNJO0FBQ0EsZ0JBQVEsTUFBTSxjQUFjO0FBQUEsTUFDaEM7QUFBQSxJQUNKO0FBQ0EsVUFBTSxpQkFBaUIsQ0FBQyxhQUFzQjtBQUMxQyxhQUFPLFNBQVMsVUFBVSxJQUFJLE9BQU87QUFBQSxJQUN6QztBQUVBLFVBQU0saUJBQWlCLE1BQU07QUFHekIsVUFBRyxhQUFhLFFBQVEsTUFBTSxLQUFLLEtBQUssUUFBUSxlQUFlLFFBQVEsTUFBTSxRQUFRLEtBQUssTUFBSztBQUMzRixpQkFBUyxRQUFRLE1BQU0sTUFBTSxRQUFRLE1BQU0sT0FBTyxRQUFRLE1BQU0sUUFBUSxFQUN2RSxLQUFLLE1BQU07QUFDUixrQkFBUTtBQUFBLFlBQ0osaUJBQWlCO0FBQUEsY0FDYixNQUFNLFFBQVEsTUFBTTtBQUFBLGNBQ3BCLE9BQU8sUUFBUSxNQUFNO0FBQUEsY0FDckIsTUFBTTtBQUFBLGNBQ04sUUFBUSxPQUFPO0FBQUEsWUFDbkI7QUFBQSxVQUNKLENBQUMsRUFBRSxLQUFLLFlBQVU7QUFDZCxnQkFBSSxDQUFDLFFBQVE7QUFBTSxvQkFBTSxJQUFJLE1BQU0sNkJBQTZCO0FBRWhFLHVCQUFXLFFBQVEsT0FBTztBQUMxQixvQkFBUSxJQUFJLE9BQU87QUFDbkIsb0JBQVEsR0FBRztBQUFBLFVBQ2YsQ0FBQztBQUFBLFFBQ0wsQ0FBQyxFQUNBLE1BQU0sU0FBTztBQUNWLGdCQUFNLFFBQVE7QUFBQSxRQUNsQixDQUFDO0FBQUEsTUFDTCxPQUNJO0FBQ0Esa0JBQVUsUUFBUTtBQUNsQixnQkFBUSxJQUFJLGdDQUFnQztBQUFBLE1BQ2hEO0FBQUEsSUFFSjs7Ozs7Ozs7cUJBeE1TLE9BQU0sa0dBQWlHO21CQUN4RztBQUFBLEVBR007QUFBQSxJQUhELE9BQU0sa0JBQWlCO0FBQUE7QUFBQSxJQUN4QixvQ0FBK0MsUUFBM0MsT0FBTSx5QkFBd0IsR0FBQyxTQUFPO0FBQUEsSUFDMUMsb0NBQThELFFBQTFELE9BQU0sZUFBYyxHQUFDLGtDQUFnQztBQUFBOzs7O3FCQUd4RCxPQUFNLE9BQU07bUJBQ2I7QUFBQSxFQUErRDtBQUFBO0FBQUEsSUFBeEQsS0FBSTtBQUFBLElBQVcsT0FBTTtBQUFBO0VBQW1CO0FBQUEsRUFBUTtBQUFBO0FBQUE7cUJBZXRELE9BQU0sT0FBTTs7RUFDTixLQUFJO0FBQUEsRUFBUSxPQUFNOztxQkFpQnhCLE9BQU0sT0FBTTs7RUFDTixLQUFJO0FBQUEsRUFBVyxPQUFNOztzQkFhdkIsT0FBTSxVQUFTO29CQVl4QjtBQUFBLEVBT007QUFBQSxJQVBELE9BQU0sR0FBRTtBQUFBO0FBQUEsSUFDVCxvQ0FLUztBQUFBLE1BSkwsTUFBSztBQUFBLE1BQ0wsT0FBTTtBQUFBLE9BQ1QsV0FFRDtBQUFBOzs7O29CQUtJO0FBQUEsRUFBMEU7QUFBQTtBQUFBO0FBQUEscUNBQXZFLDBCQUF3QjtBQUFBLHdDQUEyQyxVQUFyQyxPQUFNLGtCQUFpQixHQUFDLFFBQU07QUFBQTs7OztvQkFJdkU7QUFBQSxFQUdNO0FBQUEsSUFIRCxPQUFNLGlEQUFnRDtBQUFBO0FBQUEsSUFDdkQsb0NBQWlFLFFBQTdELE9BQU0sdURBQXNEO0FBQUEsSUFDaEUsb0NBQXFHLFVBQS9GLE9BQU0sZ0ZBQStFLEdBQUMsSUFBRTtBQUFBOzs7O3NCQUc3RixPQUFNLG1DQUFrQztzQkFDakMsT0FBTSw2Q0FBNEM7b0JBRWxEO0FBQUEsRUFBa0M7QUFBQTtBQUFBLEVBQS9CO0FBQUEsRUFBMkI7QUFBQTtBQUFBOzs7dUJBM0ZsRCxvQkFnR087QUFBQSxJQWhHQSxVQUFNLGVBQVUsdUJBQWM7QUFBQSxJQUNyQyxPQUFNO0FBQUE7SUFDRixvQkE2Rk0sT0E3Rk4sWUE2Rk07QUFBQSxNQTVGRjtBQUFBLE1BS0Esb0JBY00sT0FkTixZQWNNO0FBQUEsUUFiRjtBQUFBLHdCQUNBO0FBQUEsVUFXRTtBQUFBO0FBQUEsWUFWRSxNQUFLO0FBQUEsWUFDTCxNQUFLO0FBQUEsWUFDTCxJQUFHO0FBQUEsWUFDSCxhQUFZO0FBQUEseUVBQ0gsZUFBUSxPQUFJO0FBQUEsWUFDckI7QUFBQSxZQUNBLGNBQWE7QUFBQSxZQUNiLE9BQU07QUFBQTs7Ozs7d0JBSEcsZUFBUSxJQUFJO0FBQUE7O01BUzdCLG9CQWdCTSxPQWhCTixZQWdCTTtBQUFBLFFBZkYsb0JBQW1PLFNBQW5PLFlBQW1PO0FBQUEsMkJBQXZMLE9BQUs7QUFBQTtBQUFBLFlBQTBLO0FBQUE7QUFBQSxjQUFuSyxPQUFLLCtEQUFpRCxvQkFBYSxlQUFRLEtBQUssNENBQTZDLG9CQUFhLGVBQVEsS0FBSztBQUFBO1lBQUk7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO3dCQUNwTjtBQUFBLFVBWUU7QUFBQTtBQUFBLFlBWEUsTUFBSztBQUFBLFlBQ0wsTUFBSztBQUFBLFlBQ0wsSUFBRztBQUFBLFlBQ0gsYUFBWTtBQUFBLHlFQUNILGVBQVEsUUFBSztBQUFBLFlBQ3RCO0FBQUEsWUFDQSxjQUFhO0FBQUEsWUFDYixPQUFNO0FBQUEsWUFHTCxTQUFLLDBCQUFOO0FBQUE7QUFBQTs7Ozs7d0JBTlMsZUFBUSxLQUFLO0FBQUE7d0JBUTFCO0FBQUEsVUFBK0c7QUFBQSxZQUF6RixPQUFNLGVBQWM7QUFBQSwyQkFBSSxvQkFBYSxlQUFRLEtBQUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBN0QsZ0JBQVM7QUFBQTs7TUFHeEIsb0JBd0JNLE9BeEJOLFlBd0JNO0FBQUEsUUF2QkYsb0JBQW1QLFNBQW5QLFlBQW1QO0FBQUEsMkJBQXBNLFVBQVE7QUFBQTtBQUFBLFlBQW9MO0FBQUE7QUFBQSxjQUE3SyxPQUFLLCtEQUFpRCxzQkFBZSxlQUFRLFFBQVEsNENBQTZDLHNCQUFlLGVBQVEsUUFBUTtBQUFBO1lBQUk7QUFBQSxZQUFDO0FBQUE7QUFBQTtBQUFBO3dCQUNwTztBQUFBLFVBV0U7QUFBQTtBQUFBLFlBVkUsTUFBSztBQUFBLFlBQ0wsTUFBSztBQUFBLFlBQ0wsSUFBRztBQUFBLHlFQUNNLGVBQVEsV0FBUTtBQUFBLFlBQ3pCLGNBQWE7QUFBQSxZQUNiLE9BQU07QUFBQSxZQUdMLFNBQUssdUNBQUUsd0JBQWlCLGVBQVEsUUFBUSxHQUFHLHNCQUFlLGVBQVEsUUFBUTtBQUFBOzs7Ozt3QkFMbEUsZUFBUSxRQUFRO0FBQUE7UUFRN0Isb0JBU00sT0FUTixhQVNNO0FBQUEsVUFSRjtBQUFBLFlBQTZQO0FBQUE7QUFBQSxjQUExUCxPQUFLLGlCQUFDLGlCQUFlLG9CQUE4QixzQkFBZSxlQUFRLFFBQVEsb0JBQXFCLHNCQUFlLGVBQVEsUUFBUTtBQUFBOzZCQUFRLHNCQUFlLGVBQVEsUUFBUTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQ2hMO0FBQUE7O01BVVI7QUFBQSxNQVNBLG9CQUlNO0FBQUEsUUFIRixhQUVhO0FBQUEsVUFGRCxJQUFHO0FBQUEsVUFBYyxPQUFNO0FBQUE7NEJBQy9CLE1BQTBFO0FBQUEsWUFBMUU7QUFBQTs7Ozs7TUFJUjtBQUFBLE1BS0Esb0JBTU0sT0FOTixhQU1NO0FBQUEsUUFMRixvQkFJUyxVQUpULGFBSVM7QUFBQSxVQUhMLGFBRWE7QUFBQSxZQUZELElBQUc7QUFBQSxZQUFJLE9BQU07QUFBQTs4QkFDckIsTUFBa0M7QUFBQSxjQUFsQztBQUFBIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInJlZ2lzdGVyLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XHJcbiAgICA8Zm9ybSBAc3VibWl0LnByZXZlbnQ9XCJoYW5kbGVSZWdpc3RlclwiIFxyXG4gICAgY2xhc3M9XCJmbGV4IG10LTE2IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciB0ZXh0LUJnQmxhY2tcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicm91bmRlZC1sZyBtYXgtdy1zbSBzaGFkb3ctWzBfMF82MHB4Xy0yNXB4X3JnYmEoMCwwLDAsMC4zKV0gc2hhZG93LUFjY2VudEJsdWUgcC0xMiBiZy1NYWluV2hpdGVcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtY2VudGVyIG0tOFwiPlxyXG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzPVwidGV4dC0zeGwgZm9udC1zZW1pYm9sZFwiPlNpZ24gdXA8L2gxPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzPVwidGV4dC14cyBtdC0xXCI+RW50ZXIgeW91ciBhY2NvdW50IGRldGFpbHMgYmVsb3c8L2gyPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwibmlja25hbWVcIiBjbGFzcz1cIm1iLTQgZm9udC1tZWRpdW1cIj5Vc2VybmFtZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJuaWNrbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJuaWNrbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJKb2V5XCJcclxuICAgICAgICAgICAgICAgICAgICB2LW1vZGVsPVwibmV3VXNlci5uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGF1dG9jb21wbGV0ZT1cIm9mZlwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJibG9jayByb3VuZGVkLWxnIGJvcmRlci0yIHAtMiBzaGFkb3ctaW5uZXIgc2hhZG93LWdyYXktNDAwIHctZnVsbCB0cmFuc2l0aW9uLWNvbG9ycyBlYXNlLWluLW91dCBkdXJhdGlvbi0zMDBcclxuICAgICAgICAgICAgICAgICAgICBob3Zlcjpib3JkZXItQWNjZW50Qmx1ZSBcclxuICAgICAgICAgICAgICAgICAgICBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctQWNjZW50Qmx1ZVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwiZW1haWxcIiBjbGFzcz1cIm1iLTQgZm9udC1tZWRpdW1cIj5FbWFpbDxzcGFuIDpjbGFzcz1cInsnYW5pbWF0ZS1wdWxzZSB0ZXh0LXJlZC01MDAgZm9udC1zZW1pYm9sZCcgOiAhaXNWYWxpZEVtYWlsKG5ld1VzZXIuZW1haWwpLCAndGV4dC1CZ0JsYWNrIGZvbnQtbm9ybWFsIGFuaW1hdGUtbm9uZScgOiBpc1ZhbGlkRW1haWwobmV3VXNlci5lbWFpbCl9XCI+Kjwvc3Bhbj48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0IFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZXhhbXBsZUBkb21haW4uY29tXCJcclxuICAgICAgICAgICAgICAgICAgICB2LW1vZGVsPVwibmV3VXNlci5lbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBhdXRvY29tcGxldGU9XCJvZmZcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiYmxvY2sgcm91bmRlZC1sZyBib3JkZXItMiBwLTIgc2hhZG93LWlubmVyIHNoYWRvdy1ncmF5LTQwMCB3LWZ1bGwgdHJhbnNpdGlvbi1jb2xvcnMgZWFzZS1pbi1vdXQgZHVyYXRpb24tMzAwXHJcbiAgICAgICAgICAgICAgICAgICAgaG92ZXI6Ym9yZGVyLUFjY2VudEJsdWUgXHJcbiAgICAgICAgICAgICAgICAgICAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctNCBmb2N1czpyaW5nLUFjY2VudEJsdWVcIiAgIFxyXG4gICAgICAgICAgICAgICAgICAgIEBpbnB1dD1cIlwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPHAgdi1zaG93PVwic2hvd0Vycm9yXCIgY2xhc3M9XCJ0ZXh0LXJlZC01MDBcIj57eyBpc1ZhbGlkRW1haWwobmV3VXNlci5lbWFpbCkgPyBcIlwiIDogXCJPbmdlbGRpZyBlLW1haWwgYWRyZXNcIiB9fTwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGZvcj1cInBhc3N3b3JkXCIgY2xhc3M9XCJtYi00IGZvbnQtbWVkaXVtXCI+UGFzc3dvcmQ8c3BhbiA6Y2xhc3M9XCJ7J2FuaW1hdGUtcHVsc2UgdGV4dC1yZWQtNTAwIGZvbnQtc2VtaWJvbGQnIDogIXBhc3N3b3JkTGVuZ3RoKG5ld1VzZXIucGFzc3dvcmQpLCAndGV4dC1CZ0JsYWNrIGZvbnQtbm9ybWFsIGFuaW1hdGUtbm9uZScgOiBwYXNzd29yZExlbmd0aChuZXdVc2VyLnBhc3N3b3JkKX1cIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdi1tb2RlbD1cIm5ld1VzZXIucGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGF1dG9jb21wbGV0ZT1cIm9mZlwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJibG9jayByb3VuZGVkLWxnIGJvcmRlci0yIHAtMiBzaGFkb3ctaW5uZXIgc2hhZG93LWdyYXktNDAwIHctZnVsbCB0cmFuc2l0aW9uLWNvbG9ycyBlYXNlLWluLW91dCBkdXJhdGlvbi0zMDBcclxuICAgICAgICAgICAgICAgICAgICBob3Zlcjpib3JkZXItQWNjZW50Qmx1ZSBcclxuICAgICAgICAgICAgICAgICAgICBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctQWNjZW50Qmx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgQGlucHV0PVwiaXNTdHJvbmdQYXNzd29yZChuZXdVc2VyLnBhc3N3b3JkKSwgcGFzc3dvcmRMZW5ndGgobmV3VXNlci5wYXNzd29yZClcIlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJmb250LXNlbWlib2xkXCIgOmNsYXNzPVwieyAndGV4dC1ncmVlbi03MDAnIDogcGFzc3dvcmRMZW5ndGgobmV3VXNlci5wYXNzd29yZCksICd0ZXh0LXJlZC01MDAnIDogIXBhc3N3b3JkTGVuZ3RoKG5ld1VzZXIucGFzc3dvcmQpIH1cIj57eyBwYXNzd29yZExlbmd0aChuZXdVc2VyLnBhc3N3b3JkKSA/IFwiSmUgd2FjaHR3b29yZCBiZXZhdCA4IHRla2Vuc1wiIDogXCJNb2V0IG1pbnN0ZW5zIDggdGVrZW5zIGJldmF0dGVuXCIgfX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPCEtLSA8cD5NYWtlIHN1cmUgeW91ciBwYXNzd29yZCBoYXMgdGhlIGZvbGxvd2luZzo8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzPVwiXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzcz1cImxpc3QtZGlzY1wiPnt7IGNoZWNrZXIuaGFzX2xvd2VyY2FzZSA/IFwiSGFzIGxvd2VyY2FzZSBsZXR0ZXJzXCIgOiBcIkhhcyBOTyBsb3dlcmNhc2UgbGV0dGVyc1wiIH19PC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzPVwibGlzdC1kaXNjXCI+e3sgY2hlY2tlci5oYXNfdXBwZXJjYXNlID8gXCJIYXMgdXBwZXJjYXNlIGxldHRlcnNcIiA6IFwiSGFzIE5PIHVwcGVyY2FzZSBsZXR0ZXJzXCIgfX08L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3M9XCJsaXN0LWRpc2NcIj57eyBjaGVja2VyLmhhc19udW1iZXIgPyBcIkhhcyBudW1iZXJzXCIgOiBcIkhhcyBOTyBudW1iZXJzXCIgfX08L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3M9XCJsaXN0LWRpc2NcIj57eyBjaGVja2VyLmhhc19zcGVjaWFsID8gXCJIYXMgc3BlY2lhbCBjaGFyYWN0ZXJzXCIgOiBcIkhhcyBOTyBzcGVjaWFsIGNoYXJhY3RlcnNcIiB9fTwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgPC91bD4gLS0+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJ3LWZ1bGwgcHktMiByb3VuZGVkLWxnIG1iLTggZm9udC1zZW1pYm9sZCBiZy1BY2NlbnRCbHVlIHRleHQtTWFpbldoaXRlXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBTaWduIHVwXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlckxpbmsgdG89XCIvYXV0aC9sb2dpblwiIGNsYXNzPVwiZm9udC1ub3JtYWwgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwPkRvIHlvdSBoYXZlIGFuIGFjY291bnQ/IDxzcGFuIGNsYXNzPVwidGV4dC1BY2NlbnRCbHVlXCI+TG9nIGluPC9zcGFuPjwvcD5cclxuICAgICAgICAgICAgICAgIDwvUm91dGVyTGluaz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGhyIGNsYXNzPVwidy1mdWxsIGgtcHggdHJhbnNsYXRlLXktMC41IG15LTggYmctQmdCbGFjayBib3JkZXItMFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJhYnNvbHV0ZSBweC0zIGZvbnQtbWVkaXVtIHRleHQtQmdCbGFjayAtdHJhbnNsYXRlLXgtMS8yIGJnLU1haW5XaGl0ZSBsZWZ0LTEvMlwiPm9yPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJvcmRlciBib3JkZXItQmdCbGFjayBweC02IHB5LTMgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3V0ZXJMaW5rIHRvPVwiL1wiIGNsYXNzPVwiXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPkNvbnRpbnVlIHdpdGhvdXQgbG9nZ2luZyBpbjwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L1JvdXRlckxpbms+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Zvcm0+XHJcbjwvdGVtcGxhdGU+XHJcblxyXG5cclxuPHNjcmlwdCBzZXR1cCBsYW5nPVwidHNcIj5cclxuICAgIGltcG9ydCB7IGNvbXB1dGVkLCByZWYgfSBmcm9tICd2dWUnXHJcbiAgICBpbXBvcnQgeyB0eXBlIEF1dGhFcnJvciB9IGZyb20gJ2ZpcmViYXNlL2F1dGgnXHJcblxyXG4gICAgaW1wb3J0IHVzZUZpcmViYXNlIGZyb20gJ0AvY29tcG9zYWJsZXMvdXNlRmlyZWJhc2UnXHJcbiAgICBpbXBvcnQgdXNlQ3VzdG9tVXNlciBmcm9tICdAL2NvbXBvc2FibGVzL3VzZUN1c3RvbVVzZXInXHJcbiAgICBpbXBvcnQgeyB1c2VNdXRhdGlvbiB9IGZyb20gJ0B2dWUvYXBvbGxvLWNvbXBvc2FibGUnXHJcbiAgICBpbXBvcnQgeyBBRERfVVNFUiB9IGZyb20gJ0AvZ3JhcGhxbC91c2VyLm11dGF0aW9uJ1xyXG4gICAgaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJ3Z1ZS1pMThuJ1xyXG4gICAgaW1wb3J0IHR5cGUgeyBDdXN0b21Vc2VyIH0gZnJvbSAnQC9pbnRlcmZhY2VzL3VzZXIuaW50ZXJmYWNlJ1xyXG4gICAgaW1wb3J0IHsgTG9hZGVyMiB9IGZyb20gJ2x1Y2lkZS12dWUtbmV4dCdcclxuICAgIGltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ3Z1ZS1yb3V0ZXInXHJcblxyXG5cclxuICAgIC8vIENvbXBvc2FibGVzXHJcbiAgICBjb25zdCB7IHJlZ2lzdGVyIH0gPSB1c2VGaXJlYmFzZSgpXHJcbiAgICBjb25zdCB7IGxvY2FsZSB9ID0gdXNlSTE4bigpXHJcbiAgICBjb25zdCB7IGN1c3RvbVVzZXIgfSA9IHVzZUN1c3RvbVVzZXIoKVxyXG4gICAgY29uc3QgeyByZXBsYWNlIH0gPSB1c2VSb3V0ZXIoKVxyXG5cclxuICAgIC8vTG9naWNcclxuICAgIGNvbnN0IGVycm9yID0gcmVmPEF1dGhFcnJvciB8IG51bGw+KG51bGwpXHJcbiAgICBjb25zdCBzdGFydFZhbGlkYXRpb24gPSByZWYoZmFsc2UpXHJcbiAgICBjb25zdCBzaG93RXJyb3IgPSByZWYoZmFsc2UpXHJcbiAgICBjb25zdCBuZXdVc2VyID0gcmVmKHtcclxuICAgICAgICBuYW1lOiAnJyxcclxuICAgICAgICBwYXNzd29yZDogJycsXHJcbiAgICAgICAgZW1haWw6ICcnLFxyXG4gICAgfSlcclxuICAgIGNvbnN0IGNoZWNrZXIgPSByZWYoe1xyXG4gICAgICAgIGhhc19udW1iZXI6IGZhbHNlLFxyXG4gICAgICAgIGhhc19sb3dlcmNhc2U6IGZhbHNlLFxyXG4gICAgICAgIGhhc191cHBlcmNhc2U6IGZhbHNlLFxyXG4gICAgICAgIGhhc19zcGVjaWFsOiBmYWxzZVxyXG4gICAgfSlcclxuXHJcbiAgICBjb25zdCB7IG11dGF0ZTogYWRkVXNlciwgbG9hZGluZzogYWRkVXNlckxvYWRpbmcgfSA9IHVzZU11dGF0aW9uPEN1c3RvbVVzZXI+KEFERF9VU0VSKVxyXG5cclxuICAgIGNvbnN0IGlzVmFsaWRFbWFpbCA9IChFbWFpbFBhcmFtZXRlciA6IHN0cmluZykgPT4ge1xyXG4gICAgICAgIHJldHVybiAvXlxcdysoW1xcLi1dP1xcdyspKkBcXHcrKFtcXC4tXT9cXHcrKSooXFwuXFx3ezIsM30pKyQvLnRlc3QoRW1haWxQYXJhbWV0ZXIpID8gdHJ1ZSAgOiBmYWxzZVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGlzU3Ryb25nUGFzc3dvcmQgPSAoUGFzc3dvcmRQYXJhbWV0ZXIgOiBzdHJpbmcpID0+IHtcclxuICAgICAgICBpZigvXFxkLy50ZXN0KFBhc3N3b3JkUGFyYW1ldGVyKSl7XHJcbiAgICAgICAgICAgIGNoZWNrZXIudmFsdWUuaGFzX251bWJlciA9IHRydWVcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgY2hlY2tlci52YWx1ZS5oYXNfbnVtYmVyID0gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYoL1thLXpdLy50ZXN0KFBhc3N3b3JkUGFyYW1ldGVyKSl7XHJcbiAgICAgICAgICAgIGNoZWNrZXIudmFsdWUuaGFzX2xvd2VyY2FzZSA9IHRydWVcclxuICAgICAgICB9IFxyXG4gICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgIGNoZWNrZXIudmFsdWUuaGFzX2xvd2VyY2FzZSA9IGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKC9bQS1aXS8udGVzdChQYXNzd29yZFBhcmFtZXRlcikpe1xyXG4gICAgICAgICAgICBjaGVja2VyLnZhbHVlLmhhc191cHBlcmNhc2UgPSB0cnVlXHJcbiAgICAgICAgfSBcclxuICAgICAgICBlbHNle1xyXG4gICAgICAgICAgICBjaGVja2VyLnZhbHVlLmhhc191cHBlcmNhc2UgPSBmYWxzZVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZigvWyFAI1xcJCVcXF5cXCYqXFwpXFwoKz0uXy1dLy50ZXN0KFBhc3N3b3JkUGFyYW1ldGVyKSl7XHJcbiAgICAgICAgICAgIGNoZWNrZXIudmFsdWUuaGFzX3NwZWNpYWwgPSB0cnVlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgIGNoZWNrZXIudmFsdWUuaGFzX3NwZWNpYWwgPSBmYWxzZVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGNvbnN0IHBhc3N3b3JkTGVuZ3RoID0gKFBhc3N3b3JkIDogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIFBhc3N3b3JkLmxlbmd0aCA+PSA4ID8gdHJ1ZSA6IGZhbHNlXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgaGFuZGxlUmVnaXN0ZXIgPSAoKSA9PiB7XHJcbiAgICAgICAgLy8gc3RhcnRWYWxpZGF0aW9uLnZhbHVlID0gdHJ1ZVxyXG4gICAgICAgIC8vIGlzU3Ryb25nUGFzc3dvcmQobmV3VXNlci52YWx1ZS5wYXNzd29yZClcclxuICAgICAgICBpZihpc1ZhbGlkRW1haWwobmV3VXNlci52YWx1ZS5lbWFpbCkgPT0gdHJ1ZSAmJiBwYXNzd29yZExlbmd0aChuZXdVc2VyLnZhbHVlLnBhc3N3b3JkKSA9PSB0cnVlKXtcclxuICAgICAgICAgICAgcmVnaXN0ZXIobmV3VXNlci52YWx1ZS5uYW1lLCBuZXdVc2VyLnZhbHVlLmVtYWlsLCBuZXdVc2VyLnZhbHVlLnBhc3N3b3JkKVxyXG4gICAgICAgICAgICAudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBhZGRVc2VyKHtcclxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVVc2VySW5wdXQ6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogbmV3VXNlci52YWx1ZS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbWFpbDogbmV3VXNlci52YWx1ZS5lbWFpbCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcm9sZTogXCJDTElFTlRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxlOiBsb2NhbGUudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIH0pLnRoZW4ocmVzdWx0ID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIXJlc3VsdD8uZGF0YSkgdGhyb3cgbmV3IEVycm9yKCdDdXN0b20gdXNlciBjcmVhdGlvbiBmYWlsZWQnKVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBjdXN0b21Vc2VyLnZhbHVlID0gcmVzdWx0LmRhdGFcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhuZXdVc2VyKVxyXG4gICAgICAgICAgICAgICAgICAgIHJlcGxhY2UoJy8nKVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgICAgICAgICBlcnJvci52YWx1ZSA9IGVyclxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNle1xyXG4gICAgICAgICAgICBzaG93RXJyb3IudmFsdWUgPSB0cnVlXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZW1haWwgb2YgcGFzc3dvcmQgaXMgbmlldCBnb2VkXCIpXHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuXHJcbjwvc2NyaXB0PiJdLCJmaWxlIjoiQzovQUZTRC9Lb2JlLUJlcnQvcGFja2FnZXMvcHdhL3NyYy92aWV3cy9hdXRoL3JlZ2lzdGVyLnZ1ZSJ9