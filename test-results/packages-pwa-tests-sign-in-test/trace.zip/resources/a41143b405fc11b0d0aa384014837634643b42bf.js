import.meta.env = {"VITE_apiKey":"AIzaSyDRyDZKvLHOsjdItTsl6IEqsGcFqtJ4KQo","VITE_authDomain":"pretpark-929b6.firebaseapp.com","VITE_projectId":"pretpark-929b6","VITE_storageBucket":"pretpark-929b6.appspot.com","VITE_messagingSenderId":"69976698416","VITE_appId":"1:69976698416:web:d23a0a7b80c81b6d4c07f5","VITE_measurementId":"G-2GQTGNKRSS","VITE_BACKEND_URL":"http://[::1]:3000/graphql","VITE_EMULATION":"true ","BASE_URL":"/","MODE":"development","DEV":true,"PROD":false,"SSR":false};import {
  from,
  createHttpLink,
  ApolloClient,
  InMemoryCache
} from "/node_modules/.vite/deps/@apollo_client_core.js?v=1470181e";
import { onError } from "/node_modules/.vite/deps/@apollo_client_link_error.js?v=1470181e";
import { logErrorMessages } from "/node_modules/.vite/deps/@vue_apollo-util.js?v=1470181e";
import { setContext } from "/node_modules/.vite/deps/@apollo_client_link_context.js?v=1470181e";
import useFirebase from "/src/composables/useFirebase.ts";
const { firebaseUser } = useFirebase();
const httpLink = createHttpLink({
  // uri: "http://[::1]:3000/graphql",
  uri: import.meta.env.VITE_BACKEND_URL,
  credentials: "same-origin"
});
const authLink = setContext(async (_, { headers }) => ({
  headers: {
    ...headers,
    authorization: firebaseUser.value ? `Bearer ${await firebaseUser.value.getIdToken()}` : ``
  }
}));
const errorLink = onError((error) => {
  if (import.meta.env.DEV)
    logErrorMessages(error);
});
const apolloClient = new ApolloClient({
  link: from([authLink, errorLink, httpLink]),
  cache: new InMemoryCache()
});
export default () => {
  return {
    apolloClient
  };
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZUdyYXBocWwudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICBmcm9tLFxyXG4gIGNyZWF0ZUh0dHBMaW5rLFxyXG4gIEFwb2xsb0NsaWVudCxcclxuICBJbk1lbW9yeUNhY2hlLFxyXG59IGZyb20gXCJAYXBvbGxvL2NsaWVudC9jb3JlXCJcclxuaW1wb3J0IHsgb25FcnJvciB9IGZyb20gXCJAYXBvbGxvL2NsaWVudC9saW5rL2Vycm9yXCJcclxuaW1wb3J0IHsgbG9nRXJyb3JNZXNzYWdlcyB9IGZyb20gXCJAdnVlL2Fwb2xsby11dGlsXCJcclxuaW1wb3J0IHsgc2V0Q29udGV4dCB9IGZyb20gXCJAYXBvbGxvL2NsaWVudC9saW5rL2NvbnRleHRcIlxyXG5cclxuaW1wb3J0IHVzZUZpcmViYXNlIGZyb20gXCIuL3VzZUZpcmViYXNlXCJcclxuXHJcbmNvbnN0IHsgZmlyZWJhc2VVc2VyIH0gPSB1c2VGaXJlYmFzZSgpXHJcblxyXG5jb25zdCBodHRwTGluayA9IGNyZWF0ZUh0dHBMaW5rKHtcclxuICAvLyB1cmk6IFwiaHR0cDovL1s6OjFdOjMwMDAvZ3JhcGhxbFwiLFxyXG4gIHVyaTogaW1wb3J0Lm1ldGEuZW52LlZJVEVfQkFDS0VORF9VUkwsXHJcbiAgY3JlZGVudGlhbHM6IFwic2FtZS1vcmlnaW5cIixcclxufSlcclxuXHJcbmNvbnN0IGF1dGhMaW5rID0gc2V0Q29udGV4dChhc3luYyAoXywgeyBoZWFkZXJzIH0pID0+ICh7XHJcbiAgaGVhZGVyczoge1xyXG4gICAgLi4uaGVhZGVycyxcclxuICAgIGF1dGhvcml6YXRpb246IGZpcmViYXNlVXNlci52YWx1ZVxyXG4gICAgICA/IGBCZWFyZXIgJHthd2FpdCBmaXJlYmFzZVVzZXIudmFsdWUuZ2V0SWRUb2tlbigpfWBcclxuICAgICAgOiBgYCxcclxuICB9LFxyXG59KSlcclxuXHJcbi8vIEhhbmRsZSBlcnJvcnNcclxuY29uc3QgZXJyb3JMaW5rID0gb25FcnJvcihlcnJvciA9PiB7XHJcbiAgaWYgKGltcG9ydC5tZXRhLmVudi5ERVYpIGxvZ0Vycm9yTWVzc2FnZXMoZXJyb3IpXHJcbn0pXHJcblxyXG5jb25zdCBhcG9sbG9DbGllbnQgPSBuZXcgQXBvbGxvQ2xpZW50KHtcclxuICBsaW5rOiBmcm9tKFthdXRoTGluaywgZXJyb3JMaW5rLCBodHRwTGlua10pLFxyXG4gIGNhY2hlOiBuZXcgSW5NZW1vcnlDYWNoZSgpLFxyXG59KVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgKCkgPT4ge1xyXG4gIHJldHVybiB7XHJcbiAgICBhcG9sbG9DbGllbnQsXHJcbiAgfVxyXG59XHJcbiJdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxFQUNFO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsT0FDSztBQUNQLFNBQVMsZUFBZTtBQUN4QixTQUFTLHdCQUF3QjtBQUNqQyxTQUFTLGtCQUFrQjtBQUUzQixPQUFPLGlCQUFpQjtBQUV4QixNQUFNLEVBQUUsYUFBYSxJQUFJLFlBQVk7QUFFckMsTUFBTSxXQUFXLGVBQWU7QUFBQTtBQUFBLEVBRTlCLEtBQUssWUFBWSxJQUFJO0FBQUEsRUFDckIsYUFBYTtBQUNmLENBQUM7QUFFRCxNQUFNLFdBQVcsV0FBVyxPQUFPLEdBQUcsRUFBRSxRQUFRLE9BQU87QUFBQSxFQUNyRCxTQUFTO0FBQUEsSUFDUCxHQUFHO0FBQUEsSUFDSCxlQUFlLGFBQWEsUUFDeEIsVUFBVSxNQUFNLGFBQWEsTUFBTSxXQUFXLENBQUMsS0FDL0M7QUFBQSxFQUNOO0FBQ0YsRUFBRTtBQUdGLE1BQU0sWUFBWSxRQUFRLFdBQVM7QUFDakMsTUFBSSxZQUFZLElBQUk7QUFBSyxxQkFBaUIsS0FBSztBQUNqRCxDQUFDO0FBRUQsTUFBTSxlQUFlLElBQUksYUFBYTtBQUFBLEVBQ3BDLE1BQU0sS0FBSyxDQUFDLFVBQVUsV0FBVyxRQUFRLENBQUM7QUFBQSxFQUMxQyxPQUFPLElBQUksY0FBYztBQUMzQixDQUFDO0FBRUQsZUFBZSxNQUFNO0FBQ25CLFNBQU87QUFBQSxJQUNMO0FBQUEsRUFDRjtBQUNGOyIsIm5hbWVzIjpbXX0=