import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/profile.vue");import { defineComponent as _defineComponent } from "/node_modules/.vite/deps/vue.js?v=1470181e";
import { useRouter } from "/node_modules/.vite/deps/vue-router.js?v=1470181e";
import { ref, computed } from "/node_modules/.vite/deps/vue.js?v=1470181e";
import useFirebase from "/src/composables/useFirebase.ts";
import { useI18n } from "/node_modules/.vite/deps/vue-i18n.js?v=1470181e";
import { GET_USER_BY_UID } from "/src/graphql/user.query.ts";
import { GET_ALL_STAFF } from "/src/graphql/allStaff.query.ts";
import { useQuery } from "/node_modules/.vite/deps/@vue_apollo-composable.js?v=1470181e";
import Button from "/src/components/generic/CtaButton.vue";
const _sfc_main = /* @__PURE__ */ _defineComponent({
  __name: "profile",
  setup(__props, { expose: __expose }) {
    __expose();
    const { firebaseUser, logout } = useFirebase();
    const { replace } = useRouter();
    const { locale } = useI18n();
    const userEditActive = ref(false);
    const admin = ref(false);
    const { result } = useQuery(GET_USER_BY_UID, { uid: firebaseUser.value?.uid });
    const userResult = computed(() => result.value);
    const resultStaff = useQuery(GET_ALL_STAFF);
    const staffResult = computed(() => resultStaff.result.value);
    const userInfo = ref({
      name: "",
      email: "",
      phoneNumber: "",
      fullName: ""
    });
    const items = [
      { werkdagen: "Monday", Start_uur: "13:30", Eind_uur: "18:30" },
      { werkdagen: "Tuesday", Start_uur: "13:30", Eind_uur: "18:30" },
      { werkdagen: "Wednesday", Start_uur: "09:30", Eind_uur: "13:30" },
      { werkdagen: "Thursday", Start_uur: "09:30", Eind_uur: "13:30" },
      { werkdagen: "Friday", Start_uur: "10:00", Eind_uur: "14:30" }
    ];
    const VakantieDagen = [
      { from: "02 april", to: "16 april" },
      { from: "15 july", to: "15 august" },
      { from: "20 december", to: "27 december" }
    ];
    const loggedIn = () => {
    };
    const logoutUser = () => {
      logout().then(() => {
        replace({ path: "/" });
      });
    };
    const __returned__ = { firebaseUser, logout, replace, locale, userEditActive, admin, result, userResult, resultStaff, staffResult, userInfo, items, VakantieDagen, loggedIn, logoutUser, Button };
    Object.defineProperty(__returned__, "__isScriptSetup", { enumerable: false, value: true });
    return __returned__;
  }
});
import { createElementVNode as _createElementVNode, toDisplayString as _toDisplayString, withCtx as _withCtx, openBlock as _openBlock, createBlock as _createBlock, createCommentVNode as _createCommentVNode, createTextVNode as _createTextVNode, createVNode as _createVNode, vModelText as _vModelText, withDirectives as _withDirectives, renderList as _renderList, Fragment as _Fragment, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=1470181e";
const _hoisted_1 = {
  key: 0,
  class: "flex text-center flex-col pb-8"
};
const _hoisted_2 = { class: "flex justify-center items-center mt-16 gap-8" };
const _hoisted_3 = /* @__PURE__ */ _createElementVNode(
  "img",
  {
    class: "rounded-full lg:w-1/7 self-center",
    src: "/src/components/img/coding-logo-design-template-free-vector.jpg",
    alt: ""
  },
  null,
  -1
  /* HOISTED */
);
const _hoisted_4 = { class: "flex flex-col gap-4" };
const _hoisted_5 = { class: "text-2xl font-medium text-left" };
const _hoisted_6 = /* @__PURE__ */ _createElementVNode(
  "p",
  null,
  "Edit",
  -1
  /* HOISTED */
);
const _hoisted_7 = /* @__PURE__ */ _createElementVNode(
  "p",
  null,
  "Save",
  -1
  /* HOISTED */
);
const _hoisted_8 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "inline-flex items-center justify-center w-full" },
  [
    /* @__PURE__ */ _createElementVNode("hr", { class: "w-3/4 h-px translate-y-0.5 my-8 bg-MainWhite border-0" })
  ],
  -1
  /* HOISTED */
);
const _hoisted_9 = { class: "flex justify-center" };
const _hoisted_10 = { class: "justify-between text-left flex flex-wrap w-8/12" };
const _hoisted_11 = { class: "w-[45%] flex flex-col" };
const _hoisted_12 = /* @__PURE__ */ _createElementVNode(
  "label",
  {
    for: "fullName",
    class: "mb-2"
  },
  "Full name:",
  -1
  /* HOISTED */
);
const _hoisted_13 = ["readonly", "placeholder"];
const _hoisted_14 = { class: "w-[45%] flex flex-col" };
const _hoisted_15 = /* @__PURE__ */ _createElementVNode(
  "label",
  {
    for: "email",
    class: "mb-2"
  },
  "Email:",
  -1
  /* HOISTED */
);
const _hoisted_16 = ["readonly", "placeholder"];
const _hoisted_17 = { class: "w-[45%] flex flex-col" };
const _hoisted_18 = /* @__PURE__ */ _createElementVNode(
  "label",
  {
    for: "phoneNumber",
    class: "mb-2"
  },
  "Phone number:",
  -1
  /* HOISTED */
);
const _hoisted_19 = ["readonly", "placeholder"];
const _hoisted_20 = { key: 0 };
const _hoisted_21 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "inline-flex items-center justify-center w-full" },
  [
    /* @__PURE__ */ _createElementVNode("hr", { class: "w-3/4 h-px translate-y-0.5 my-8 bg-MainWhite/15 border-0" })
  ],
  -1
  /* HOISTED */
);
const _hoisted_22 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "flex w-full justify-center mb-4" },
  [
    /* @__PURE__ */ _createElementVNode("h1", { class: "text-left w-3/4 font-semibold text-2xl" }, "When do I have to work?")
  ],
  -1
  /* HOISTED */
);
const _hoisted_23 = { class: "flex justify-center text-left" };
const _hoisted_24 = { class: "table-auto w-8/12" };
const _hoisted_25 = /* @__PURE__ */ _createElementVNode(
  "thead",
  { class: "" },
  [
    /* @__PURE__ */ _createElementVNode("tr", null, [
      /* @__PURE__ */ _createElementVNode("th", { class: "pr-8 pl-2 border-r pb-4" }, " Workdays "),
      /* @__PURE__ */ _createElementVNode("th", { class: "pr-8 pb-4 border-r pl-2" }, " Start "),
      /* @__PURE__ */ _createElementVNode("th", { class: "pr-8 pb-4 pl-2" }, " End ")
    ])
  ],
  -1
  /* HOISTED */
);
const _hoisted_26 = { class: "odd:bg-black/15" };
const _hoisted_27 = { class: "p-2 border-r" };
const _hoisted_28 = { class: "p-2 border-r" };
const _hoisted_29 = { class: "p-2" };
const _hoisted_30 = { key: 1 };
const _hoisted_31 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "inline-flex items-center justify-center w-full" },
  [
    /* @__PURE__ */ _createElementVNode("hr", { class: "w-3/4 h-px translate-y-0.5 my-8 bg-MainWhite/15 border-0" })
  ],
  -1
  /* HOISTED */
);
const _hoisted_32 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "flex w-full justify-center mb-4" },
  [
    /* @__PURE__ */ _createElementVNode("h1", { class: "text-left w-3/4 font-semibold text-2xl" }, "When do I have my vacation?")
  ],
  -1
  /* HOISTED */
);
const _hoisted_33 = { class: "flex justify-center text-left" };
const _hoisted_34 = { class: "table-auto w-8/12" };
const _hoisted_35 = /* @__PURE__ */ _createElementVNode(
  "thead",
  { class: "" },
  [
    /* @__PURE__ */ _createElementVNode("tr", null, [
      /* @__PURE__ */ _createElementVNode("th", { class: "pr-8 pl-2 pb-4 border-r" }, " Begin vacation "),
      /* @__PURE__ */ _createElementVNode("th", { class: "pr-8 pb-4 pl-2" }, " End vacation ")
    ])
  ],
  -1
  /* HOISTED */
);
const _hoisted_36 = { class: "odd:bg-black/15" };
const _hoisted_37 = { class: "border-r p-2" };
const _hoisted_38 = { class: "p-2" };
const _hoisted_39 = { key: 2 };
const _hoisted_40 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "inline-flex items-center justify-center w-full" },
  [
    /* @__PURE__ */ _createElementVNode("hr", { class: "w-3/4 h-px translate-y-0.5 my-8 bg-MainWhite/15 border-0" })
  ],
  -1
  /* HOISTED */
);
const _hoisted_41 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "flex w-full justify-center mb-4" },
  [
    /* @__PURE__ */ _createElementVNode("h1", { class: "text-left w-3/4 font-semibold text-2xl" }, "All staff members")
  ],
  -1
  /* HOISTED */
);
const _hoisted_42 = { class: "flex justify-center text-left" };
const _hoisted_43 = { class: "table-auto w-8/12" };
const _hoisted_44 = /* @__PURE__ */ _createElementVNode(
  "thead",
  { class: "" },
  [
    /* @__PURE__ */ _createElementVNode("tr", null, [
      /* @__PURE__ */ _createElementVNode("th", { class: "pr-8 pl-2 pb-4 border-r" }, " Name "),
      /* @__PURE__ */ _createElementVNode("th", { class: "pr-8 pb-4 pl-2 border-r" }, " Email "),
      /* @__PURE__ */ _createElementVNode("th", { class: "pr-8 pb-4 pl-2 border-r" }, " Phone number "),
      /* @__PURE__ */ _createElementVNode("th", { class: "pr-8 pb-4 pl-2 border-r" }, " Function "),
      /* @__PURE__ */ _createElementVNode("th", { class: "pr-8 pb-4 pl-2 border-r" }, " Job "),
      /* @__PURE__ */ _createElementVNode("th", { class: "pr-8 pb-4 pl-2" }, " Bruto income ")
    ])
  ],
  -1
  /* HOISTED */
);
const _hoisted_45 = { class: "odd:bg-black/15" };
const _hoisted_46 = { class: "border-r p-2" };
const _hoisted_47 = { class: "border-r p-2" };
const _hoisted_48 = { class: "border-r p-2" };
const _hoisted_49 = { class: "border-r p-2" };
const _hoisted_50 = { class: "border-r p-2" };
const _hoisted_51 = { class: "p-2" };
const _hoisted_52 = { key: 1 };
const _hoisted_53 = /* @__PURE__ */ _createElementVNode(
  "p",
  null,
  "Log in om een account te zien",
  -1
  /* HOISTED */
);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return $setup.userResult ? (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _createElementVNode("div", _hoisted_2, [
      _hoisted_3,
      _createElementVNode("div", _hoisted_4, [
        _createElementVNode(
          "p",
          _hoisted_5,
          _toDisplayString($setup.userResult.getUserByUid.name),
          1
          /* TEXT */
        ),
        !$setup.userEditActive ? (_openBlock(), _createBlock($setup["Button"], {
          key: 0,
          class: "text-sm",
          onClick: _cache[0] || (_cache[0] = ($event) => $setup.userEditActive = !$setup.userEditActive)
        }, {
          default: _withCtx(() => [
            _hoisted_6
          ]),
          _: 1
          /* STABLE */
        })) : (_openBlock(), _createBlock($setup["Button"], {
          key: 1,
          class: "text-sm",
          onClick: _cache[1] || (_cache[1] = ($event) => $setup.userEditActive = !$setup.userEditActive)
        }, {
          default: _withCtx(() => [
            _hoisted_7
          ]),
          _: 1
          /* STABLE */
        })),
        _createVNode($setup["Button"], { onClick: $setup.logoutUser }, {
          default: _withCtx(() => [
            _createTextVNode(
              _toDisplayString(_ctx.$t("Logout")),
              1
              /* TEXT */
            )
          ]),
          _: 1
          /* STABLE */
        })
      ])
    ]),
    _hoisted_8,
    _createElementVNode("div", _hoisted_9, [
      _createElementVNode("div", _hoisted_10, [
        _createElementVNode("div", _hoisted_11, [
          _hoisted_12,
          _withDirectives(_createElementVNode("input", {
            class: "mb-6 text-MainWhite border-MainWhite/50 bg-transparent border-2 p-4 rounded-full",
            type: "text",
            name: "fullName",
            id: "fullName",
            readonly: !$setup.userEditActive,
            placeholder: $setup.userResult.getUserByUid.fullName ? $setup.userResult.getUserByUid.fullName : "No full name found!",
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => $setup.userInfo.fullName = $event)
          }, null, 8, _hoisted_13), [
            [_vModelText, $setup.userInfo.fullName]
          ])
        ]),
        _createElementVNode("div", _hoisted_14, [
          _hoisted_15,
          _withDirectives(_createElementVNode("input", {
            class: "mb-6 text-MainWhite bg-transparent border-MainWhite/50 border-2 p-4 rounded-full",
            type: "text",
            name: "email",
            id: "email",
            readonly: !$setup.userEditActive,
            placeholder: $setup.userResult.getUserByUid.email ? $setup.userResult.getUserByUid.email : "No email found!",
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => $setup.userResult.getUserByUid.email = $event)
          }, null, 8, _hoisted_16), [
            [_vModelText, $setup.userResult.getUserByUid.email]
          ])
        ]),
        _createElementVNode("div", _hoisted_17, [
          _hoisted_18,
          _withDirectives(_createElementVNode("input", {
            class: "text-MainWhite border-MainWhite/50 bg-transparent border-2 p-4 rounded-full",
            type: "text",
            name: "phoneNumber",
            id: "phoneNumber",
            readonly: !$setup.userEditActive,
            "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => $setup.userInfo.phoneNumber = $event),
            placeholder: $setup.userResult.getUserByUid.phoneNumber ? $setup.userResult.getUserByUid.phoneNumber : "No phone number found!"
          }, null, 8, _hoisted_19), [
            [_vModelText, $setup.userInfo.phoneNumber]
          ])
        ])
      ])
    ]),
    _createCommentVNode(" werkuren "),
    $setup.userResult.getUserByUid.role == "STAFF" || $setup.userResult.getUserByUid.role == "ADMIN" ? (_openBlock(), _createElementBlock("section", _hoisted_20, [
      _hoisted_21,
      _hoisted_22,
      _createElementVNode("div", _hoisted_23, [
        _createElementVNode("table", _hoisted_24, [
          _hoisted_25,
          _createElementVNode("tbody", null, [
            (_openBlock(), _createElementBlock(
              _Fragment,
              null,
              _renderList($setup.items, (item) => {
                return _createElementVNode("tr", _hoisted_26, [
                  _createElementVNode(
                    "td",
                    _hoisted_27,
                    _toDisplayString(item.werkdagen),
                    1
                    /* TEXT */
                  ),
                  _createElementVNode(
                    "td",
                    _hoisted_28,
                    _toDisplayString(item.Start_uur),
                    1
                    /* TEXT */
                  ),
                  _createElementVNode(
                    "td",
                    _hoisted_29,
                    _toDisplayString(item.Eind_uur),
                    1
                    /* TEXT */
                  )
                ]);
              }),
              64
              /* STABLE_FRAGMENT */
            ))
          ])
        ])
      ])
    ])) : _createCommentVNode("v-if", true),
    _createCommentVNode(" VakantieDagen "),
    $setup.userResult.getUserByUid.role == "STAFF" || $setup.userResult.getUserByUid.role == "ADMIN" ? (_openBlock(), _createElementBlock("section", _hoisted_30, [
      _hoisted_31,
      _hoisted_32,
      _createElementVNode("div", _hoisted_33, [
        _createElementVNode("table", _hoisted_34, [
          _hoisted_35,
          _createElementVNode("tbody", null, [
            (_openBlock(), _createElementBlock(
              _Fragment,
              null,
              _renderList($setup.VakantieDagen, (item) => {
                return _createElementVNode("tr", _hoisted_36, [
                  _createElementVNode(
                    "td",
                    _hoisted_37,
                    _toDisplayString(item.from),
                    1
                    /* TEXT */
                  ),
                  _createElementVNode(
                    "td",
                    _hoisted_38,
                    _toDisplayString(item.to),
                    1
                    /* TEXT */
                  )
                ]);
              }),
              64
              /* STABLE_FRAGMENT */
            ))
          ])
        ])
      ])
    ])) : _createCommentVNode("v-if", true),
    _createCommentVNode(" List of all staffmembers (only visible when ADMIN) "),
    $setup.userResult.getUserByUid.role == "ADMIN" ? (_openBlock(), _createElementBlock("section", _hoisted_39, [
      _hoisted_40,
      _hoisted_41,
      _createElementVNode("div", _hoisted_42, [
        _createElementVNode("table", _hoisted_43, [
          _hoisted_44,
          _createElementVNode("tbody", null, [
            (_openBlock(true), _createElementBlock(
              _Fragment,
              null,
              _renderList($setup.staffResult.getAllStaff, (item) => {
                return _openBlock(), _createElementBlock("tr", _hoisted_45, [
                  _createElementVNode(
                    "td",
                    _hoisted_46,
                    _toDisplayString(item.name),
                    1
                    /* TEXT */
                  ),
                  _createElementVNode(
                    "td",
                    _hoisted_47,
                    _toDisplayString(item.email),
                    1
                    /* TEXT */
                  ),
                  _createElementVNode(
                    "td",
                    _hoisted_48,
                    _toDisplayString(item.phoneNumber ? item.phoneNumber : "No phone number"),
                    1
                    /* TEXT */
                  ),
                  _createElementVNode(
                    "td",
                    _hoisted_49,
                    _toDisplayString(item.role),
                    1
                    /* TEXT */
                  ),
                  _createElementVNode(
                    "td",
                    _hoisted_50,
                    _toDisplayString(item.job ? item.job : "No current job"),
                    1
                    /* TEXT */
                  ),
                  _createElementVNode(
                    "td",
                    _hoisted_51,
                    _toDisplayString(item.brutoMonthlyWage ? item.brutoMonthlyWage : "No income"),
                    1
                    /* TEXT */
                  )
                ]);
              }),
              256
              /* UNKEYED_FRAGMENT */
            ))
          ])
        ])
      ])
    ])) : _createCommentVNode("v-if", true)
  ])) : (_openBlock(), _createElementBlock("div", _hoisted_52, [
    _hoisted_53,
    _createVNode($setup["Button"], { onClick: $setup.logoutUser }, {
      default: _withCtx(() => [
        _createTextVNode(
          _toDisplayString(_ctx.$t("Logout")),
          1
          /* TEXT */
        )
      ]),
      _: 1
      /* STABLE */
    })
  ]));
}
_sfc_main.__hmrId = "5542c8fc";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.accept((mod) => {
  if (!mod)
    return;
  const { default: updated, _rerender_only } = mod;
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
  }
});
import _export_sfc from "/@id/__x00__plugin-vue:export-helper";
export default /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "C:/AFSD/Kobe-Bert/packages/pwa/src/views/profile.vue"]]);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQWdNSSxTQUFTLGlCQUFpQjtBQUMxQixTQUFRLEtBQUssZ0JBQWdCO0FBRTdCLE9BQU8saUJBQWlCO0FBQ3hCLFNBQVMsZUFBZTtBQUN4QixTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLGdCQUFnQjtBQUN6QixPQUFPLFlBQVk7Ozs7O0FBTW5CLFVBQU0sRUFBRSxjQUFjLE9BQU8sSUFBSSxZQUFZO0FBQzdDLFVBQU0sRUFBRSxRQUFRLElBQUksVUFBVTtBQUM5QixVQUFNLEVBQUUsT0FBTyxJQUFJLFFBQVE7QUFDM0IsVUFBTSxpQkFBaUIsSUFBSSxLQUFLO0FBQ2hDLFVBQU0sUUFBUSxJQUFJLEtBQUs7QUFFdkIsVUFBTSxFQUFFLE9BQU8sSUFBSSxTQUFTLGlCQUFpQixFQUFDLEtBQUssYUFBYSxPQUFPLElBQUcsQ0FBQztBQUMzRSxVQUFNLGFBQWEsU0FBUyxNQUFNLE9BQU8sS0FBSztBQUU5QyxVQUFNLGNBQWMsU0FBUyxhQUFhO0FBQzFDLFVBQU0sY0FBYyxTQUFTLE1BQU0sWUFBWSxPQUFPLEtBQUs7QUFJM0QsVUFBTSxXQUFXLElBQUk7QUFBQSxNQUNqQixNQUFNO0FBQUEsTUFDTixPQUFPO0FBQUEsTUFDUCxhQUFhO0FBQUEsTUFDYixVQUFVO0FBQUEsSUFDZCxDQUFDO0FBRUQsVUFBTSxRQUFRO0FBQUEsTUFDVixFQUFFLFdBQVcsVUFBVSxXQUFXLFNBQVMsVUFBVSxRQUFRO0FBQUEsTUFDN0QsRUFBRSxXQUFXLFdBQVcsV0FBVyxTQUFTLFVBQVUsUUFBUTtBQUFBLE1BQzlELEVBQUUsV0FBVyxhQUFhLFdBQVcsU0FBUyxVQUFVLFFBQVE7QUFBQSxNQUNoRSxFQUFFLFdBQVcsWUFBWSxXQUFXLFNBQVMsVUFBVSxRQUFRO0FBQUEsTUFDL0QsRUFBRSxXQUFXLFVBQVUsV0FBVyxTQUFTLFVBQVUsUUFBUTtBQUFBLElBQ2pFO0FBRUEsVUFBTSxnQkFBZ0I7QUFBQSxNQUNsQixFQUFDLE1BQU0sWUFBWSxJQUFJLFdBQVU7QUFBQSxNQUNqQyxFQUFDLE1BQU0sV0FBVyxJQUFJLFlBQVc7QUFBQSxNQUNqQyxFQUFDLE1BQU0sZUFBZSxJQUFJLGNBQWE7QUFBQSxJQUMzQztBQUVBLFVBQU0sV0FBVyxNQUFNO0FBQUEsSUFFdkI7QUFHQSxVQUFNLGFBQWEsTUFBTTtBQUNyQixhQUFPLEVBQUUsS0FBSyxNQUFNO0FBQ2hCLGdCQUFRLEVBQUMsTUFBTSxJQUFHLENBQUM7QUFBQSxNQUN2QixDQUFDO0FBQUEsSUFDTDs7Ozs7Ozs7O0VBelB1QixPQUFNOztxQkFDcEIsT0FBTSwrQ0FBOEM7bUJBQ3JEO0FBQUEsRUFBMEg7QUFBQTtBQUFBLElBQXJILE9BQU07QUFBQSxJQUFvQyxLQUFJO0FBQUEsSUFBZ0UsS0FBSTtBQUFBOzs7OztxQkFDbEgsT0FBTSxzQkFBcUI7cUJBQ3pCLE9BQU0saUNBQWdDO21CQUVyQztBQUFBLEVBQVc7QUFBQTtBQUFBLEVBQVI7QUFBQSxFQUFJO0FBQUE7QUFBQTttQkFHUDtBQUFBLEVBQVc7QUFBQTtBQUFBLEVBQVI7QUFBQSxFQUFJO0FBQUE7QUFBQTttQkFRbkI7QUFBQSxFQUVNO0FBQUEsSUFGRCxPQUFNLGlEQUFnRDtBQUFBO0FBQUEsSUFDdkQsb0NBQWtFLFFBQTlELE9BQU0sd0RBQXVEO0FBQUE7Ozs7cUJBR2hFLE9BQU0sc0JBQXFCO3NCQUN2QixPQUFNLGtEQUFpRDtzQkFFbkQsT0FBTSx3QkFBdUI7b0JBQzlCO0FBQUEsRUFBcUQ7QUFBQTtBQUFBLElBQTlDLEtBQUk7QUFBQSxJQUFXLE9BQU07QUFBQTtFQUFPO0FBQUEsRUFBVTtBQUFBO0FBQUE7O3NCQVk1QyxPQUFNLHdCQUF1QjtvQkFDOUI7QUFBQSxFQUE4QztBQUFBO0FBQUEsSUFBdkMsS0FBSTtBQUFBLElBQVEsT0FBTTtBQUFBO0VBQU87QUFBQSxFQUFNO0FBQUE7QUFBQTs7c0JBY3JDLE9BQU0sd0JBQXVCO29CQUM5QjtBQUFBLEVBQTJEO0FBQUE7QUFBQSxJQUFwRCxLQUFJO0FBQUEsSUFBYyxPQUFNO0FBQUE7RUFBTztBQUFBLEVBQWE7QUFBQTtBQUFBOzs7b0JBZ0IzRDtBQUFBLEVBRU07QUFBQSxJQUZELE9BQU0saURBQWdEO0FBQUE7QUFBQSxJQUN2RCxvQ0FBcUUsUUFBakUsT0FBTSwyREFBMEQ7QUFBQTs7OztvQkFFeEU7QUFBQSxFQUVNO0FBQUEsSUFGRCxPQUFNLGtDQUFpQztBQUFBO0FBQUEsSUFDeEMsb0NBQStFLFFBQTNFLE9BQU0seUNBQXdDLEdBQUMseUJBQXVCO0FBQUE7Ozs7c0JBR3pFLE9BQU0sZ0NBQStCO3NCQUMvQixPQUFNLG9CQUFtQjtvQkFDNUI7QUFBQSxFQVlRO0FBQUEsSUFaRCxPQUFNLEdBQUU7QUFBQTtBQUFBLElBQ1gsb0NBVUs7QUFBQSxNQVRELG9DQUVLLFFBRkQsT0FBTSwwQkFBeUIsR0FBQyxZQUVwQztBQUFBLE1BQ0Esb0NBRUssUUFGRCxPQUFNLDBCQUF5QixHQUFDLFNBRXBDO0FBQUEsTUFDQSxvQ0FFSyxRQUZELE9BQU0saUJBQWdCLEdBQUMsT0FFM0I7QUFBQTs7Ozs7c0JBSXNCLE9BQU0sa0JBQWlCO3NCQUN6QyxPQUFNLGVBQWM7c0JBQ3BCLE9BQU0sZUFBYztzQkFDcEIsT0FBTSxNQUFLOztvQkFTL0I7QUFBQSxFQUVNO0FBQUEsSUFGRCxPQUFNLGlEQUFnRDtBQUFBO0FBQUEsSUFDdkQsb0NBQXFFLFFBQWpFLE9BQU0sMkRBQTBEO0FBQUE7Ozs7b0JBR3hFO0FBQUEsRUFFTTtBQUFBLElBRkQsT0FBTSxrQ0FBaUM7QUFBQTtBQUFBLElBQ3hDLG9DQUFtRixRQUEvRSxPQUFNLHlDQUF3QyxHQUFDLDZCQUEyQjtBQUFBOzs7O3NCQUc3RSxPQUFNLGdDQUErQjtzQkFDL0IsT0FBTSxvQkFBbUI7b0JBQzVCO0FBQUEsRUFTUTtBQUFBLElBVEQsT0FBTSxHQUFFO0FBQUE7QUFBQSxJQUNYLG9DQU9LO0FBQUEsTUFORCxvQ0FFSyxRQUZELE9BQU0sMEJBQXlCLEdBQUMsa0JBRXBDO0FBQUEsTUFDQSxvQ0FFSyxRQUZELE9BQU0saUJBQWdCLEdBQUMsZ0JBRTNCO0FBQUE7Ozs7O3NCQUk4QixPQUFNLGtCQUFpQjtzQkFDakQsT0FBTSxlQUFjO3NCQUNwQixPQUFNLE1BQUs7O29CQVMvQjtBQUFBLEVBRU07QUFBQSxJQUZELE9BQU0saURBQWdEO0FBQUE7QUFBQSxJQUN2RCxvQ0FBcUUsUUFBakUsT0FBTSwyREFBMEQ7QUFBQTs7OztvQkFHeEU7QUFBQSxFQUVNO0FBQUEsSUFGRCxPQUFNLGtDQUFpQztBQUFBO0FBQUEsSUFDeEMsb0NBQXlFLFFBQXJFLE9BQU0seUNBQXdDLEdBQUMsbUJBQWlCO0FBQUE7Ozs7c0JBR25FLE9BQU0sZ0NBQStCO3NCQUMvQixPQUFNLG9CQUFtQjtvQkFDNUI7QUFBQSxFQXFCUTtBQUFBLElBckJELE9BQU0sR0FBRTtBQUFBO0FBQUEsSUFDWCxvQ0FtQks7QUFBQSxNQWxCRCxvQ0FFSyxRQUZELE9BQU0sMEJBQXlCLEdBQUMsUUFFcEM7QUFBQSxNQUNBLG9DQUVLLFFBRkQsT0FBTSwwQkFBeUIsR0FBQyxTQUVwQztBQUFBLE1BQ0Esb0NBRUssUUFGRCxPQUFNLDBCQUF5QixHQUFDLGdCQUVwQztBQUFBLE1BQ0Esb0NBRUssUUFGRCxPQUFNLDBCQUF5QixHQUFDLFlBRXBDO0FBQUEsTUFDQSxvQ0FFSyxRQUZELE9BQU0sMEJBQXlCLEdBQUMsT0FFcEM7QUFBQSxNQUNBLG9DQUVLLFFBRkQsT0FBTSxpQkFBZ0IsR0FBQyxnQkFFM0I7QUFBQTs7Ozs7c0JBSXdDLE9BQU0sa0JBQWlCO3NCQUMzRCxPQUFNLGVBQWM7c0JBQ3BCLE9BQU0sZUFBYztzQkFDcEIsT0FBTSxlQUFjO3NCQUNwQixPQUFNLGVBQWM7c0JBQ3BCLE9BQU0sZUFBYztzQkFDcEIsT0FBTSxNQUFLOztvQkFRbkM7QUFBQSxFQUFvQztBQUFBO0FBQUEsRUFBakM7QUFBQSxFQUE2QjtBQUFBO0FBQUE7O1NBdkx6QixtQ0FBWCxvQkFxTE0sT0FyTE4sWUFxTE07QUFBQSxJQXBMRixvQkFjTSxPQWROLFlBY007QUFBQSxNQWJGO0FBQUEsTUFDQSxvQkFXTSxPQVhOLFlBV007QUFBQSxRQVZGO0FBQUEsVUFBZ0Y7QUFBQSxVQUFoRjtBQUFBLFVBQWdGLGlCQUFuQyxrQkFBVyxhQUFhLElBQUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUMxRCx1Q0FBZixhQUVTO0FBQUE7VUFGc0IsT0FBTTtBQUFBLFVBQVcsU0FBSyxzQ0FBRSx3QkFBYyxDQUFJO0FBQUE7NEJBQ3JFLE1BQVc7QUFBQSxZQUFYO0FBQUE7Ozs2QkFFSixhQUVTO0FBQUE7VUFGTSxPQUFNO0FBQUEsVUFBVyxTQUFLLHNDQUFFLHdCQUFjLENBQUk7QUFBQTs0QkFDckQsTUFBVztBQUFBLFlBQVg7QUFBQTs7OztRQUVKLGFBRVMsb0JBRkEsU0FBTyxrQkFBVTtBQUFBLDRCQUN0QixNQUFrQjtBQUFBOytCQUFmLFFBQUU7QUFBQTtBQUFBO0FBQUE7QUFBQTs7Ozs7O0lBS2pCO0FBQUEsSUFJQSxvQkE0Q00sT0E1Q04sWUE0Q007QUFBQSxNQTNDRixvQkEwQ00sT0ExQ04sYUEwQ007QUFBQSxRQXhDRixvQkFXTSxPQVhOLGFBV007QUFBQSxVQVZGO0FBQUEsMEJBQ0Esb0JBUUU7QUFBQSxZQVBFLE9BQU07QUFBQSxZQUNOLE1BQUs7QUFBQSxZQUNMLE1BQUs7QUFBQSxZQUNMLElBQUc7QUFBQSxZQUNJLFVBQVEsQ0FBRztBQUFBLFlBQ1gsYUFBYSxrQkFBVyxhQUFhLFdBQVcsa0JBQVcsYUFBYSxXQUFRO0FBQUEseUVBQzlFLGdCQUFTLFdBQVE7QUFBQTswQkFBakIsZ0JBQVMsUUFBUTtBQUFBOztRQUlsQyxvQkFXTSxPQVhOLGFBV007QUFBQSxVQVZGO0FBQUEsMEJBQ0Esb0JBUUU7QUFBQSxZQVBFLE9BQU07QUFBQSxZQUNOLE1BQUs7QUFBQSxZQUNMLE1BQUs7QUFBQSxZQUNMLElBQUc7QUFBQSxZQUNJLFVBQVEsQ0FBRztBQUFBLFlBQ1gsYUFBYSxrQkFBVyxhQUFhLFFBQVEsa0JBQVcsYUFBYSxRQUFLO0FBQUEseUVBQ3hFLGtCQUFXLGFBQWEsUUFBSztBQUFBOzBCQUE3QixrQkFBVyxhQUFhLEtBQUs7QUFBQTs7UUFNOUMsb0JBV00sT0FYTixhQVdNO0FBQUEsVUFWRjtBQUFBLDBCQUNBLG9CQVFFO0FBQUEsWUFQRSxPQUFNO0FBQUEsWUFDTixNQUFLO0FBQUEsWUFDTCxNQUFLO0FBQUEsWUFDTCxJQUFHO0FBQUEsWUFDSSxVQUFRLENBQUc7QUFBQSx5RUFDVCxnQkFBUyxjQUFXO0FBQUEsWUFDdEIsYUFBYSxrQkFBVyxhQUFhLGNBQWMsa0JBQVcsYUFBYSxjQUFXO0FBQUE7MEJBRHBGLGdCQUFTLFdBQVc7QUFBQTs7OztJQU83QztBQUFBLElBQ2Usa0JBQVcsYUFBYSxRQUFJLFdBQWUsa0JBQVcsYUFBYSxRQUFJLHlCQUF0RixvQkFnQ1U7QUFBQSxNQS9CTjtBQUFBLE1BR0E7QUFBQSxNQUlBLG9CQXVCTSxPQXZCTixhQXVCTTtBQUFBLFFBdEJGLG9CQXFCUSxTQXJCUixhQXFCUTtBQUFBLFVBcEJKO0FBQUEsVUFhQSxvQkFNUTtBQUFBLDJCQUxKO0FBQUEsY0FJSztBQUFBO0FBQUEsMEJBSmMsY0FBSyxDQUFiLFNBQUk7dUJBQWYsb0JBSUssTUFKTCxhQUlLO0FBQUEsa0JBSEQ7QUFBQSxvQkFBa0Q7QUFBQSxvQkFBbEQ7QUFBQSxvQkFBa0QsaUJBQXRCLEtBQUssU0FBUztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUMxQztBQUFBLG9CQUFrRDtBQUFBLG9CQUFsRDtBQUFBLG9CQUFrRCxpQkFBdEIsS0FBSyxTQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQzFDO0FBQUEsb0JBQXdDO0FBQUEsb0JBQXhDO0FBQUEsb0JBQXdDLGlCQUFyQixLQUFLLFFBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7O0lBT3BEO0FBQUEsSUFDZSxrQkFBVyxhQUFhLFFBQUksV0FBZSxrQkFBVyxhQUFhLFFBQUkseUJBQXRGLG9CQTZCVTtBQUFBLE1BNUJOO0FBQUEsTUFJQTtBQUFBLE1BSUEsb0JBbUJNLE9BbkJOLGFBbUJNO0FBQUEsUUFsQkYsb0JBaUJRLFNBakJSLGFBaUJRO0FBQUEsVUFoQko7QUFBQSxVQVVBLG9CQUtRO0FBQUEsMkJBSko7QUFBQSxjQUdLO0FBQUE7QUFBQSwwQkFIYyxzQkFBYSxDQUFyQixTQUFJO3VCQUFmLG9CQUdLLE1BSEwsYUFHSztBQUFBLGtCQUZEO0FBQUEsb0JBQTZDO0FBQUEsb0JBQTdDO0FBQUEsb0JBQTZDLGlCQUFqQixLQUFLLElBQUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDckM7QUFBQSxvQkFBa0M7QUFBQSxvQkFBbEM7QUFBQSxvQkFBa0MsaUJBQWYsS0FBSyxFQUFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7Ozs7Ozs7OztJQU85QztBQUFBLElBQ2Usa0JBQVcsYUFBYSxRQUFJLHlCQUEzQyxvQkE2Q1U7QUFBQSxNQTVDTjtBQUFBLE1BSUE7QUFBQSxNQUlBLG9CQW1DTSxPQW5DTixhQW1DTTtBQUFBLFFBbENGLG9CQWlDUSxTQWpDUixhQWlDUTtBQUFBLFVBaENKO0FBQUEsVUFzQkEsb0JBU1E7QUFBQSwrQkFSSjtBQUFBLGNBT0s7QUFBQTtBQUFBLDBCQVBjLG1CQUFZLGFBQVcsQ0FBL0IsU0FBSTtxQ0FBZixvQkFPSyxNQVBMLGFBT0s7QUFBQSxrQkFORDtBQUFBLG9CQUE2QztBQUFBLG9CQUE3QztBQUFBLG9CQUE2QyxpQkFBakIsS0FBSyxJQUFJO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQ3JDO0FBQUEsb0JBQThDO0FBQUEsb0JBQTlDO0FBQUEsb0JBQThDLGlCQUFsQixLQUFLLEtBQUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDdEM7QUFBQSxvQkFBMkY7QUFBQSxvQkFBM0Y7QUFBQSxvQkFBMkYsaUJBQS9ELEtBQUssY0FBYyxLQUFLLGNBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDL0Q7QUFBQSxvQkFBNkM7QUFBQSxvQkFBN0M7QUFBQSxvQkFBNkMsaUJBQWpCLEtBQUssSUFBSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUNyQztBQUFBLG9CQUEwRTtBQUFBLG9CQUExRTtBQUFBLG9CQUEwRSxpQkFBOUMsS0FBSyxNQUFNLEtBQUssTUFBRztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUMvQztBQUFBLG9CQUFzRjtBQUFBLG9CQUF0RjtBQUFBLG9CQUFzRixpQkFBbkUsS0FBSyxtQkFBbUIsS0FBSyxtQkFBZ0I7QUFBQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7O3VCQU94RixvQkFLTTtBQUFBLElBSkY7QUFBQSxJQUNBLGFBRVMsb0JBRkEsU0FBTyxrQkFBVTtBQUFBLHdCQUN0QixNQUFrQjtBQUFBOzJCQUFmLFFBQUU7QUFBQTtBQUFBO0FBQUE7QUFBQSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJwcm9maWxlLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XHJcbiAgICA8ZGl2IHYtaWY9XCJ1c2VyUmVzdWx0XCIgY2xhc3M9XCJmbGV4IHRleHQtY2VudGVyIGZsZXgtY29sIHBiLThcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgbXQtMTYgZ2FwLThcIj5cclxuICAgICAgICAgICAgPGltZyBjbGFzcz1cInJvdW5kZWQtZnVsbCBsZzp3LTEvNyBzZWxmLWNlbnRlclwiIHNyYz1cIi4uL2NvbXBvbmVudHMvaW1nL2NvZGluZy1sb2dvLWRlc2lnbi10ZW1wbGF0ZS1mcmVlLXZlY3Rvci5qcGdcIiBhbHQ9XCJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZmxleC1jb2wgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC0yeGwgZm9udC1tZWRpdW0gdGV4dC1sZWZ0XCI+e3sgdXNlclJlc3VsdC5nZXRVc2VyQnlVaWQubmFtZSB9fTwvcD5cclxuICAgICAgICAgICAgICAgIDxCdXR0b24gdi1pZj1cIiF1c2VyRWRpdEFjdGl2ZVwiIGNsYXNzPVwidGV4dC1zbVwiIEBjbGljaz1cInVzZXJFZGl0QWN0aXZlID0gIXVzZXJFZGl0QWN0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHA+RWRpdDwvcD5cclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiB2LWVsc2UgY2xhc3M9XCJ0ZXh0LXNtXCIgQGNsaWNrPVwidXNlckVkaXRBY3RpdmUgPSAhdXNlckVkaXRBY3RpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cD5TYXZlPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uIEBjbGljaz1cImxvZ291dFVzZXJcIiA+XHJcbiAgICAgICAgICAgICAgICAgICAge3sgJHQoJ0xvZ291dCcpIH19XHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj4gXHJcbiAgICAgICAgICAgIDwvZGl2PiBcclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgPGhyIGNsYXNzPVwidy0zLzQgaC1weCB0cmFuc2xhdGUteS0wLjUgbXktOCBiZy1NYWluV2hpdGUgYm9yZGVyLTBcIj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImZsZXgganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImp1c3RpZnktYmV0d2VlbiB0ZXh0LWxlZnQgZmxleCBmbGV4LXdyYXAgdy04LzEyXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctWzQ1JV0gZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJmdWxsTmFtZVwiIGNsYXNzPVwibWItMlwiPkZ1bGwgbmFtZTo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJtYi02IHRleHQtTWFpbldoaXRlIGJvcmRlci1NYWluV2hpdGUvNTAgYmctdHJhbnNwYXJlbnQgYm9yZGVyLTIgcC00IHJvdW5kZWQtZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImZ1bGxOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJmdWxsTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHYtYmluZDpyZWFkb25seT1cIiF1c2VyRWRpdEFjdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHYtYmluZDpwbGFjZWhvbGRlcj0ndXNlclJlc3VsdC5nZXRVc2VyQnlVaWQuZnVsbE5hbWUgPyB1c2VyUmVzdWx0LmdldFVzZXJCeVVpZC5mdWxsTmFtZSA6IFwiTm8gZnVsbCBuYW1lIGZvdW5kIVwiJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2LW1vZGVsPVwidXNlckluZm8uZnVsbE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy1bNDUlXSBmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGZvcj1cImVtYWlsXCIgY2xhc3M9XCJtYi0yXCI+RW1haWw6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwibWItNiB0ZXh0LU1haW5XaGl0ZSBiZy10cmFuc3BhcmVudCBib3JkZXItTWFpbldoaXRlLzUwIGJvcmRlci0yIHAtNCByb3VuZGVkLWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2LWJpbmQ6cmVhZG9ubHk9XCIhdXNlckVkaXRBY3RpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2LWJpbmQ6cGxhY2Vob2xkZXI9J3VzZXJSZXN1bHQuZ2V0VXNlckJ5VWlkLmVtYWlsID8gdXNlclJlc3VsdC5nZXRVc2VyQnlVaWQuZW1haWwgOiBcIk5vIGVtYWlsIGZvdW5kIVwiJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2LW1vZGVsPVwidXNlclJlc3VsdC5nZXRVc2VyQnlVaWQuZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcblxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LVs0NSVdIGZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwicGhvbmVOdW1iZXJcIiBjbGFzcz1cIm1iLTJcIj5QaG9uZSBudW1iZXI6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwidGV4dC1NYWluV2hpdGUgYm9yZGVyLU1haW5XaGl0ZS81MCBiZy10cmFuc3BhcmVudCBib3JkZXItMiBwLTQgcm91bmRlZC1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGhvbmVOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInBob25lTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdi1iaW5kOnJlYWRvbmx5PVwiIXVzZXJFZGl0QWN0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdi1tb2RlbD1cInVzZXJJbmZvLnBob25lTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdi1iaW5kOnBsYWNlaG9sZGVyPSd1c2VyUmVzdWx0LmdldFVzZXJCeVVpZC5waG9uZU51bWJlciA/IHVzZXJSZXN1bHQuZ2V0VXNlckJ5VWlkLnBob25lTnVtYmVyIDogXCJObyBwaG9uZSBudW1iZXIgZm91bmQhXCInXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj4gICBcclxuXHJcbiAgICAgICAgPCEtLSB3ZXJrdXJlbiAtLT5cclxuICAgICAgICA8c2VjdGlvbiB2LWlmPVwidXNlclJlc3VsdC5nZXRVc2VyQnlVaWQucm9sZSA9PSAnU1RBRkYnIHx8IHVzZXJSZXN1bHQuZ2V0VXNlckJ5VWlkLnJvbGUgPT0gJ0FETUlOJ1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGhyIGNsYXNzPVwidy0zLzQgaC1weCB0cmFuc2xhdGUteS0wLjUgbXktOCBiZy1NYWluV2hpdGUvMTUgYm9yZGVyLTBcIj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IHctZnVsbCBqdXN0aWZ5LWNlbnRlciBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDEgY2xhc3M9XCJ0ZXh0LWxlZnQgdy0zLzQgZm9udC1zZW1pYm9sZCB0ZXh0LTJ4bFwiPldoZW4gZG8gSSBoYXZlIHRvIHdvcms/PC9oMT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBqdXN0aWZ5LWNlbnRlciB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlLWF1dG8gdy04LzEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzPVwiXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzcz1cInByLTggcGwtMiBib3JkZXItciBwYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgV29ya2RheXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJwci04IHBiLTQgYm9yZGVyLXIgcGwtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN0YXJ0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzPVwicHItOCBwYi00IHBsLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFbmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ciB2LWZvcj1cIml0ZW0gaW4gaXRlbXNcIiBjbGFzcz1cIm9kZDpiZy1ibGFjay8xNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzPVwicC0yIGJvcmRlci1yXCI+e3sgaXRlbS53ZXJrZGFnZW4gfX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzPVwicC0yIGJvcmRlci1yXCI+e3sgaXRlbS5TdGFydF91dXIgfX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzPVwicC0yXCI+e3sgaXRlbS5FaW5kX3V1ciB9fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgIDwvZGl2PiAgXHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgICA8IS0tIFZha2FudGllRGFnZW4gLS0+XHJcbiAgICAgICAgPHNlY3Rpb24gdi1pZj1cInVzZXJSZXN1bHQuZ2V0VXNlckJ5VWlkLnJvbGUgPT0gJ1NUQUZGJyB8fCB1c2VyUmVzdWx0LmdldFVzZXJCeVVpZC5yb2xlID09ICdBRE1JTidcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxociBjbGFzcz1cInctMy80IGgtcHggdHJhbnNsYXRlLXktMC41IG15LTggYmctTWFpbldoaXRlLzE1IGJvcmRlci0wXCI+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggdy1mdWxsIGp1c3RpZnktY2VudGVyIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzcz1cInRleHQtbGVmdCB3LTMvNCBmb250LXNlbWlib2xkIHRleHQtMnhsXCI+V2hlbiBkbyBJIGhhdmUgbXkgdmFjYXRpb24/PC9oMT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBqdXN0aWZ5LWNlbnRlciB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlLWF1dG8gdy04LzEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzPVwiXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzcz1cInByLTggcGwtMiBwYi00IGJvcmRlci1yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQmVnaW4gdmFjYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJwci04IHBiLTQgcGwtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVuZCB2YWNhdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyIHYtZm9yPVwiaXRlbSBpbiBWYWthbnRpZURhZ2VuXCIgY2xhc3M9XCJvZGQ6YmctYmxhY2svMTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cImJvcmRlci1yIHAtMlwiPnt7IGl0ZW0uZnJvbSB9fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJwLTJcIj57eyBpdGVtLnRvIH19PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgPC9kaXY+ICBcclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPCEtLSBMaXN0IG9mIGFsbCBzdGFmZm1lbWJlcnMgKG9ubHkgdmlzaWJsZSB3aGVuIEFETUlOKSAtLT5cclxuICAgICAgICA8c2VjdGlvbiB2LWlmPVwidXNlclJlc3VsdC5nZXRVc2VyQnlVaWQucm9sZSA9PSAnQURNSU4nXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8aHIgY2xhc3M9XCJ3LTMvNCBoLXB4IHRyYW5zbGF0ZS15LTAuNSBteS04IGJnLU1haW5XaGl0ZS8xNSBib3JkZXItMFwiPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IHctZnVsbCBqdXN0aWZ5LWNlbnRlciBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDEgY2xhc3M9XCJ0ZXh0LWxlZnQgdy0zLzQgZm9udC1zZW1pYm9sZCB0ZXh0LTJ4bFwiPkFsbCBzdGFmZiBtZW1iZXJzPC9oMT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBqdXN0aWZ5LWNlbnRlciB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlLWF1dG8gdy04LzEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzPVwiXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzcz1cInByLTggcGwtMiBwYi00IGJvcmRlci1yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzcz1cInByLTggcGItNCBwbC0yIGJvcmRlci1yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRW1haWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJwci04IHBiLTQgcGwtMiBib3JkZXItclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBob25lIG51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzcz1cInByLTggcGItNCBwbC0yIGJvcmRlci1yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRnVuY3Rpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJwci04IHBiLTQgcGwtMiBib3JkZXItclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEpvYlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzcz1cInByLTggcGItNCBwbC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQnJ1dG8gaW5jb21lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIgdi1mb3I9XCJpdGVtIGluIHN0YWZmUmVzdWx0LmdldEFsbFN0YWZmXCIgY2xhc3M9XCJvZGQ6YmctYmxhY2svMTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cImJvcmRlci1yIHAtMlwiPnt7IGl0ZW0ubmFtZSB9fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJib3JkZXItciBwLTJcIj57eyBpdGVtLmVtYWlsIH19PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cImJvcmRlci1yIHAtMlwiPnt7IGl0ZW0ucGhvbmVOdW1iZXIgPyBpdGVtLnBob25lTnVtYmVyIDogXCJObyBwaG9uZSBudW1iZXJcIiB9fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJib3JkZXItciBwLTJcIj57eyBpdGVtLnJvbGUgfX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzPVwiYm9yZGVyLXIgcC0yXCI+e3sgaXRlbS5qb2IgPyBpdGVtLmpvYiA6IFwiTm8gY3VycmVudCBqb2JcIiB9fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJwLTJcIj57eyBpdGVtLmJydXRvTW9udGhseVdhZ2UgPyBpdGVtLmJydXRvTW9udGhseVdhZ2UgOiBcIk5vIGluY29tZVwiIH19PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgPC9kaXY+ICBcclxuICAgICAgICA8L3NlY3Rpb24+ICAgIFxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2IHYtZWxzZT5cclxuICAgICAgICA8cD5Mb2cgaW4gb20gZWVuIGFjY291bnQgdGUgemllbjwvcD5cclxuICAgICAgICA8QnV0dG9uIEBjbGljaz1cImxvZ291dFVzZXJcIiA+XHJcbiAgICAgICAgICAgIHt7ICR0KCdMb2dvdXQnKSB9fVxyXG4gICAgICAgIDwvQnV0dG9uPlxyXG4gICAgPC9kaXY+XHJcbjwvdGVtcGxhdGU+XHJcblxyXG48c2NyaXB0IHNldHVwIGxhbmc9XCJ0c1wiPlxyXG4gICAgaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAndnVlLXJvdXRlcidcclxuICAgIGltcG9ydCB7cmVmLCBjb21wdXRlZCB9IGZyb20gJ3Z1ZSdcclxuXHJcbiAgICBpbXBvcnQgdXNlRmlyZWJhc2UgZnJvbSAnQC9jb21wb3NhYmxlcy91c2VGaXJlYmFzZSdcclxuICAgIGltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICd2dWUtaTE4bidcclxuICAgIGltcG9ydCB7IEdFVF9VU0VSX0JZX1VJRCB9IGZyb20gJ0AvZ3JhcGhxbC91c2VyLnF1ZXJ5J1xyXG4gICAgaW1wb3J0IHsgR0VUX0FMTF9TVEFGRiB9IGZyb20gJ0AvZ3JhcGhxbC9hbGxTdGFmZi5xdWVyeSdcclxuICAgIGltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSAnQHZ1ZS9hcG9sbG8tY29tcG9zYWJsZSdcclxuICAgIGltcG9ydCBCdXR0b24gZnJvbSAnLi4vY29tcG9uZW50cy9nZW5lcmljL0N0YUJ1dHRvbi52dWUnXHJcbiAgICBpbXBvcnQgeyBkYXRhY2F0YWxvZyB9IGZyb20gJ2dvb2dsZWFwaXMvYnVpbGQvc3JjL2FwaXMvZGF0YWNhdGFsb2cnXHJcbiAgICBpbXBvcnQgeyB0YWJsZSB9IGZyb20gJ2NvbnNvbGUnO1xyXG5pbXBvcnQgeyB0eXBlIH0gZnJvbSAnb3MnXHJcbmltcG9ydCB7IHRleHQgfSBmcm9tICdub2RlOnN0cmVhbS9jb25zdW1lcnMnXHJcblxyXG4gICAgY29uc3QgeyBmaXJlYmFzZVVzZXIsIGxvZ291dCB9ID0gdXNlRmlyZWJhc2UoKVxyXG4gICAgY29uc3QgeyByZXBsYWNlIH0gPSB1c2VSb3V0ZXIoKVxyXG4gICAgY29uc3QgeyBsb2NhbGUgfSA9IHVzZUkxOG4oKVxyXG4gICAgY29uc3QgdXNlckVkaXRBY3RpdmUgPSByZWYoZmFsc2UpXHJcbiAgICBjb25zdCBhZG1pbiA9IHJlZihmYWxzZSlcclxuXHJcbiAgICBjb25zdCB7IHJlc3VsdCB9ID0gdXNlUXVlcnkoR0VUX1VTRVJfQllfVUlELCB7dWlkOiBmaXJlYmFzZVVzZXIudmFsdWU/LnVpZH0pXHJcbiAgICBjb25zdCB1c2VyUmVzdWx0ID0gY29tcHV0ZWQoKCkgPT4gcmVzdWx0LnZhbHVlKVxyXG5cclxuICAgIGNvbnN0IHJlc3VsdFN0YWZmID0gdXNlUXVlcnkoR0VUX0FMTF9TVEFGRilcclxuICAgIGNvbnN0IHN0YWZmUmVzdWx0ID0gY29tcHV0ZWQoKCkgPT4gcmVzdWx0U3RhZmYucmVzdWx0LnZhbHVlKVxyXG5cclxuICAgIFxyXG5cclxuICAgIGNvbnN0IHVzZXJJbmZvID0gcmVmKHtcclxuICAgICAgICBuYW1lOiAnJyxcclxuICAgICAgICBlbWFpbDogJycsXHJcbiAgICAgICAgcGhvbmVOdW1iZXI6ICcnLFxyXG4gICAgICAgIGZ1bGxOYW1lOiAnJ1xyXG4gICAgfSlcclxuXHJcbiAgICBjb25zdCBpdGVtcyA9IFtcclxuICAgICAgICB7IHdlcmtkYWdlbjogJ01vbmRheScsIFN0YXJ0X3V1cjogJzEzOjMwJywgRWluZF91dXI6ICcxODozMCcgfSxcclxuICAgICAgICB7IHdlcmtkYWdlbjogJ1R1ZXNkYXknLCBTdGFydF91dXI6ICcxMzozMCcsIEVpbmRfdXVyOiAnMTg6MzAnIH0sXHJcbiAgICAgICAgeyB3ZXJrZGFnZW46ICdXZWRuZXNkYXknLCBTdGFydF91dXI6ICcwOTozMCcsIEVpbmRfdXVyOiAnMTM6MzAnIH0sXHJcbiAgICAgICAgeyB3ZXJrZGFnZW46ICdUaHVyc2RheScsIFN0YXJ0X3V1cjogJzA5OjMwJywgRWluZF91dXI6ICcxMzozMCcgfSxcclxuICAgICAgICB7IHdlcmtkYWdlbjogJ0ZyaWRheScsIFN0YXJ0X3V1cjogJzEwOjAwJywgRWluZF91dXI6ICcxNDozMCcgfVxyXG4gICAgXVxyXG5cclxuICAgIGNvbnN0IFZha2FudGllRGFnZW4gPSBbXHJcbiAgICAgICAge2Zyb206ICcwMiBhcHJpbCcsIHRvOiAnMTYgYXByaWwnfSxcclxuICAgICAgICB7ZnJvbTogJzE1IGp1bHknLCB0bzogJzE1IGF1Z3VzdCd9LFxyXG4gICAgICAgIHtmcm9tOiAnMjAgZGVjZW1iZXInLCB0bzogJzI3IGRlY2VtYmVyJ31cclxuICAgIF1cclxuXHJcbiAgICBjb25zdCBsb2dnZWRJbiA9ICgpID0+IHtcclxuXHJcbiAgICB9XHJcblxyXG5cclxuICAgIGNvbnN0IGxvZ291dFVzZXIgPSAoKSA9PiB7XHJcbiAgICAgICAgbG9nb3V0KCkudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICAgIHJlcGxhY2Uoe3BhdGg6ICcvJ30pXHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuXHJcbjwvc2NyaXB0PiJdLCJmaWxlIjoiQzovQUZTRC9Lb2JlLUJlcnQvcGFja2FnZXMvcHdhL3NyYy92aWV3cy9wcm9maWxlLnZ1ZSJ9