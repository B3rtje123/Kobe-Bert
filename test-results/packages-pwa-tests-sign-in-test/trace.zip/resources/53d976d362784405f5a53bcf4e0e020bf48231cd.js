import gql from "/node_modules/.vite/deps/graphql-tag.js?v=1470181e";
export const GET_ALL_STAFF = gql`
 query GetAllStaff {
  getAllStaff {
    id
    uid
    name
    email
    role
    locale
    fullname
    phoneNumber
    brutoMonthlyWage
    isChief
    job
  }
}
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFsbFN0YWZmLnF1ZXJ5LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBncWwgZnJvbSBcImdyYXBocWwtdGFnXCJcclxuXHJcbmV4cG9ydCBjb25zdCBHRVRfQUxMX1NUQUZGID0gZ3FsYFxyXG4gcXVlcnkgR2V0QWxsU3RhZmYge1xyXG4gIGdldEFsbFN0YWZmIHtcclxuICAgIGlkXHJcbiAgICB1aWRcclxuICAgIG5hbWVcclxuICAgIGVtYWlsXHJcbiAgICByb2xlXHJcbiAgICBsb2NhbGVcclxuICAgIGZ1bGxuYW1lXHJcbiAgICBwaG9uZU51bWJlclxyXG4gICAgYnJ1dG9Nb250aGx5V2FnZVxyXG4gICAgaXNDaGllZlxyXG4gICAgam9iXHJcbiAgfVxyXG59XHJcbmAiXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sU0FBUztBQUVULGFBQU0sZ0JBQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7IiwibmFtZXMiOltdfQ==