import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/home.vue");const _sfc_main = {}
import { openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=1470181e"

const _hoisted_1 = { class: "text-MainWhite" }

function _sfc_render(_ctx, _cache) {
  return (_openBlock(), _createElementBlock("h1", _hoisted_1, "HOMEPAGE"))
}


_sfc_main.__hmrId = "40f7d07e"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/AFSD/Kobe-Bert/packages/pwa/src/views/home.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUudnVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O3FCQUNNLEtBQUssRUFBQyxnQkFBZ0I7Ozt3QkFBMUIsb0JBQXdDLE1BQXhDLFVBQXdDLEVBQWIsVUFBUSIsImZpbGUiOiJDOi9BRlNEL0tvYmUtQmVydC9wYWNrYWdlcy9wd2Evc3JjL3ZpZXdzL2hvbWUudnVlIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIjx0ZW1wbGF0ZT5cclxuICA8aDEgY2xhc3M9XCJ0ZXh0LU1haW5XaGl0ZVwiPkhPTUVQQUdFPC9oMT5cclxuPC90ZW1wbGF0ZT5cclxuXHJcbjxzY3JpcHQgc2V0dXAgbGFuZz1cInRzXCI+XHJcblxyXG48L3NjcmlwdD4iXX0=