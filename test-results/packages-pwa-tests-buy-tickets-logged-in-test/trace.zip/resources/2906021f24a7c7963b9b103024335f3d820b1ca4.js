import {
  ApolloLink,
  Observable
} from "/node_modules/.vite/deps/chunk-27PNIARD.js?v=69a8df67";
import "/node_modules/.vite/deps/chunk-NBBOXWME.js?v=69a8df67";
import "/node_modules/.vite/deps/chunk-2ODJBQ45.js?v=69a8df67";
import {
  __rest
} from "/node_modules/.vite/deps/chunk-47VN6MY4.js?v=69a8df67";
import "/node_modules/.vite/deps/chunk-5WWUZCGV.js?v=69a8df67";

// ../../node_modules/@apollo/client/link/context/index.js
function setContext(setter) {
  return new ApolloLink(function(operation, forward) {
    var request = __rest(operation, []);
    return new Observable(function(observer) {
      var handle;
      var closed = false;
      Promise.resolve(request).then(function(req) {
        return setter(req, operation.getContext());
      }).then(operation.setContext).then(function() {
        if (closed)
          return;
        handle = forward(operation).subscribe({
          next: observer.next.bind(observer),
          error: observer.error.bind(observer),
          complete: observer.complete.bind(observer)
        });
      }).catch(observer.error.bind(observer));
      return function() {
        closed = true;
        if (handle)
          handle.unsubscribe();
      };
    });
  });
}
export {
  setContext
};
//# sourceMappingURL=@apollo_client_link_context.js.map
