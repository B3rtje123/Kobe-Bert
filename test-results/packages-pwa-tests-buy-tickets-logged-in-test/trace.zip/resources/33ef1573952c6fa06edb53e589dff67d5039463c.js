import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/client/buyTicket.vue");import { defineComponent as _defineComponent } from "/node_modules/.vite/deps/vue.js?v=69a8df67";
import { useQuery, useMutation } from "/node_modules/.vite/deps/@vue_apollo-composable.js?v=69a8df67";
import { GET_ALL_TICKET_TYPES } from "/src/graphql/ticketTypes.query.ts";
import { ADD_TICKET } from "/src/graphql/createTicket.mutation.ts";
import { useRouter } from "/node_modules/.vite/deps/vue-router.js?v=69a8df67";
import { ref } from "/node_modules/.vite/deps/vue.js?v=69a8df67";
import { computed } from "/node_modules/.vite/deps/vue.js?v=69a8df67";
import useFirebase from "/src/composables/useFirebase.ts";
const _sfc_main = /* @__PURE__ */ _defineComponent({
  __name: "buyTicket",
  setup(__props, { expose: __expose }) {
    __expose();
    const { mutate: createTicket, onDone: created } = useMutation(ADD_TICKET);
    const { firebaseUser } = useFirebase();
    const { replace } = useRouter();
    const {
      result,
      onResult,
      loading: loadingTypes
    } = useQuery(GET_ALL_TICKET_TYPES);
    const TypeResults = computed(() => result.value);
    const newOrder = ref({
      email: firebaseUser.value?.email ? firebaseUser.value?.email : "",
      date: null,
      types: []
    });
    onResult(() => {
      console.log(TypeResults.value.getAllTicketTypes);
      TypeResults.value.getAllTicketTypes.forEach((ticketType) => {
        newOrder.value.types?.push({
          name: ticketType.name,
          price: ticketType.price,
          amount: ticketType.amount,
          id: ticketType.id,
          count: 0
        });
      });
    });
    const buytickets = () => {
      console.log(newOrder.value);
      newOrder.value.types?.forEach((type) => {
        for (let i = 0; i < type.count; i++) {
          createTicket({
            createTicketInput: {
              typeId: type.id,
              startDay: newOrder.value.date,
              clientUid: firebaseUser.value ? firebaseUser.value.uid : null
            }
          }).catch((err) => {
            console.log(err);
          }).then((result2) => {
            console.log(result2);
            replace("/ticket");
          });
        }
      });
    };
    const __returned__ = { createTicket, created, firebaseUser, replace, result, onResult, loadingTypes, TypeResults, newOrder, buytickets };
    Object.defineProperty(__returned__, "__isScriptSetup", { enumerable: false, value: true });
    return __returned__;
  }
});
import { renderList as _renderList, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock, vModelText as _vModelText, createElementVNode as _createElementVNode, withDirectives as _withDirectives, toDisplayString as _toDisplayString, withModifiers as _withModifiers } from "/node_modules/.vite/deps/vue.js?v=69a8df67";
const _hoisted_1 = ["onSubmit"];
const _hoisted_2 = { class: "rounded-lg max-w-sm shadow-[0_0_60px_-25px_rgba(0,0,0,0.3)] shadow-AccentBlue p-12 bg-MainWhite" };
const _hoisted_3 = ["onUpdate:modelValue", "id"];
const _hoisted_4 = ["for"];
const _hoisted_5 = { class: "mb-6" };
const _hoisted_6 = /* @__PURE__ */ _createElementVNode(
  "label",
  {
    for: "email",
    class: "mb-4 font-medium"
  },
  "email",
  -1
  /* HOISTED */
);
const _hoisted_7 = { class: "mb-6" };
const _hoisted_8 = /* @__PURE__ */ _createElementVNode(
  "label",
  {
    for: "date",
    class: "mb-4 font-medium"
  },
  "email",
  -1
  /* HOISTED */
);
const _hoisted_9 = /* @__PURE__ */ _createElementVNode(
  "button",
  {
    type: "submit",
    class: "w-full py-2 border border-hidden rounded-lg mb-8 font-semibold bg-AccentBlue text-MainWhite transition ease-in-out duration-300 hover:bg-BgBlack/25 hover:text-BgBlack focus:outline-none focus:ring-4 focus:ring-AccentBlue focus:bg-[#1B8ACC]"
  },
  " buy tickets ",
  -1
  /* HOISTED */
);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return _openBlock(), _createElementBlock("form", {
    onSubmit: _withModifiers($setup.buytickets, ["prevent"]),
    class: "flex mt-16 justify-center items-center text-BgBlack"
  }, [
    _createElementVNode("div", _hoisted_2, [
      (_openBlock(true), _createElementBlock(
        _Fragment,
        null,
        _renderList($setup.newOrder.types, (type) => {
          return _openBlock(), _createElementBlock("div", {
            key: type.name,
            class: "mb-2"
          }, [
            _withDirectives(_createElementVNode("input", {
              type: "number",
              "onUpdate:modelValue": ($event) => type.count = $event,
              id: type.name,
              placeholder: "0",
              class: "mr-2 rounded-lg border-2 p-2 shadow-inner shadow-gray-400 w-20 transition-colors ease-in-out duration-300 hover:border-AccentBlue focus:outline-none focus:ring-4 focus:ring-AccentBlue appearance-none"
            }, null, 8, _hoisted_3), [
              [_vModelText, type.count]
            ]),
            _createElementVNode("label", {
              for: type.name
            }, _toDisplayString(type.name.toLowerCase()), 9, _hoisted_4)
          ]);
        }),
        128
        /* KEYED_FRAGMENT */
      )),
      _createElementVNode("div", _hoisted_5, [
        _hoisted_6,
        _withDirectives(_createElementVNode(
          "input",
          {
            type: "text",
            name: "email",
            id: "email",
            placeholder: "example@domain.com",
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => $setup.newOrder.email = $event),
            required: "",
            autocomplete: "off",
            class: "block rounded-lg border-2 p-2 shadow-inner shadow-gray-400 w-full transition-colors ease-in-out duration-300 hover:border-AccentBlue focus:outline-none focus:ring-4 focus:ring-AccentBlue"
          },
          null,
          512
          /* NEED_PATCH */
        ), [
          [_vModelText, $setup.newOrder.email]
        ])
      ]),
      _createElementVNode("div", _hoisted_7, [
        _hoisted_8,
        _withDirectives(_createElementVNode(
          "input",
          {
            type: "date",
            name: "date",
            id: "date",
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => $setup.newOrder.date = $event),
            required: "",
            autocomplete: "off",
            class: "block rounded-lg border-2 p-2 shadow-inner shadow-gray-400 w-full transition-colors ease-in-out duration-300 hover:border-AccentBlue focus:outline-none focus:ring-4 focus:ring-AccentBlue"
          },
          null,
          512
          /* NEED_PATCH */
        ), [
          [_vModelText, $setup.newOrder.date]
        ])
      ]),
      _hoisted_9
    ])
  ], 40, _hoisted_1);
}
_sfc_main.__hmrId = "676fb61f";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.accept((mod) => {
  if (!mod)
    return;
  const { default: updated, _rerender_only } = mod;
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
  }
});
import _export_sfc from "/@id/__x00__plugin-vue:export-helper";
export default /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "C:/AFSD/Kobe-Bert/packages/pwa/src/views/client/buyTicket.vue"]]);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQXlEQSxTQUFTLFVBQVUsbUJBQW1CO0FBQ3RDLFNBQVMsNEJBQTRCO0FBQ3JDLFNBQVMsa0JBQWtCO0FBRTNCLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsV0FBVztBQUNwQixTQUFTLGdCQUFnQjtBQUN6QixPQUFPLGlCQUFpQjs7Ozs7QUFFeEIsVUFBTSxFQUFFLFFBQVEsY0FBYyxRQUFRLFFBQVEsSUFBSSxZQUFZLFVBQVU7QUFDeEUsVUFBTSxFQUFFLGFBQWEsSUFBSSxZQUFZO0FBQ3JDLFVBQU0sRUFBRSxRQUFRLElBQUksVUFBVTtBQWlCOUIsVUFBTTtBQUFBLE1BQ0o7QUFBQSxNQUNBO0FBQUEsTUFDQSxTQUFTO0FBQUEsSUFDWCxJQUFJLFNBQVMsb0JBQW9CO0FBQ2pDLFVBQU0sY0FBYyxTQUFTLE1BQU0sT0FBTyxLQUFLO0FBRS9DLFVBQU0sV0FBVyxJQUFjO0FBQUEsTUFDN0IsT0FBTyxhQUFhLE9BQU8sUUFBUSxhQUFhLE9BQU8sUUFBUTtBQUFBLE1BQy9ELE1BQU07QUFBQSxNQUNOLE9BQU8sQ0FBQztBQUFBLElBQ1YsQ0FBQztBQUVELGFBQVMsTUFBTTtBQUNiLGNBQVEsSUFBSSxZQUFZLE1BQU0saUJBQWlCO0FBQy9DLGtCQUFZLE1BQU0sa0JBQWtCLFFBQVEsQ0FBQyxlQUEyQjtBQUN0RSxpQkFBUyxNQUFNLE9BQU8sS0FBSztBQUFBLFVBQ3pCLE1BQU0sV0FBVztBQUFBLFVBQ2pCLE9BQU8sV0FBVztBQUFBLFVBQ2xCLFFBQVEsV0FBVztBQUFBLFVBQ25CLElBQUksV0FBVztBQUFBLFVBQ2YsT0FBTztBQUFBLFFBQ1QsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUVELFVBQU0sYUFBYSxNQUFNO0FBQ3ZCLGNBQVEsSUFBSSxTQUFTLEtBQUs7QUFDMUIsZUFBUyxNQUFNLE9BQU8sUUFBUSxVQUFRO0FBQ3BDLGlCQUFTLElBQUksR0FBRyxJQUFJLEtBQUssT0FBTyxLQUFLO0FBQ25DLHVCQUFhO0FBQUEsWUFDWCxtQkFBbUI7QUFBQSxjQUNqQixRQUFRLEtBQUs7QUFBQSxjQUNiLFVBQVUsU0FBUyxNQUFNO0FBQUEsY0FDekIsV0FBVyxhQUFhLFFBQVEsYUFBYSxNQUFNLE1BQU07QUFBQSxZQUMzRDtBQUFBLFVBQ0YsQ0FBQyxFQUNFLE1BQU0sU0FBTztBQUNaLG9CQUFRLElBQUksR0FBRztBQUFBLFVBQ2pCLENBQUMsRUFDQSxLQUFLLENBQUFBLFlBQVU7QUFDZCxvQkFBUSxJQUFJQSxPQUFNO0FBRWxCLG9CQUFRLFNBQVM7QUFBQSxVQUNuQixDQUFDO0FBQUEsUUFDTDtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7Ozs7Ozs7O3FCQTlITSxPQUFNLGtHQUFpRzs7O3FCQWFsRyxPQUFNLE9BQU07bUJBQ2Y7QUFBQSxFQUF5RDtBQUFBO0FBQUEsSUFBbEQsS0FBSTtBQUFBLElBQVEsT0FBTTtBQUFBO0VBQW1CO0FBQUEsRUFBSztBQUFBO0FBQUE7cUJBYTlDLE9BQU0sT0FBTTttQkFDZjtBQUFBLEVBQXdEO0FBQUE7QUFBQSxJQUFqRCxLQUFJO0FBQUEsSUFBTyxPQUFNO0FBQUE7RUFBbUI7QUFBQSxFQUFLO0FBQUE7QUFBQTttQkFZbEQ7QUFBQSxFQUtTO0FBQUE7QUFBQSxJQUpQLE1BQUs7QUFBQSxJQUNMLE9BQU07QUFBQTtFQUNQO0FBQUEsRUFFRDtBQUFBO0FBQUE7O3VCQWxESixvQkFvRE87QUFBQSxJQW5ESixVQUFNLGVBQVUsbUJBQVU7QUFBQSxJQUMzQixPQUFNO0FBQUE7SUFFTixvQkErQ00sT0EvQ04sWUErQ007QUFBQSx5QkE1Q0o7QUFBQSxRQVNNO0FBQUE7QUFBQSxvQkFUYyxnQkFBUyxPQUFLLENBQXRCLFNBQUk7K0JBQWhCLG9CQVNNO0FBQUEsWUFUK0IsS0FBSyxLQUFLO0FBQUEsWUFBTSxPQUFNO0FBQUE7NEJBQ3pELG9CQU1FO0FBQUEsY0FMQSxNQUFLO0FBQUEsaURBQ0ksS0FBSyxRQUFLO0FBQUEsY0FDbEIsSUFBSSxLQUFLO0FBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixPQUFNO0FBQUE7NEJBSEcsS0FBSyxLQUFLO0FBQUE7WUFLckIsb0JBQTZEO0FBQUEsY0FBckQsS0FBSyxLQUFLO0FBQUEsZ0NBQVMsS0FBSyxLQUFLLFlBQVc7QUFBQTs7Ozs7TUFHbEQsb0JBWU0sT0FaTixZQVlNO0FBQUEsUUFYSjtBQUFBLHdCQUNBO0FBQUEsVUFTRTtBQUFBO0FBQUEsWUFSQSxNQUFLO0FBQUEsWUFDTCxNQUFLO0FBQUEsWUFDTCxJQUFHO0FBQUEsWUFDSCxhQUFZO0FBQUEseUVBQ0gsZ0JBQVMsUUFBSztBQUFBLFlBQ3ZCO0FBQUEsWUFDQSxjQUFhO0FBQUEsWUFDYixPQUFNO0FBQUE7Ozs7O3dCQUhHLGdCQUFTLEtBQUs7QUFBQTs7TUFPM0Isb0JBV00sT0FYTixZQVdNO0FBQUEsUUFWSjtBQUFBLHdCQUNBO0FBQUEsVUFRRTtBQUFBO0FBQUEsWUFQQSxNQUFLO0FBQUEsWUFDTCxNQUFLO0FBQUEsWUFDTCxJQUFHO0FBQUEseUVBQ00sZ0JBQVMsT0FBSTtBQUFBLFlBQ3RCO0FBQUEsWUFDQSxjQUFhO0FBQUEsWUFDYixPQUFNO0FBQUE7Ozs7O3dCQUhHLGdCQUFTLElBQUk7QUFBQTs7TUFPMUI7QUFBQSIsIm5hbWVzIjpbInJlc3VsdCJdLCJzb3VyY2VzIjpbImJ1eVRpY2tldC52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxyXG4gIDxmb3JtXHJcbiAgICBAc3VibWl0LnByZXZlbnQ9XCJidXl0aWNrZXRzXCJcclxuICAgIGNsYXNzPVwiZmxleCBtdC0xNiBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgdGV4dC1CZ0JsYWNrXCJcclxuICA+XHJcbiAgICA8ZGl2XHJcbiAgICAgIGNsYXNzPVwicm91bmRlZC1sZyBtYXgtdy1zbSBzaGFkb3ctWzBfMF82MHB4Xy0yNXB4X3JnYmEoMCwwLDAsMC4zKV0gc2hhZG93LUFjY2VudEJsdWUgcC0xMiBiZy1NYWluV2hpdGVcIlxyXG4gICAgPlxyXG4gICAgICA8ZGl2IHYtZm9yPVwidHlwZSBpbiBuZXdPcmRlci50eXBlc1wiIDprZXk9XCJ0eXBlLm5hbWVcIiBjbGFzcz1cIm1iLTJcIj5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgdi1tb2RlbD1cInR5cGUuY291bnRcIlxyXG4gICAgICAgICAgOmlkPVwidHlwZS5uYW1lXCJcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMFwiXHJcbiAgICAgICAgICBjbGFzcz1cIm1yLTIgcm91bmRlZC1sZyBib3JkZXItMiBwLTIgc2hhZG93LWlubmVyIHNoYWRvdy1ncmF5LTQwMCB3LTIwIHRyYW5zaXRpb24tY29sb3JzIGVhc2UtaW4tb3V0IGR1cmF0aW9uLTMwMCBob3Zlcjpib3JkZXItQWNjZW50Qmx1ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctQWNjZW50Qmx1ZSBhcHBlYXJhbmNlLW5vbmVcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGxhYmVsIDpmb3I9XCJ0eXBlLm5hbWVcIj57eyB0eXBlLm5hbWUudG9Mb3dlckNhc2UoKSB9fTwvbGFiZWw+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzcz1cIm1iLTZcIj5cclxuICAgICAgICA8bGFiZWwgZm9yPVwiZW1haWxcIiBjbGFzcz1cIm1iLTQgZm9udC1tZWRpdW1cIj5lbWFpbDwvbGFiZWw+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICBuYW1lPVwiZW1haWxcIlxyXG4gICAgICAgICAgaWQ9XCJlbWFpbFwiXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cImV4YW1wbGVAZG9tYWluLmNvbVwiXHJcbiAgICAgICAgICB2LW1vZGVsPVwibmV3T3JkZXIuZW1haWxcIlxyXG4gICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgIGF1dG9jb21wbGV0ZT1cIm9mZlwiXHJcbiAgICAgICAgICBjbGFzcz1cImJsb2NrIHJvdW5kZWQtbGcgYm9yZGVyLTIgcC0yIHNoYWRvdy1pbm5lciBzaGFkb3ctZ3JheS00MDAgdy1mdWxsIHRyYW5zaXRpb24tY29sb3JzIGVhc2UtaW4tb3V0IGR1cmF0aW9uLTMwMCBob3Zlcjpib3JkZXItQWNjZW50Qmx1ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctQWNjZW50Qmx1ZVwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzPVwibWItNlwiPlxyXG4gICAgICAgIDxsYWJlbCBmb3I9XCJkYXRlXCIgY2xhc3M9XCJtYi00IGZvbnQtbWVkaXVtXCI+ZW1haWw8L2xhYmVsPlxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgbmFtZT1cImRhdGVcIlxyXG4gICAgICAgICAgaWQ9XCJkYXRlXCJcclxuICAgICAgICAgIHYtbW9kZWw9XCJuZXdPcmRlci5kYXRlXCJcclxuICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICBhdXRvY29tcGxldGU9XCJvZmZcIlxyXG4gICAgICAgICAgY2xhc3M9XCJibG9jayByb3VuZGVkLWxnIGJvcmRlci0yIHAtMiBzaGFkb3ctaW5uZXIgc2hhZG93LWdyYXktNDAwIHctZnVsbCB0cmFuc2l0aW9uLWNvbG9ycyBlYXNlLWluLW91dCBkdXJhdGlvbi0zMDAgaG92ZXI6Ym9yZGVyLUFjY2VudEJsdWUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctNCBmb2N1czpyaW5nLUFjY2VudEJsdWVcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGJ1dHRvblxyXG4gICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgIGNsYXNzPVwidy1mdWxsIHB5LTIgYm9yZGVyIGJvcmRlci1oaWRkZW4gcm91bmRlZC1sZyBtYi04IGZvbnQtc2VtaWJvbGQgYmctQWNjZW50Qmx1ZSB0ZXh0LU1haW5XaGl0ZSB0cmFuc2l0aW9uIGVhc2UtaW4tb3V0IGR1cmF0aW9uLTMwMCBob3ZlcjpiZy1CZ0JsYWNrLzI1IGhvdmVyOnRleHQtQmdCbGFjayBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctQWNjZW50Qmx1ZSBmb2N1czpiZy1bIzFCOEFDQ11cIlxyXG4gICAgICA+XHJcbiAgICAgICAgYnV5IHRpY2tldHNcclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuICA8L2Zvcm0+XHJcbjwvdGVtcGxhdGU+XHJcblxyXG48c2NyaXB0IHNldHVwIGxhbmc9XCJ0c1wiPlxyXG5pbXBvcnQgeyB1c2VRdWVyeSwgdXNlTXV0YXRpb24gfSBmcm9tIFwiQHZ1ZS9hcG9sbG8tY29tcG9zYWJsZVwiXHJcbmltcG9ydCB7IEdFVF9BTExfVElDS0VUX1RZUEVTIH0gZnJvbSBcIkAvZ3JhcGhxbC90aWNrZXRUeXBlcy5xdWVyeVwiXHJcbmltcG9ydCB7IEFERF9USUNLRVQgfSBmcm9tIFwiQC9ncmFwaHFsL2NyZWF0ZVRpY2tldC5tdXRhdGlvblwiXHJcbmltcG9ydCB7IEdFVF9VU0VSX0JZX1VJRCB9IGZyb20gXCJAL2dyYXBocWwvdXNlci5xdWVyeVwiXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJ2dWUtcm91dGVyXCJcclxuaW1wb3J0IHsgcmVmIH0gZnJvbSBcInZ1ZVwiXHJcbmltcG9ydCB7IGNvbXB1dGVkIH0gZnJvbSBcInZ1ZVwiXHJcbmltcG9ydCB1c2VGaXJlYmFzZSBmcm9tIFwiQC9jb21wb3NhYmxlcy91c2VGaXJlYmFzZVwiXHJcblxyXG5jb25zdCB7IG11dGF0ZTogY3JlYXRlVGlja2V0LCBvbkRvbmU6IGNyZWF0ZWQgfSA9IHVzZU11dGF0aW9uKEFERF9USUNLRVQpXHJcbmNvbnN0IHsgZmlyZWJhc2VVc2VyIH0gPSB1c2VGaXJlYmFzZSgpXHJcbmNvbnN0IHsgcmVwbGFjZSB9ID0gdXNlUm91dGVyKClcclxuXHJcbi8vaW50ZXJmYWNlc1xyXG5pbnRlcmZhY2UgVGlja2V0VHlwZSB7XHJcbiAgbmFtZTogc3RyaW5nXHJcbiAgcHJpY2U6IG51bWJlclxyXG4gIGFtb3VudDogbnVtYmVyXHJcbiAgaWQ6IHN0cmluZ1xyXG4gIGNvdW50OiBudW1iZXJcclxufVxyXG5cclxuaW50ZXJmYWNlIE5ld09yZGVyIHtcclxuICBlbWFpbDogc3RyaW5nXHJcbiAgZGF0ZTogRGF0ZSB8IG51bGxcclxuICB0eXBlcz86IFRpY2tldFR5cGVbXVxyXG59XHJcblxyXG5jb25zdCB7XHJcbiAgcmVzdWx0LFxyXG4gIG9uUmVzdWx0LFxyXG4gIGxvYWRpbmc6IGxvYWRpbmdUeXBlcyxcclxufSA9IHVzZVF1ZXJ5KEdFVF9BTExfVElDS0VUX1RZUEVTKVxyXG5jb25zdCBUeXBlUmVzdWx0cyA9IGNvbXB1dGVkKCgpID0+IHJlc3VsdC52YWx1ZSlcclxuXHJcbmNvbnN0IG5ld09yZGVyID0gcmVmPE5ld09yZGVyPih7XHJcbiAgZW1haWw6IGZpcmViYXNlVXNlci52YWx1ZT8uZW1haWwgPyBmaXJlYmFzZVVzZXIudmFsdWU/LmVtYWlsIDogXCJcIixcclxuICBkYXRlOiBudWxsLFxyXG4gIHR5cGVzOiBbXSxcclxufSlcclxuXHJcbm9uUmVzdWx0KCgpID0+IHtcclxuICBjb25zb2xlLmxvZyhUeXBlUmVzdWx0cy52YWx1ZS5nZXRBbGxUaWNrZXRUeXBlcylcclxuICBUeXBlUmVzdWx0cy52YWx1ZS5nZXRBbGxUaWNrZXRUeXBlcy5mb3JFYWNoKCh0aWNrZXRUeXBlOiBUaWNrZXRUeXBlKSA9PiB7XHJcbiAgICBuZXdPcmRlci52YWx1ZS50eXBlcz8ucHVzaCh7XHJcbiAgICAgIG5hbWU6IHRpY2tldFR5cGUubmFtZSxcclxuICAgICAgcHJpY2U6IHRpY2tldFR5cGUucHJpY2UsXHJcbiAgICAgIGFtb3VudDogdGlja2V0VHlwZS5hbW91bnQsXHJcbiAgICAgIGlkOiB0aWNrZXRUeXBlLmlkLFxyXG4gICAgICBjb3VudDogMCxcclxuICAgIH0pXHJcbiAgfSlcclxufSlcclxuXHJcbmNvbnN0IGJ1eXRpY2tldHMgPSAoKSA9PiB7XHJcbiAgY29uc29sZS5sb2cobmV3T3JkZXIudmFsdWUpXHJcbiAgbmV3T3JkZXIudmFsdWUudHlwZXM/LmZvckVhY2godHlwZSA9PiB7XHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHR5cGUuY291bnQ7IGkrKykge1xyXG4gICAgICBjcmVhdGVUaWNrZXQoe1xyXG4gICAgICAgIGNyZWF0ZVRpY2tldElucHV0OiB7XHJcbiAgICAgICAgICB0eXBlSWQ6IHR5cGUuaWQsXHJcbiAgICAgICAgICBzdGFydERheTogbmV3T3JkZXIudmFsdWUuZGF0ZSxcclxuICAgICAgICAgIGNsaWVudFVpZDogZmlyZWJhc2VVc2VyLnZhbHVlID8gZmlyZWJhc2VVc2VyLnZhbHVlLnVpZCA6IG51bGwsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSlcclxuICAgICAgICAuY2F0Y2goZXJyID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGVycilcclxuICAgICAgICB9KVxyXG4gICAgICAgIC50aGVuKHJlc3VsdCA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhyZXN1bHQpXHJcbiAgICAgICAgICAvLyBUT0RPOiBzZW5kIGVtYWlsIHdpdGggUVItY29kZXMgdG8gY2xpZW50XHJcbiAgICAgICAgICByZXBsYWNlKFwiL3RpY2tldFwiKVxyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgfSlcclxufVxyXG48L3NjcmlwdD5cclxuIl0sImZpbGUiOiJDOi9BRlNEL0tvYmUtQmVydC9wYWNrYWdlcy9wd2Evc3JjL3ZpZXdzL2NsaWVudC9idXlUaWNrZXQudnVlIn0=