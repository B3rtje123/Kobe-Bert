import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/client/ticket.vue");import { defineComponent as _defineComponent } from "/node_modules/.vite/deps/vue.js?v=69a8df67";
import useFirebase from "/src/composables/useFirebase.ts";
import { GET_ALL_TICKETS_BY_UID } from "/src/graphql/allTicketsByUid.ts";
import VueBarcode from "/node_modules/.vite/deps/@chenfengyuan_vue-barcode.js?v=69a8df67";
import { createApp } from "/node_modules/.vite/deps/vue.js?v=69a8df67";
import { useQuery } from "/node_modules/.vite/deps/@vue_apollo-composable.js?v=69a8df67";
import { useRouter } from "/node_modules/.vite/deps/vue-router.js?v=69a8df67";
import { watch } from "/node_modules/.vite/deps/vue.js?v=69a8df67";
const _sfc_main = /* @__PURE__ */ _defineComponent({
  __name: "ticket",
  setup(__props, { expose: __expose }) {
    __expose();
    const app = createApp({
      components: {
        VueBarcode
      }
    });
    const { replace } = useRouter();
    const { firebaseUser } = useFirebase();
    if (!firebaseUser.value) {
      replace("/ticket/buy");
    }
    const {
      result: ticketsResult,
      onResult,
      loading: ticketsLoading
    } = useQuery(GET_ALL_TICKETS_BY_UID);
    watch(ticketsResult, () => {
      console.log(ticketsResult.value);
      ticketsResult.value.getTicketsByUserId.filter(
        (item) => item.isUsed == false && new Date(item.endDay) > /* @__PURE__ */ new Date()
      );
    });
    const __returned__ = { app, replace, firebaseUser, ticketsResult, onResult, ticketsLoading, get VueBarcode() {
      return VueBarcode;
    } };
    Object.defineProperty(__returned__, "__isScriptSetup", { enumerable: false, value: true });
    return __returned__;
  }
});
import { createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, createElementVNode as _createElementVNode, createCommentVNode as _createCommentVNode, renderList as _renderList, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock, toDisplayString as _toDisplayString } from "/node_modules/.vite/deps/vue.js?v=69a8df67";
const _hoisted_1 = { class: "flex p-4 justify-center m-4" };
const _hoisted_2 = { class: "flex justify-center" };
const _hoisted_3 = {
  key: 0,
  class: "table-auto w-8/12"
};
const _hoisted_4 = /* @__PURE__ */ _createElementVNode(
  "thead",
  { class: "" },
  [
    /* @__PURE__ */ _createElementVNode("tr", null, [
      /* @__PURE__ */ _createElementVNode("th", { class: "pr-8 pl-2 pb-4 border-r" }, "type"),
      /* @__PURE__ */ _createElementVNode("th", { class: "pr-8 pb-4 pl-2 border-r" }, "day"),
      /* @__PURE__ */ _createElementVNode("th", { class: "pb-4 border-r" }, "barcode")
    ])
  ],
  -1
  /* HOISTED */
);
const _hoisted_5 = { class: "odd:bg-black/15" };
const _hoisted_6 = { class: "border-r p-2" };
const _hoisted_7 = { class: "border-r p-2" };
const _hoisted_8 = { class: "border-r flex justify-center" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_RouterLink = _resolveComponent("RouterLink");
  return _openBlock(), _createElementBlock(
    _Fragment,
    null,
    [
      _createElementVNode("div", _hoisted_1, [
        _createVNode(_component_RouterLink, {
          to: "/ticket/buy",
          class: "bg-AccentBlue text-2xl lg:text-lg font-semibold text-MainWhite rounded py-1.5 px4 transition ease-in-out duration-300 hover:bg-sky-600 hover:text-BgBlack focus:outline-none focus:bg-transparent focus:ring-4 focus:ring-sky-600 focus:text-AccentBlue"
        }, {
          default: _withCtx(() => [
            _createTextVNode(" Buy tickets ")
          ]),
          _: 1
          /* STABLE */
        })
      ]),
      _createCommentVNode(" show tickets from user if logged in "),
      _createElementVNode("div", _hoisted_2, [
        !$setup.ticketsLoading ? (_openBlock(), _createElementBlock("table", _hoisted_3, [
          _hoisted_4,
          _createElementVNode("tbody", null, [
            (_openBlock(true), _createElementBlock(
              _Fragment,
              null,
              _renderList($setup.ticketsResult.getTicketsByUserId, (item) => {
                return _openBlock(), _createElementBlock("tr", _hoisted_5, [
                  _createCommentVNode(' <div v-if="item.isUsed == false && new Date(item.endDay) > new Date()"> '),
                  _createElementVNode(
                    "td",
                    _hoisted_6,
                    _toDisplayString(item.type.name),
                    1
                    /* TEXT */
                  ),
                  _createElementVNode(
                    "td",
                    _hoisted_7,
                    _toDisplayString(new Date(item.endDay).toLocaleDateString()),
                    1
                    /* TEXT */
                  ),
                  _createElementVNode("td", _hoisted_8, [
                    _createVNode($setup["VueBarcode"], {
                      value: item.barcode,
                      modelValue: item.barcode,
                      "onUpdate:modelValue": ($event) => item.barcode = $event,
                      tag: "svg"
                    }, null, 8, ["value", "modelValue", "onUpdate:modelValue"])
                  ]),
                  _createCommentVNode(" </div> ")
                ]);
              }),
              256
              /* UNKEYED_FRAGMENT */
            ))
          ])
        ])) : _createCommentVNode("v-if", true)
      ])
    ],
    64
    /* STABLE_FRAGMENT */
  );
}
_sfc_main.__hmrId = "de944ab0";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.accept((mod) => {
  if (!mod)
    return;
  const { default: updated, _rerender_only } = mod;
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
  }
});
import _export_sfc from "/@id/__x00__plugin-vue:export-helper";
export default /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "C:/AFSD/Kobe-Bert/packages/pwa/src/views/client/ticket.vue"]]);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQTZDQSxPQUFPLGlCQUFpQjtBQUN4QixTQUFTLDhCQUE4QjtBQUN2QyxPQUFPLGdCQUFnQjtBQUN2QixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLGdCQUFnQjtBQUV6QixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLGFBQWE7Ozs7O0FBRXRCLFVBQU0sTUFBTSxVQUFVO0FBQUEsTUFDcEIsWUFBWTtBQUFBLFFBQ1Y7QUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBRUQsVUFBTSxFQUFFLFFBQVEsSUFBSSxVQUFVO0FBQzlCLFVBQU0sRUFBRSxhQUFhLElBQUksWUFBWTtBQUVyQyxRQUFJLENBQUMsYUFBYSxPQUFPO0FBQ3ZCLGNBQVEsYUFBYTtBQUFBLElBQ3ZCO0FBRUEsVUFBTTtBQUFBLE1BQ0osUUFBUTtBQUFBLE1BQ1I7QUFBQSxNQUNBLFNBQVM7QUFBQSxJQUNYLElBQUksU0FBUyxzQkFBc0I7QUFFbkMsVUFBTSxlQUFlLE1BQU07QUFDekIsY0FBUSxJQUFJLGNBQWMsS0FBSztBQUMvQixvQkFBYyxNQUFNLG1CQUFtQjtBQUFBLFFBQ3JDLENBQUMsU0FBYyxLQUFLLFVBQVUsU0FBUyxJQUFJLEtBQUssS0FBSyxNQUFNLElBQUksb0JBQUksS0FBSztBQUFBLE1BQzFFO0FBQUEsSUFDRixDQUFDOzs7Ozs7Ozs7cUJBN0VNLE9BQU0sOEJBQTZCO3FCQVVuQyxPQUFNLHNCQUFxQjs7O0VBQ3ZCLE9BQU07O21CQUNYO0FBQUEsRUFNUTtBQUFBLElBTkQsT0FBTSxHQUFFO0FBQUE7QUFBQSxJQUNiLG9DQUlLO0FBQUEsTUFISCxvQ0FBNkMsUUFBekMsT0FBTSwwQkFBeUIsR0FBQyxNQUFJO0FBQUEsTUFDeEMsb0NBQTRDLFFBQXhDLE9BQU0sMEJBQXlCLEdBQUMsS0FBRztBQUFBLE1BQ3ZDLG9DQUFzQyxRQUFsQyxPQUFNLGdCQUFlLEdBQUMsU0FBTztBQUFBOzs7OztxQkFNakMsT0FBTSxrQkFBaUI7cUJBR25CLE9BQU0sZUFBYztxQkFDcEIsT0FBTSxlQUFjO3FCQUdwQixPQUFNLCtCQUE4Qjs7Ozs7OztNQTdCaEQsb0JBT00sT0FQTixZQU9NO0FBQUEsUUFOSixhQUthO0FBQUEsVUFKWCxJQUFHO0FBQUEsVUFDSCxPQUFNO0FBQUE7NEJBQ1AsTUFFRDtBQUFBLDZCQUZDLGVBRUQ7QUFBQTs7Ozs7TUFHRjtBQUFBLE1BQ0Esb0JBOEJNLE9BOUJOLFlBOEJNO0FBQUEsU0E3Qm9DLHVDQUF4QyxvQkE0QlEsU0E1QlIsWUE0QlE7QUFBQSxVQTNCTjtBQUFBLFVBT0Esb0JBbUJRO0FBQUEsK0JBbEJOO0FBQUEsY0FpQks7QUFBQTtBQUFBLDBCQWhCWSxxQkFBYyxvQkFBa0IsQ0FBeEMsU0FBSTtxQ0FEYixvQkFpQkssTUFqQkwsWUFpQks7QUFBQSxrQkFiSDtBQUFBLGtCQUNBO0FBQUEsb0JBQWtEO0FBQUEsb0JBQWxEO0FBQUEsb0JBQWtELGlCQUF0QixLQUFLLEtBQUssSUFBSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUMxQztBQUFBLG9CQUVLO0FBQUEsb0JBRkw7QUFBQSxvQkFFSyxxQkFESSxLQUFLLEtBQUssTUFBTSxFQUFFLG1CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUU3QyxvQkFNSyxNQU5MLFlBTUs7QUFBQSxvQkFMSCxhQUllO0FBQUEsc0JBSE4sT0FBTyxLQUFLO0FBQUEsa0NBQ1YsS0FBSztBQUFBLHlEQUFMLEtBQUssVUFBTztBQUFBLHNCQUNyQixLQUFJO0FBQUE7O2tCQUdSO0FBQUEiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsidGlja2V0LnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XHJcbiAgPGRpdiBjbGFzcz1cImZsZXggcC00IGp1c3RpZnktY2VudGVyIG0tNFwiPlxyXG4gICAgPFJvdXRlckxpbmtcclxuICAgICAgdG89XCIvdGlja2V0L2J1eVwiXHJcbiAgICAgIGNsYXNzPVwiYmctQWNjZW50Qmx1ZSB0ZXh0LTJ4bCBsZzp0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1NYWluV2hpdGUgcm91bmRlZCBweS0xLjUgcHg0IHRyYW5zaXRpb24gZWFzZS1pbi1vdXQgZHVyYXRpb24tMzAwIGhvdmVyOmJnLXNreS02MDAgaG92ZXI6dGV4dC1CZ0JsYWNrIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpiZy10cmFuc3BhcmVudCBmb2N1czpyaW5nLTQgZm9jdXM6cmluZy1za3ktNjAwIGZvY3VzOnRleHQtQWNjZW50Qmx1ZVwiXHJcbiAgICA+XHJcbiAgICAgIEJ1eSB0aWNrZXRzXHJcbiAgICA8L1JvdXRlckxpbms+XHJcbiAgPC9kaXY+XHJcblxyXG4gIDwhLS0gc2hvdyB0aWNrZXRzIGZyb20gdXNlciBpZiBsb2dnZWQgaW4gLS0+XHJcbiAgPGRpdiBjbGFzcz1cImZsZXgganVzdGlmeS1jZW50ZXJcIj5cclxuICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlLWF1dG8gdy04LzEyXCIgdi1pZj1cIiF0aWNrZXRzTG9hZGluZ1wiPlxyXG4gICAgICA8dGhlYWQgY2xhc3M9XCJcIj5cclxuICAgICAgICA8dHI+XHJcbiAgICAgICAgICA8dGggY2xhc3M9XCJwci04IHBsLTIgcGItNCBib3JkZXItclwiPnR5cGU8L3RoPlxyXG4gICAgICAgICAgPHRoIGNsYXNzPVwicHItOCBwYi00IHBsLTIgYm9yZGVyLXJcIj5kYXk8L3RoPlxyXG4gICAgICAgICAgPHRoIGNsYXNzPVwicGItNCBib3JkZXItclwiPmJhcmNvZGU8L3RoPlxyXG4gICAgICAgIDwvdHI+XHJcbiAgICAgIDwvdGhlYWQ+XHJcbiAgICAgIDx0Ym9keT5cclxuICAgICAgICA8dHJcclxuICAgICAgICAgIHYtZm9yPVwiaXRlbSBpbiB0aWNrZXRzUmVzdWx0LmdldFRpY2tldHNCeVVzZXJJZFwiXHJcbiAgICAgICAgICBjbGFzcz1cIm9kZDpiZy1ibGFjay8xNVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPCEtLSA8ZGl2IHYtaWY9XCJpdGVtLmlzVXNlZCA9PSBmYWxzZSAmJiBuZXcgRGF0ZShpdGVtLmVuZERheSkgPiBuZXcgRGF0ZSgpXCI+IC0tPlxyXG4gICAgICAgICAgPHRkIGNsYXNzPVwiYm9yZGVyLXIgcC0yXCI+e3sgaXRlbS50eXBlLm5hbWUgfX08L3RkPlxyXG4gICAgICAgICAgPHRkIGNsYXNzPVwiYm9yZGVyLXIgcC0yXCI+XHJcbiAgICAgICAgICAgIHt7IG5ldyBEYXRlKGl0ZW0uZW5kRGF5KS50b0xvY2FsZURhdGVTdHJpbmcoKSB9fVxyXG4gICAgICAgICAgPC90ZD5cclxuICAgICAgICAgIDx0ZCBjbGFzcz1cImJvcmRlci1yIGZsZXgganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPHZ1ZS1iYXJjb2RlXHJcbiAgICAgICAgICAgICAgdi1iaW5kOnZhbHVlPVwiaXRlbS5iYXJjb2RlXCJcclxuICAgICAgICAgICAgICB2LW1vZGVsPVwiaXRlbS5iYXJjb2RlXCJcclxuICAgICAgICAgICAgICB0YWc9XCJzdmdcIlxyXG4gICAgICAgICAgICA+PC92dWUtYmFyY29kZT5cclxuICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICA8IS0tIDwvZGl2PiAtLT5cclxuICAgICAgICA8L3RyPlxyXG4gICAgICA8L3Rib2R5PlxyXG4gICAgPC90YWJsZT5cclxuICA8L2Rpdj5cclxuPC90ZW1wbGF0ZT5cclxuXHJcbjxzY3JpcHQgc2V0dXAgbGFuZz1cInRzXCI+XHJcbmltcG9ydCB1c2VGaXJlYmFzZSBmcm9tIFwiQC9jb21wb3NhYmxlcy91c2VGaXJlYmFzZVwiXHJcbmltcG9ydCB7IEdFVF9BTExfVElDS0VUU19CWV9VSUQgfSBmcm9tIFwiQC9ncmFwaHFsL2FsbFRpY2tldHNCeVVpZFwiXHJcbmltcG9ydCBWdWVCYXJjb2RlIGZyb20gXCJAY2hlbmZlbmd5dWFuL3Z1ZS1iYXJjb2RlXCJcclxuaW1wb3J0IHsgY3JlYXRlQXBwIH0gZnJvbSBcInZ1ZVwiXHJcbmltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSBcIkB2dWUvYXBvbGxvLWNvbXBvc2FibGVcIlxyXG5pbXBvcnQgeyBjb21wdXRlZCB9IGZyb20gXCJ2dWVcIlxyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwidnVlLXJvdXRlclwiXHJcbmltcG9ydCB7IHdhdGNoIH0gZnJvbSBcInZ1ZVwiXHJcblxyXG5jb25zdCBhcHAgPSBjcmVhdGVBcHAoe1xyXG4gIGNvbXBvbmVudHM6IHtcclxuICAgIFZ1ZUJhcmNvZGUsXHJcbiAgfSxcclxufSlcclxuXHJcbmNvbnN0IHsgcmVwbGFjZSB9ID0gdXNlUm91dGVyKClcclxuY29uc3QgeyBmaXJlYmFzZVVzZXIgfSA9IHVzZUZpcmViYXNlKClcclxuXHJcbmlmICghZmlyZWJhc2VVc2VyLnZhbHVlKSB7XHJcbiAgcmVwbGFjZShcIi90aWNrZXQvYnV5XCIpXHJcbn1cclxuXHJcbmNvbnN0IHtcclxuICByZXN1bHQ6IHRpY2tldHNSZXN1bHQsXHJcbiAgb25SZXN1bHQsXHJcbiAgbG9hZGluZzogdGlja2V0c0xvYWRpbmcsXHJcbn0gPSB1c2VRdWVyeShHRVRfQUxMX1RJQ0tFVFNfQllfVUlEKVxyXG5cclxud2F0Y2godGlja2V0c1Jlc3VsdCwgKCkgPT4ge1xyXG4gIGNvbnNvbGUubG9nKHRpY2tldHNSZXN1bHQudmFsdWUpXHJcbiAgdGlja2V0c1Jlc3VsdC52YWx1ZS5nZXRUaWNrZXRzQnlVc2VySWQuZmlsdGVyKFxyXG4gICAgKGl0ZW06IGFueSkgPT4gaXRlbS5pc1VzZWQgPT0gZmFsc2UgJiYgbmV3IERhdGUoaXRlbS5lbmREYXkpID4gbmV3IERhdGUoKSxcclxuICApXHJcbn0pXHJcblxyXG4vLyBvblJlc3VsdCgoKSA9PiB7XHJcbi8vICAgY29uc29sZS5sb2codGlja2V0c1Jlc3VsdC52YWx1ZSlcclxuLy8gICB0aWNrZXRzUmVzdWx0LnZhbHVlLmdldFRpY2tldHNCeVVzZXJJZC5maWx0ZXIoXHJcbi8vICAgICAoaXRlbTogYW55KSA9PiBpdGVtLmlzVXNlZCA9PSBmYWxzZSAmJiBuZXcgRGF0ZShpdGVtLmVuZERheSkgPiBuZXcgRGF0ZSgpLFxyXG4vLyAgIClcclxuLy8gICBjb25zb2xlLmxvZyh0aWNrZXRzUmVzdWx0LnZhbHVlKVxyXG4vLyB9KVxyXG5cclxuLy8gY29uc3QgdmFsaWRUaWNrZXRzID0gY29tcHV0ZWQoKCkgPT4ge1xyXG4vLyAgIHJldHVybiB0aWNrZXRzUmVzdWx0LnZhbHVlLmdldFRpY2tldHNCeVVzZXJJZC5maWx0ZXIoXHJcbi8vICAgICAoaXRlbTogYW55KSA9PiBpdGVtLmlzVXNlZCA9PSBmYWxzZSAmJiBuZXcgRGF0ZShpdGVtLmVuZERheSkgPiBuZXcgRGF0ZSgpLFxyXG4vLyAgIClcclxuLy8gfSlcclxuLy8gY29uc29sZS5sb2codmFsaWRUaWNrZXRzLnZhbHVlKVxyXG48L3NjcmlwdD5cclxuIl0sImZpbGUiOiJDOi9BRlNEL0tvYmUtQmVydC9wYWNrYWdlcy9wd2Evc3JjL3ZpZXdzL2NsaWVudC90aWNrZXQudnVlIn0=