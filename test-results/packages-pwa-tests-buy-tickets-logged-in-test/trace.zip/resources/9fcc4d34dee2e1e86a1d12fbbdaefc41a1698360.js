import gql from "/node_modules/.vite/deps/graphql-tag.js?v=69a8df67";
export const GET_ALL_TICKET_TYPES = gql`
  query ticketType {
    getAllTicketTypes {
      name
      amount
      price
      id
    }
  }
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRpY2tldFR5cGVzLnF1ZXJ5LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBncWwgZnJvbSBcImdyYXBocWwtdGFnXCJcclxuXHJcbmV4cG9ydCBjb25zdCBHRVRfQUxMX1RJQ0tFVF9UWVBFUyA9IGdxbGBcclxuICBxdWVyeSB0aWNrZXRUeXBlIHtcclxuICAgIGdldEFsbFRpY2tldFR5cGVzIHtcclxuICAgICAgbmFtZVxyXG4gICAgICBhbW91bnRcclxuICAgICAgcHJpY2VcclxuICAgICAgaWRcclxuICAgIH1cclxuICB9XHJcbmBcclxuIl0sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLFNBQVM7QUFFVCxhQUFNLHVCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTsiLCJuYW1lcyI6W119