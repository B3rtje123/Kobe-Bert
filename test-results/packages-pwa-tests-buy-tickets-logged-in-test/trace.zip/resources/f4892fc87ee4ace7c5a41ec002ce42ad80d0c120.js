import {
  disableExperimentalFragmentVariables,
  disableFragmentWarnings,
  enableExperimentalFragmentVariables,
  gql,
  lib_default,
  resetCaches
} from "/node_modules/.vite/deps/chunk-7GID56CL.js?v=69a8df67";
import "/node_modules/.vite/deps/chunk-NBBOXWME.js?v=69a8df67";
import "/node_modules/.vite/deps/chunk-2ODJBQ45.js?v=69a8df67";
import "/node_modules/.vite/deps/chunk-47VN6MY4.js?v=69a8df67";
import "/node_modules/.vite/deps/chunk-5WWUZCGV.js?v=69a8df67";
export {
  lib_default as default,
  disableExperimentalFragmentVariables,
  disableFragmentWarnings,
  enableExperimentalFragmentVariables,
  gql,
  resetCaches
};
//# sourceMappingURL=graphql-tag.js.map
