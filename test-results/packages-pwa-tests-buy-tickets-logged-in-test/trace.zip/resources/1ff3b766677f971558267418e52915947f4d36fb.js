import gql from "/node_modules/.vite/deps/graphql-tag.js?v=69a8df67";
export const GET_ALL_TICKETS_BY_UID = gql`
  query ticket {
    getTicketsByUserId {
      id
      startDay
      endDay
      type {
        id
        name
        amount
        price
      }
      isUsed
      barcode
    }
  }
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFsbFRpY2tldHNCeVVpZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZ3FsIGZyb20gXCJncmFwaHFsLXRhZ1wiXHJcblxyXG5leHBvcnQgY29uc3QgR0VUX0FMTF9USUNLRVRTX0JZX1VJRCA9IGdxbGBcclxuICBxdWVyeSB0aWNrZXQge1xyXG4gICAgZ2V0VGlja2V0c0J5VXNlcklkIHtcclxuICAgICAgaWRcclxuICAgICAgc3RhcnREYXlcclxuICAgICAgZW5kRGF5XHJcbiAgICAgIHR5cGUge1xyXG4gICAgICAgIGlkXHJcbiAgICAgICAgbmFtZVxyXG4gICAgICAgIGFtb3VudFxyXG4gICAgICAgIHByaWNlXHJcbiAgICAgIH1cclxuICAgICAgaXNVc2VkXHJcbiAgICAgIGJhcmNvZGVcclxuICAgIH1cclxuICB9XHJcbmBcclxuIl0sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLFNBQVM7QUFFVCxhQUFNLHlCQUF5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOyIsIm5hbWVzIjpbXX0=