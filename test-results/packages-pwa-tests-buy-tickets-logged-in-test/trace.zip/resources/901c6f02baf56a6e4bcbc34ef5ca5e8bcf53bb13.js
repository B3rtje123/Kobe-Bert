import gql from "/node_modules/.vite/deps/graphql-tag.js?v=69a8df67";
export const ADD_TICKET = gql`
  mutation Ticket($createTicketInput: CreateTicketInput!) {
    createTicket(createTicketInput: $createTicketInput) {
      startDay
      endDay
      barcode
      type {
        name
      }
    }
  }
`;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNyZWF0ZVRpY2tldC5tdXRhdGlvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZ3FsIGZyb20gXCJncmFwaHFsLXRhZ1wiXHJcblxyXG5leHBvcnQgY29uc3QgQUREX1RJQ0tFVCA9IGdxbGBcclxuICBtdXRhdGlvbiBUaWNrZXQoJGNyZWF0ZVRpY2tldElucHV0OiBDcmVhdGVUaWNrZXRJbnB1dCEpIHtcclxuICAgIGNyZWF0ZVRpY2tldChjcmVhdGVUaWNrZXRJbnB1dDogJGNyZWF0ZVRpY2tldElucHV0KSB7XHJcbiAgICAgIHN0YXJ0RGF5XHJcbiAgICAgIGVuZERheVxyXG4gICAgICBiYXJjb2RlXHJcbiAgICAgIHR5cGUge1xyXG4gICAgICAgIG5hbWVcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuYFxyXG4iXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sU0FBUztBQUVULGFBQU0sYUFBYTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7IiwibmFtZXMiOltdfQ==