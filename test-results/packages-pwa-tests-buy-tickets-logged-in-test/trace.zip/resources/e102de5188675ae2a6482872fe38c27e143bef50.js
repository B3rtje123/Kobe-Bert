import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/generic/CtaButton.vue");const _sfc_main = {}
import { renderSlot as _renderSlot, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=69a8df67"

const _hoisted_1 = { class: "bg-AccentBlue text-2xl lg:text-lg font-semibold text-MainWhite rounded py-1.5 px4 transition ease-in-out duration-300 hover:bg-sky-600 hover:text-BgBlack focus:outline-none focus:bg-transparent focus:ring-4 focus:ring-sky-600 focus:text-AccentBlue" }

function _sfc_render(_ctx, _cache) {
  return (_openBlock(), _createElementBlock("button", _hoisted_1, [
    _renderSlot(_ctx.$slots, "default")
  ]))
}


_sfc_main.__hmrId = "4c5fc9d8"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/AFSD/Kobe-Bert/packages/pwa/src/components/generic/CtaButton.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkN0YUJ1dHRvbi52dWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7cUJBQ1ksS0FBSyxFQUFDLHlQQUVnRjs7O3dCQUY5RixvQkFLUyxVQUxULFVBS1M7SUFGTCxZQUFhIiwiZmlsZSI6IkM6L0FGU0QvS29iZS1CZXJ0L3BhY2thZ2VzL3B3YS9zcmMvY29tcG9uZW50cy9nZW5lcmljL0N0YUJ1dHRvbi52dWUiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxyXG4gICAgPGJ1dHRvbiBjbGFzcz1cImJnLUFjY2VudEJsdWUgdGV4dC0yeGwgbGc6dGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtTWFpbldoaXRlIHJvdW5kZWQgcHktMS41IHB4NCB0cmFuc2l0aW9uIGVhc2UtaW4tb3V0IGR1cmF0aW9uLTMwMFxyXG4gICAgaG92ZXI6Ymctc2t5LTYwMCBob3Zlcjp0ZXh0LUJnQmxhY2tcclxuICAgIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpiZy10cmFuc3BhcmVudCBmb2N1czpyaW5nLTQgZm9jdXM6cmluZy1za3ktNjAwIGZvY3VzOnRleHQtQWNjZW50Qmx1ZVwiPlxyXG4gICAgICAgIDxzbG90Pjwvc2xvdD5cclxuXHJcbiAgICA8L2J1dHRvbj5cclxuPC90ZW1wbGF0ZT4iXX0=