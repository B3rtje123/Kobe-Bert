import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/auth/login.vue");import { defineComponent as _defineComponent } from "/node_modules/.vite/deps/vue.js?v=69a8df67";
import { ref } from "/node_modules/.vite/deps/vue.js?v=69a8df67";
import useFirebase from "/src/composables/useFirebase.ts";
import { useRouter } from "/node_modules/.vite/deps/vue-router.js?v=69a8df67";
const _sfc_main = /* @__PURE__ */ _defineComponent({
  __name: "login",
  setup(__props, { expose: __expose }) {
    __expose();
    const { login, firebaseUser } = useFirebase();
    const { replace } = useRouter();
    const loginCredentials = ref({
      email: "",
      password: ""
    });
    const error = ref(null);
    const showError = ref(false);
    const tooMany = ref(false);
    const wrongLogin = ref(false);
    const isValidEmail = (EmailParameter) => {
      return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(EmailParameter) ? true : false;
    };
    const handleLogin = () => {
      tooMany.value = false;
      wrongLogin.value = false;
      if (isValidEmail(loginCredentials.value.email) == true) {
        login(loginCredentials.value.email, loginCredentials.value.password).then(() => {
          replace("/");
        }).catch((err) => {
          error.value = err;
          console.log(error.value.code);
          if (error.value.code == "auth/invalid-login-credentials") {
            wrongLogin.value = true;
          }
          if (error.value.code == "auth/too-many-requests") {
            tooMany.value = true;
          }
        });
      } else {
        showError.value = true;
        console.log("email of password is niet goed");
      }
    };
    const __returned__ = { login, firebaseUser, replace, loginCredentials, error, showError, tooMany, wrongLogin, isValidEmail, handleLogin };
    Object.defineProperty(__returned__, "__isScriptSetup", { enumerable: false, value: true });
    return __returned__;
  }
});
import { createElementVNode as _createElementVNode, toDisplayString as _toDisplayString, vModelText as _vModelText, withDirectives as _withDirectives, vShow as _vShow, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, withModifiers as _withModifiers, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=69a8df67";
const _hoisted_1 = ["onSubmit"];
const _hoisted_2 = { class: "rounded-lg max-w-sm shadow-[0_0_60px_-25px_rgba(0,0,0,0.3)] shadow-AccentBlue p-12 bg-MainWhite" };
const _hoisted_3 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "text-center m-8" },
  [
    /* @__PURE__ */ _createElementVNode("h1", { class: "text-3xl font-semibold" }, "Log in"),
    /* @__PURE__ */ _createElementVNode("h2", { class: "text-xs mt-1" }, "Enter your account details below")
  ],
  -1
  /* HOISTED */
);
const _hoisted_4 = { class: "text-red-500 font-medium text-center" };
const _hoisted_5 = { class: "text-red-500 font-medium text-center" };
const _hoisted_6 = { class: "mb-6" };
const _hoisted_7 = /* @__PURE__ */ _createElementVNode(
  "label",
  {
    for: "email",
    class: "mb-4 font-medium"
  },
  "Email",
  -1
  /* HOISTED */
);
const _hoisted_8 = { class: "mb-6" };
const _hoisted_9 = /* @__PURE__ */ _createElementVNode(
  "label",
  {
    for: "password",
    class: "mb-4 font-medium"
  },
  "Password",
  -1
  /* HOISTED */
);
const _hoisted_10 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "" },
  [
    /* @__PURE__ */ _createElementVNode("button", {
      type: "submit",
      class: "w-full py-2 border border-hidden rounded-lg mb-8 font-semibold bg-AccentBlue text-MainWhite transition ease-in-out duration-300 hover:bg-BgBlack/25 hover:text-BgBlack focus:outline-none focus:ring-4 focus:ring-AccentBlue focus:bg-[#1B8ACC]"
    }, " Log in ")
  ],
  -1
  /* HOISTED */
);
const _hoisted_11 = /* @__PURE__ */ _createElementVNode(
  "p",
  { class: "p-1" },
  [
    /* @__PURE__ */ _createTextVNode(" Don't have an account yet? "),
    /* @__PURE__ */ _createElementVNode("span", { class: "text-AccentBlue" }, "Sign up")
  ],
  -1
  /* HOISTED */
);
const _hoisted_12 = /* @__PURE__ */ _createElementVNode(
  "div",
  { class: "inline-flex items-center justify-center w-full" },
  [
    /* @__PURE__ */ _createElementVNode("hr", { class: "w-full h-px translate-y-0.5 my-8 bg-BgBlack border-0" }),
    /* @__PURE__ */ _createElementVNode("span", { class: "absolute px-3 font-medium text-BgBlack -translate-x-1/2 bg-MainWhite left-1/2" }, "or")
  ],
  -1
  /* HOISTED */
);
const _hoisted_13 = /* @__PURE__ */ _createElementVNode(
  "p",
  null,
  "Continue without logging in",
  -1
  /* HOISTED */
);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_RouterLink = _resolveComponent("RouterLink");
  return _openBlock(), _createElementBlock("form", {
    onSubmit: _withModifiers($setup.handleLogin, ["prevent"]),
    class: "flex mt-16 justify-center items-center text-BgBlack"
  }, [
    _createElementVNode("div", _hoisted_2, [
      _hoisted_3,
      _createElementVNode(
        "p",
        _hoisted_4,
        _toDisplayString($setup.tooMany ? "You have tried too many times.\nTry again later!" : ""),
        1
        /* TEXT */
      ),
      _createElementVNode(
        "p",
        _hoisted_5,
        _toDisplayString($setup.wrongLogin ? "Email or password is wrong!" : ""),
        1
        /* TEXT */
      ),
      _createElementVNode("div", _hoisted_6, [
        _hoisted_7,
        _withDirectives(_createElementVNode(
          "input",
          {
            type: "text",
            name: "email",
            id: "email",
            placeholder: "example@domain.com",
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => $setup.loginCredentials.email = $event),
            required: "",
            autocomplete: "off",
            class: "block rounded-lg border-2 p-2 shadow-inner shadow-gray-400 w-full transition-colors ease-in-out duration-300 hover:border-AccentBlue focus:outline-none focus:ring-4 focus:ring-AccentBlue",
            onInput: _cache[1] || (_cache[1] = () => {
            })
          },
          null,
          544
          /* HYDRATE_EVENTS, NEED_PATCH */
        ), [
          [_vModelText, $setup.loginCredentials.email]
        ]),
        _withDirectives(_createElementVNode(
          "p",
          { class: "text-red-500" },
          _toDisplayString($setup.isValidEmail($setup.loginCredentials.email) ? "" : "Ongeldig e-mail adres"),
          513
          /* TEXT, NEED_PATCH */
        ), [
          [_vShow, $setup.showError]
        ])
      ]),
      _createElementVNode("div", _hoisted_8, [
        _hoisted_9,
        _withDirectives(_createElementVNode(
          "input",
          {
            type: "text",
            name: "password",
            id: "password",
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => $setup.loginCredentials.password = $event),
            autocomplete: "off",
            class: "block rounded-lg border-2 p-2 shadow-inner shadow-gray-400 w-full transition-colors ease-in-out duration-300 hover:border-AccentBlue focus:outline-none focus:ring-4 focus:ring-AccentBlue"
          },
          null,
          512
          /* NEED_PATCH */
        ), [
          [_vModelText, $setup.loginCredentials.password]
        ])
      ]),
      _hoisted_10,
      _createElementVNode("div", null, [
        _createVNode(_component_RouterLink, {
          to: "/auth/register",
          class: "font-normal text-sm focus:outline-AccentBlue"
        }, {
          default: _withCtx(() => [
            _hoisted_11
          ]),
          _: 1
          /* STABLE */
        })
      ]),
      _hoisted_12,
      _createVNode(_component_RouterLink, {
        to: "/",
        class: "flex border border-BgBlack justify-center py-3 rounded-lg w-full hover:font-semibold focus:outline-none focus:ring-4 focus:ring-AccentBlue focus:border-AccentBlue focus:font-medium"
      }, {
        default: _withCtx(() => [
          _hoisted_13
        ]),
        _: 1
        /* STABLE */
      })
    ])
  ], 40, _hoisted_1);
}
_sfc_main.__hmrId = "50c09a87";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.accept((mod) => {
  if (!mod)
    return;
  const { default: updated, _rerender_only } = mod;
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
  }
});
import _export_sfc from "/@id/__x00__plugin-vue:export-helper";
export default /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "C:/AFSD/Kobe-Bert/packages/pwa/src/views/auth/login.vue"]]);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQTRGQSxTQUFTLFdBQVc7QUFHcEIsT0FBTyxpQkFBaUI7QUFDeEIsU0FBUyxpQkFBaUI7Ozs7O0FBRzFCLFVBQU0sRUFBRSxPQUFPLGFBQWEsSUFBSSxZQUFZO0FBQzVDLFVBQU0sRUFBRSxRQUFRLElBQUksVUFBVTtBQUc5QixVQUFNLG1CQUFtQixJQUFJO0FBQUEsTUFDM0IsT0FBTztBQUFBLE1BQ1AsVUFBVTtBQUFBLElBQ1osQ0FBQztBQUNELFVBQU0sUUFBUSxJQUFzQixJQUFJO0FBQ3hDLFVBQU0sWUFBWSxJQUFJLEtBQUs7QUFDM0IsVUFBTSxVQUFVLElBQUksS0FBSztBQUN6QixVQUFNLGFBQWEsSUFBSSxLQUFLO0FBRTVCLFVBQU0sZUFBZSxDQUFDLG1CQUEyQjtBQUMvQyxhQUFPLGdEQUFnRCxLQUFLLGNBQWMsSUFDdEUsT0FDQTtBQUFBLElBQ047QUFFQSxVQUFNLGNBQWMsTUFBTTtBQUN4QixjQUFRLFFBQVE7QUFDaEIsaUJBQVcsUUFBUTtBQUNuQixVQUFJLGFBQWEsaUJBQWlCLE1BQU0sS0FBSyxLQUFLLE1BQU07QUFDdEQsY0FBTSxpQkFBaUIsTUFBTSxPQUFPLGlCQUFpQixNQUFNLFFBQVEsRUFDaEUsS0FBSyxNQUFNO0FBQ1Ysa0JBQVEsR0FBRztBQUFBLFFBQ2IsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxRQUFtQjtBQUN6QixnQkFBTSxRQUFRO0FBQ2Qsa0JBQVEsSUFBSSxNQUFNLE1BQU0sSUFBSTtBQUM1QixjQUFJLE1BQU0sTUFBTSxRQUFRLGtDQUFrQztBQUN4RCx1QkFBVyxRQUFRO0FBQUEsVUFDckI7QUFDQSxjQUFJLE1BQU0sTUFBTSxRQUFRLDBCQUEwQjtBQUNoRCxvQkFBUSxRQUFRO0FBQUEsVUFDbEI7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNMLE9BQU87QUFDTCxrQkFBVSxRQUFRO0FBQ2xCLGdCQUFRLElBQUksZ0NBQWdDO0FBQUEsTUFDOUM7QUFBQSxJQUNGOzs7Ozs7OztxQkF0SU0sT0FBTSxrR0FBaUc7bUJBRXZHO0FBQUEsRUFHTTtBQUFBLElBSEQsT0FBTSxrQkFBaUI7QUFBQTtBQUFBLElBQzFCLG9DQUE4QyxRQUExQyxPQUFNLHlCQUF3QixHQUFDLFFBQU07QUFBQSxJQUN6QyxvQ0FBOEQsUUFBMUQsT0FBTSxlQUFjLEdBQUMsa0NBQWdDO0FBQUE7Ozs7cUJBR3hELE9BQU0sdUNBQXNDO3FCQUc1QyxPQUFNLHVDQUFzQztxQkFJMUMsT0FBTSxPQUFNO21CQUNmO0FBQUEsRUFBeUQ7QUFBQTtBQUFBLElBQWxELEtBQUk7QUFBQSxJQUFRLE9BQU07QUFBQTtFQUFtQjtBQUFBLEVBQUs7QUFBQTtBQUFBO3FCQW1COUMsT0FBTSxPQUFNO21CQUNmO0FBQUEsRUFBK0Q7QUFBQTtBQUFBLElBQXhELEtBQUk7QUFBQSxJQUFXLE9BQU07QUFBQTtFQUFtQjtBQUFBLEVBQVE7QUFBQTtBQUFBO29CQVd6RDtBQUFBLEVBT007QUFBQSxJQVBELE9BQU0sR0FBRTtBQUFBO0FBQUEsSUFDWCxvQ0FLUztBQUFBLE1BSlAsTUFBSztBQUFBLE1BQ0wsT0FBTTtBQUFBLE9BQ1AsVUFFRDtBQUFBOzs7O29CQVFFO0FBQUEsRUFHSTtBQUFBLElBSEQsT0FBTSxNQUFLO0FBQUE7QUFBQSxxQ0FBQyw4QkFFYjtBQUFBLHdDQUE0QyxVQUF0QyxPQUFNLGtCQUFpQixHQUFDLFNBQU87QUFBQTs7OztvQkFLM0M7QUFBQSxFQU1NO0FBQUEsSUFORCxPQUFNLGlEQUFnRDtBQUFBO0FBQUEsSUFDekQsb0NBQW1FLFFBQS9ELE9BQU0sdURBQXNEO0FBQUEsSUFDaEUsb0NBR0MsVUFGQyxPQUFNLGdGQUErRSxHQUNwRixJQUFFO0FBQUE7Ozs7b0JBUUw7QUFBQSxFQUFrQztBQUFBO0FBQUEsRUFBL0I7QUFBQSxFQUEyQjtBQUFBO0FBQUE7Ozt1QkFwRnBDLG9CQXVGTztBQUFBLElBdEZKLFVBQU0sZUFBVSxvQkFBVztBQUFBLElBQzVCLE9BQU07QUFBQTtJQUVOLG9CQWtGTSxPQWxGTixZQWtGTTtBQUFBLE1BL0VKO0FBQUEsTUFLQTtBQUFBLFFBRUk7QUFBQSxRQUZKO0FBQUEsUUFFSSxpQkFEQyxpQkFBTztBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRVo7QUFBQSxRQUVJO0FBQUEsUUFGSjtBQUFBLFFBRUksaUJBREMsb0JBQVU7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdmLG9CQWtCTSxPQWxCTixZQWtCTTtBQUFBLFFBakJKO0FBQUEsd0JBQ0E7QUFBQSxVQVVFO0FBQUE7QUFBQSxZQVRBLE1BQUs7QUFBQSxZQUNMLE1BQUs7QUFBQSxZQUNMLElBQUc7QUFBQSxZQUNILGFBQVk7QUFBQSx5RUFDSCx3QkFBaUIsUUFBSztBQUFBLFlBQy9CO0FBQUEsWUFDQSxjQUFhO0FBQUEsWUFDYixPQUFNO0FBQUEsWUFDTCxTQUFLLDBCQUFOO0FBQUE7QUFBQTs7Ozs7d0JBSlMsd0JBQWlCLEtBQUs7QUFBQTt3QkFNakM7QUFBQSxVQUlJO0FBQUEsWUFKa0IsT0FBTSxlQUFjO0FBQUEsMkJBRXRDLG9CQUFhLHdCQUFpQixLQUFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRjVCLGdCQUFTO0FBQUE7O01BT3RCLG9CQVVNLE9BVk4sWUFVTTtBQUFBLFFBVEo7QUFBQSx3QkFDQTtBQUFBLFVBT0U7QUFBQTtBQUFBLFlBTkEsTUFBSztBQUFBLFlBQ0wsTUFBSztBQUFBLFlBQ0wsSUFBRztBQUFBLHlFQUNNLHdCQUFpQixXQUFRO0FBQUEsWUFDbEMsY0FBYTtBQUFBLFlBQ2IsT0FBTTtBQUFBOzs7Ozt3QkFGRyx3QkFBaUIsUUFBUTtBQUFBOztNQU10QztBQUFBLE1BU0Esb0JBVU07QUFBQSxRQVRKLGFBUWE7QUFBQSxVQVBYLElBQUc7QUFBQSxVQUNILE9BQU07QUFBQTs0QkFFTixNQUdJO0FBQUEsWUFISjtBQUFBOzs7OztNQU9KO0FBQUEsTUFRQSxhQUthO0FBQUEsUUFKWCxJQUFHO0FBQUEsUUFDSCxPQUFNO0FBQUE7MEJBRU4sTUFBa0M7QUFBQSxVQUFsQztBQUFBIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImxvZ2luLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XHJcbiAgPGZvcm1cclxuICAgIEBzdWJtaXQucHJldmVudD1cImhhbmRsZUxvZ2luXCJcclxuICAgIGNsYXNzPVwiZmxleCBtdC0xNiBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgdGV4dC1CZ0JsYWNrXCJcclxuICA+XHJcbiAgICA8ZGl2XHJcbiAgICAgIGNsYXNzPVwicm91bmRlZC1sZyBtYXgtdy1zbSBzaGFkb3ctWzBfMF82MHB4Xy0yNXB4X3JnYmEoMCwwLDAsMC4zKV0gc2hhZG93LUFjY2VudEJsdWUgcC0xMiBiZy1NYWluV2hpdGVcIlxyXG4gICAgPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwidGV4dC1jZW50ZXIgbS04XCI+XHJcbiAgICAgICAgPGgxIGNsYXNzPVwidGV4dC0zeGwgZm9udC1zZW1pYm9sZFwiPkxvZyBpbjwvaDE+XHJcbiAgICAgICAgPGgyIGNsYXNzPVwidGV4dC14cyBtdC0xXCI+RW50ZXIgeW91ciBhY2NvdW50IGRldGFpbHMgYmVsb3c8L2gyPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxwIGNsYXNzPVwidGV4dC1yZWQtNTAwIGZvbnQtbWVkaXVtIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAge3sgdG9vTWFueSA/IFwiWW91IGhhdmUgdHJpZWQgdG9vIG1hbnkgdGltZXMuXFxuVHJ5IGFnYWluIGxhdGVyIVwiIDogXCJcIiB9fVxyXG4gICAgICA8L3A+XHJcbiAgICAgIDxwIGNsYXNzPVwidGV4dC1yZWQtNTAwIGZvbnQtbWVkaXVtIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAge3sgd3JvbmdMb2dpbiA/IFwiRW1haWwgb3IgcGFzc3dvcmQgaXMgd3JvbmchXCIgOiBcIlwiIH19XHJcbiAgICAgIDwvcD5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3M9XCJtYi02XCI+XHJcbiAgICAgICAgPGxhYmVsIGZvcj1cImVtYWlsXCIgY2xhc3M9XCJtYi00IGZvbnQtbWVkaXVtXCI+RW1haWw8L2xhYmVsPlxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgbmFtZT1cImVtYWlsXCJcclxuICAgICAgICAgIGlkPVwiZW1haWxcIlxyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJleGFtcGxlQGRvbWFpbi5jb21cIlxyXG4gICAgICAgICAgdi1tb2RlbD1cImxvZ2luQ3JlZGVudGlhbHMuZW1haWxcIlxyXG4gICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgIGF1dG9jb21wbGV0ZT1cIm9mZlwiXHJcbiAgICAgICAgICBjbGFzcz1cImJsb2NrIHJvdW5kZWQtbGcgYm9yZGVyLTIgcC0yIHNoYWRvdy1pbm5lciBzaGFkb3ctZ3JheS00MDAgdy1mdWxsIHRyYW5zaXRpb24tY29sb3JzIGVhc2UtaW4tb3V0IGR1cmF0aW9uLTMwMCBob3Zlcjpib3JkZXItQWNjZW50Qmx1ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctQWNjZW50Qmx1ZVwiXHJcbiAgICAgICAgICBAaW5wdXQ9XCJcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPHAgdi1zaG93PVwic2hvd0Vycm9yXCIgY2xhc3M9XCJ0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgIHt7XHJcbiAgICAgICAgICAgIGlzVmFsaWRFbWFpbChsb2dpbkNyZWRlbnRpYWxzLmVtYWlsKSA/IFwiXCIgOiBcIk9uZ2VsZGlnIGUtbWFpbCBhZHJlc1wiXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzPVwibWItNlwiPlxyXG4gICAgICAgIDxsYWJlbCBmb3I9XCJwYXNzd29yZFwiIGNsYXNzPVwibWItNCBmb250LW1lZGl1bVwiPlBhc3N3b3JkPC9sYWJlbD5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICBpZD1cInBhc3N3b3JkXCJcclxuICAgICAgICAgIHYtbW9kZWw9XCJsb2dpbkNyZWRlbnRpYWxzLnBhc3N3b3JkXCJcclxuICAgICAgICAgIGF1dG9jb21wbGV0ZT1cIm9mZlwiXHJcbiAgICAgICAgICBjbGFzcz1cImJsb2NrIHJvdW5kZWQtbGcgYm9yZGVyLTIgcC0yIHNoYWRvdy1pbm5lciBzaGFkb3ctZ3JheS00MDAgdy1mdWxsIHRyYW5zaXRpb24tY29sb3JzIGVhc2UtaW4tb3V0IGR1cmF0aW9uLTMwMCBob3Zlcjpib3JkZXItQWNjZW50Qmx1ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctQWNjZW50Qmx1ZVwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzPVwiXCI+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICBjbGFzcz1cInctZnVsbCBweS0yIGJvcmRlciBib3JkZXItaGlkZGVuIHJvdW5kZWQtbGcgbWItOCBmb250LXNlbWlib2xkIGJnLUFjY2VudEJsdWUgdGV4dC1NYWluV2hpdGUgdHJhbnNpdGlvbiBlYXNlLWluLW91dCBkdXJhdGlvbi0zMDAgaG92ZXI6YmctQmdCbGFjay8yNSBob3Zlcjp0ZXh0LUJnQmxhY2sgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctNCBmb2N1czpyaW5nLUFjY2VudEJsdWUgZm9jdXM6YmctWyMxQjhBQ0NdXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICBMb2cgaW5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxSb3V0ZXJMaW5rXHJcbiAgICAgICAgICB0bz1cIi9hdXRoL3JlZ2lzdGVyXCJcclxuICAgICAgICAgIGNsYXNzPVwiZm9udC1ub3JtYWwgdGV4dC1zbSBmb2N1czpvdXRsaW5lLUFjY2VudEJsdWVcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxwIGNsYXNzPVwicC0xXCI+XHJcbiAgICAgICAgICAgIERvbid0IGhhdmUgYW4gYWNjb3VudCB5ZXQ/XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1BY2NlbnRCbHVlXCI+U2lnbiB1cDwvc3Bhbj5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L1JvdXRlckxpbms+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzcz1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LWZ1bGxcIj5cclxuICAgICAgICA8aHIgY2xhc3M9XCJ3LWZ1bGwgaC1weCB0cmFuc2xhdGUteS0wLjUgbXktOCBiZy1CZ0JsYWNrIGJvcmRlci0wXCIgLz5cclxuICAgICAgICA8c3BhblxyXG4gICAgICAgICAgY2xhc3M9XCJhYnNvbHV0ZSBweC0zIGZvbnQtbWVkaXVtIHRleHQtQmdCbGFjayAtdHJhbnNsYXRlLXgtMS8yIGJnLU1haW5XaGl0ZSBsZWZ0LTEvMlwiXHJcbiAgICAgICAgICA+b3I8L3NwYW5cclxuICAgICAgICA+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPFJvdXRlckxpbmtcclxuICAgICAgICB0bz1cIi9cIlxyXG4gICAgICAgIGNsYXNzPVwiZmxleCBib3JkZXIgYm9yZGVyLUJnQmxhY2sganVzdGlmeS1jZW50ZXIgcHktMyByb3VuZGVkLWxnIHctZnVsbCBob3Zlcjpmb250LXNlbWlib2xkIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTQgZm9jdXM6cmluZy1BY2NlbnRCbHVlIGZvY3VzOmJvcmRlci1BY2NlbnRCbHVlIGZvY3VzOmZvbnQtbWVkaXVtXCJcclxuICAgICAgPlxyXG4gICAgICAgIDxwPkNvbnRpbnVlIHdpdGhvdXQgbG9nZ2luZyBpbjwvcD5cclxuICAgICAgPC9Sb3V0ZXJMaW5rPlxyXG4gICAgPC9kaXY+XHJcbiAgPC9mb3JtPlxyXG48L3RlbXBsYXRlPlxyXG5cclxuPHNjcmlwdCBzZXR1cCBsYW5nPVwidHNcIj5cclxuaW1wb3J0IHsgcmVmIH0gZnJvbSBcInZ1ZVwiXHJcbmltcG9ydCB7IEF1dGhFcnJvckNvZGVzLCB0eXBlIEF1dGhFcnJvciB9IGZyb20gXCJmaXJlYmFzZS9hdXRoXCJcclxuXHJcbmltcG9ydCB1c2VGaXJlYmFzZSBmcm9tIFwiQC9jb21wb3NhYmxlcy91c2VGaXJlYmFzZVwiXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJ2dWUtcm91dGVyXCJcclxuXHJcbi8vY29tcG9zYWJsZXNcclxuY29uc3QgeyBsb2dpbiwgZmlyZWJhc2VVc2VyIH0gPSB1c2VGaXJlYmFzZSgpXHJcbmNvbnN0IHsgcmVwbGFjZSB9ID0gdXNlUm91dGVyKClcclxuXHJcbi8vbG9naWNcclxuY29uc3QgbG9naW5DcmVkZW50aWFscyA9IHJlZih7XHJcbiAgZW1haWw6IFwiXCIsXHJcbiAgcGFzc3dvcmQ6IFwiXCIsXHJcbn0pXHJcbmNvbnN0IGVycm9yID0gcmVmPEF1dGhFcnJvciB8IG51bGw+KG51bGwpXHJcbmNvbnN0IHNob3dFcnJvciA9IHJlZihmYWxzZSlcclxuY29uc3QgdG9vTWFueSA9IHJlZihmYWxzZSlcclxuY29uc3Qgd3JvbmdMb2dpbiA9IHJlZihmYWxzZSlcclxuXHJcbmNvbnN0IGlzVmFsaWRFbWFpbCA9IChFbWFpbFBhcmFtZXRlcjogc3RyaW5nKSA9PiB7XHJcbiAgcmV0dXJuIC9eXFx3KyhbXFwuLV0/XFx3KykqQFxcdysoW1xcLi1dP1xcdyspKihcXC5cXHd7MiwzfSkrJC8udGVzdChFbWFpbFBhcmFtZXRlcilcclxuICAgID8gdHJ1ZVxyXG4gICAgOiBmYWxzZVxyXG59XHJcblxyXG5jb25zdCBoYW5kbGVMb2dpbiA9ICgpID0+IHtcclxuICB0b29NYW55LnZhbHVlID0gZmFsc2VcclxuICB3cm9uZ0xvZ2luLnZhbHVlID0gZmFsc2VcclxuICBpZiAoaXNWYWxpZEVtYWlsKGxvZ2luQ3JlZGVudGlhbHMudmFsdWUuZW1haWwpID09IHRydWUpIHtcclxuICAgIGxvZ2luKGxvZ2luQ3JlZGVudGlhbHMudmFsdWUuZW1haWwsIGxvZ2luQ3JlZGVudGlhbHMudmFsdWUucGFzc3dvcmQpXHJcbiAgICAgIC50aGVuKCgpID0+IHtcclxuICAgICAgICByZXBsYWNlKFwiL1wiKVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycjogQXV0aEVycm9yKSA9PiB7XHJcbiAgICAgICAgZXJyb3IudmFsdWUgPSBlcnJcclxuICAgICAgICBjb25zb2xlLmxvZyhlcnJvci52YWx1ZS5jb2RlKVxyXG4gICAgICAgIGlmIChlcnJvci52YWx1ZS5jb2RlID09IFwiYXV0aC9pbnZhbGlkLWxvZ2luLWNyZWRlbnRpYWxzXCIpIHtcclxuICAgICAgICAgIHdyb25nTG9naW4udmFsdWUgPSB0cnVlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChlcnJvci52YWx1ZS5jb2RlID09IFwiYXV0aC90b28tbWFueS1yZXF1ZXN0c1wiKSB7XHJcbiAgICAgICAgICB0b29NYW55LnZhbHVlID0gdHJ1ZVxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICB9IGVsc2Uge1xyXG4gICAgc2hvd0Vycm9yLnZhbHVlID0gdHJ1ZVxyXG4gICAgY29uc29sZS5sb2coXCJlbWFpbCBvZiBwYXNzd29yZCBpcyBuaWV0IGdvZWRcIilcclxuICB9XHJcbn1cclxuPC9zY3JpcHQ+XHJcbiJdLCJmaWxlIjoiQzovQUZTRC9Lb2JlLUJlcnQvcGFja2FnZXMvcHdhL3NyYy92aWV3cy9hdXRoL2xvZ2luLnZ1ZSJ9