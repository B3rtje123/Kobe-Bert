import.meta.env = {"VITE_apiKey":"AIzaSyDRyDZKvLHOsjdItTsl6IEqsGcFqtJ4KQo","VITE_authDomain":"pretpark-929b6.firebaseapp.com","VITE_projectId":"pretpark-929b6","VITE_storageBucket":"pretpark-929b6.appspot.com","VITE_messagingSenderId":"69976698416","VITE_appId":"1:69976698416:web:d23a0a7b80c81b6d4c07f5","VITE_measurementId":"G-2GQTGNKRSS","VITE_BACKEND_URL":"http://[::1]:3000/graphql","BASE_URL":"/","MODE":"development","DEV":true,"PROD":false,"SSR":false};import { createRouter, createWebHistory } from "/node_modules/.vite/deps/vue-router.js?v=69a8df67";
import useFirebase from "/src/composables/useFirebase.ts";
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    //general
    {
      path: "/",
      name: "home",
      component: () => import("/src/views/home.vue")
    },
    //client
    {
      path: "/ticket",
      name: "ticket",
      component: () => import("/src/views/client/ticket.vue")
    },
    {
      path: "/ticket/buy",
      name: "buyTicket",
      component: () => import("/src/views/client/buyTicket.vue")
    },
    {
      path: "/helpdesk",
      name: "helpdesk",
      component: () => import("/src/views/client/helpdesk.vue")
    },
    {
      path: "/FAQ",
      name: "FAQ",
      component: () => import("/src/views/client/FAQ.vue")
    },
    {
      path: "/bestelling",
      name: "bestelling",
      component: () => import("/src/views/client/bestelling.vue")
    },
    //admin
    {
      path: "/attractie",
      name: "attracties",
      component: () => import("/src/views/admin/attractie.vue")
      // meta: { shouldBeAuthenticated: true },
    },
    {
      path: "/personeel",
      name: "personeel",
      component: () => import("/src/views/admin/personeel.vue"),
      meta: { shouldBeAuthenticated: true }
    },
    {
      path: "/restaurant",
      name: "restaurants",
      component: () => import("/src/views/admin/restaurant.vue")
      // meta: { shouldBeAuthenticated: true },
    },
    {
      path: "/shop",
      name: "shop",
      component: () => import("/src/views/admin/shop.vue"),
      meta: { shouldBeAuthenticated: true }
    },
    //authentification
    {
      path: "/auth",
      component: () => import("/src/components/wrappers/AuthWrap.vue")
    },
    {
      path: "/auth/login",
      name: "login",
      component: () => import("/src/views/auth/login.vue")
    },
    {
      path: "/auth/register",
      name: "register",
      component: () => import("/src/views/auth/register.vue")
    },
    {
      path: "/auth/forgot-password",
      name: "forgotPassword",
      component: () => import("/src/views/auth/forgotPassword.vue")
    },
    {
      path: "/profile",
      name: "Account",
      component: () => import("/src/views/profile.vue")
    },
    //404
    {
      path: "/:pathMatch(.*)*",
      name: "not-found",
      component: () => import("/src/views/404Page.vue")
    }
  ]
});
router.beforeEach(async (to, from, next) => {
  const { firebaseUser } = useFirebase();
  if (to.meta.shouldBeAuthenticated && !firebaseUser.value) {
    console.log("HACKER");
    next({ path: "/auth/login" });
  } else {
    next();
  }
});
export default router;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJvdXRlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVSb3V0ZXIsIGNyZWF0ZVdlYkhpc3RvcnkgfSBmcm9tIFwidnVlLXJvdXRlclwiXHJcblxyXG5pbXBvcnQgdXNlRmlyZWJhc2UgZnJvbSBcIkAvY29tcG9zYWJsZXMvdXNlRmlyZWJhc2VcIlxyXG5cclxuY29uc3Qgcm91dGVyID0gY3JlYXRlUm91dGVyKHtcclxuICBoaXN0b3J5OiBjcmVhdGVXZWJIaXN0b3J5KGltcG9ydC5tZXRhLmVudi5CQVNFX1VSTCksXHJcbiAgcm91dGVzOiBbXHJcbiAgICAvL2dlbmVyYWxcclxuICAgIHtcclxuICAgICAgcGF0aDogXCIvXCIsXHJcbiAgICAgIG5hbWU6IFwiaG9tZVwiLFxyXG4gICAgICBjb21wb25lbnQ6ICgpID0+IGltcG9ydChcIi4uL3ZpZXdzL2hvbWUudnVlXCIpLFxyXG4gICAgfSxcclxuICAgIC8vY2xpZW50XHJcbiAgICB7XHJcbiAgICAgIHBhdGg6IFwiL3RpY2tldFwiLFxyXG4gICAgICBuYW1lOiBcInRpY2tldFwiLFxyXG4gICAgICBjb21wb25lbnQ6ICgpID0+IGltcG9ydChcIi4uL3ZpZXdzL2NsaWVudC90aWNrZXQudnVlXCIpLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcGF0aDogXCIvdGlja2V0L2J1eVwiLFxyXG4gICAgICBuYW1lOiBcImJ1eVRpY2tldFwiLFxyXG4gICAgICBjb21wb25lbnQ6ICgpID0+IGltcG9ydChcIi4uL3ZpZXdzL2NsaWVudC9idXlUaWNrZXQudnVlXCIpLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcGF0aDogXCIvaGVscGRlc2tcIixcclxuICAgICAgbmFtZTogXCJoZWxwZGVza1wiLFxyXG4gICAgICBjb21wb25lbnQ6ICgpID0+IGltcG9ydChcIi4uL3ZpZXdzL2NsaWVudC9oZWxwZGVzay52dWVcIiksXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwYXRoOiBcIi9GQVFcIixcclxuICAgICAgbmFtZTogXCJGQVFcIixcclxuICAgICAgY29tcG9uZW50OiAoKSA9PiBpbXBvcnQoXCIuLi92aWV3cy9jbGllbnQvRkFRLnZ1ZVwiKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHBhdGg6IFwiL2Jlc3RlbGxpbmdcIixcclxuICAgICAgbmFtZTogXCJiZXN0ZWxsaW5nXCIsXHJcbiAgICAgIGNvbXBvbmVudDogKCkgPT4gaW1wb3J0KFwiLi4vdmlld3MvY2xpZW50L2Jlc3RlbGxpbmcudnVlXCIpLFxyXG4gICAgfSxcclxuICAgIC8vYWRtaW5cclxuICAgIHtcclxuICAgICAgcGF0aDogXCIvYXR0cmFjdGllXCIsXHJcbiAgICAgIG5hbWU6IFwiYXR0cmFjdGllc1wiLFxyXG4gICAgICBjb21wb25lbnQ6ICgpID0+IGltcG9ydChcIi4uL3ZpZXdzL2FkbWluL2F0dHJhY3RpZS52dWVcIiksXHJcbiAgICAgIC8vIG1ldGE6IHsgc2hvdWxkQmVBdXRoZW50aWNhdGVkOiB0cnVlIH0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwYXRoOiBcIi9wZXJzb25lZWxcIixcclxuICAgICAgbmFtZTogXCJwZXJzb25lZWxcIixcclxuICAgICAgY29tcG9uZW50OiAoKSA9PiBpbXBvcnQoXCIuLi92aWV3cy9hZG1pbi9wZXJzb25lZWwudnVlXCIpLFxyXG4gICAgICBtZXRhOiB7IHNob3VsZEJlQXV0aGVudGljYXRlZDogdHJ1ZSB9LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcGF0aDogXCIvcmVzdGF1cmFudFwiLFxyXG4gICAgICBuYW1lOiBcInJlc3RhdXJhbnRzXCIsXHJcbiAgICAgIGNvbXBvbmVudDogKCkgPT4gaW1wb3J0KFwiLi4vdmlld3MvYWRtaW4vcmVzdGF1cmFudC52dWVcIiksXHJcbiAgICAgIC8vIG1ldGE6IHsgc2hvdWxkQmVBdXRoZW50aWNhdGVkOiB0cnVlIH0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwYXRoOiBcIi9zaG9wXCIsXHJcbiAgICAgIG5hbWU6IFwic2hvcFwiLFxyXG4gICAgICBjb21wb25lbnQ6ICgpID0+IGltcG9ydChcIi4uL3ZpZXdzL2FkbWluL3Nob3AudnVlXCIpLFxyXG4gICAgICBtZXRhOiB7IHNob3VsZEJlQXV0aGVudGljYXRlZDogdHJ1ZSB9LFxyXG4gICAgfSxcclxuICAgIC8vYXV0aGVudGlmaWNhdGlvblxyXG4gICAge1xyXG4gICAgICBwYXRoOiBcIi9hdXRoXCIsXHJcbiAgICAgIGNvbXBvbmVudDogKCkgPT4gaW1wb3J0KFwiLi4vY29tcG9uZW50cy93cmFwcGVycy9BdXRoV3JhcC52dWVcIiksXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwYXRoOiBcIi9hdXRoL2xvZ2luXCIsXHJcbiAgICAgIG5hbWU6IFwibG9naW5cIixcclxuICAgICAgY29tcG9uZW50OiAoKSA9PiBpbXBvcnQoXCIuLi92aWV3cy9hdXRoL2xvZ2luLnZ1ZVwiKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHBhdGg6IFwiL2F1dGgvcmVnaXN0ZXJcIixcclxuICAgICAgbmFtZTogXCJyZWdpc3RlclwiLFxyXG4gICAgICBjb21wb25lbnQ6ICgpID0+IGltcG9ydChcIi4uL3ZpZXdzL2F1dGgvcmVnaXN0ZXIudnVlXCIpLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcGF0aDogXCIvYXV0aC9mb3Jnb3QtcGFzc3dvcmRcIixcclxuICAgICAgbmFtZTogXCJmb3Jnb3RQYXNzd29yZFwiLFxyXG4gICAgICBjb21wb25lbnQ6ICgpID0+IGltcG9ydChcIi4uL3ZpZXdzL2F1dGgvZm9yZ290UGFzc3dvcmQudnVlXCIpLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcGF0aDogXCIvcHJvZmlsZVwiLFxyXG4gICAgICBuYW1lOiBcIkFjY291bnRcIixcclxuICAgICAgY29tcG9uZW50OiAoKSA9PiBpbXBvcnQoXCIuLi92aWV3cy9wcm9maWxlLnZ1ZVwiKSxcclxuICAgIH0sXHJcbiAgICAvLzQwNFxyXG4gICAge1xyXG4gICAgICBwYXRoOiBcIi86cGF0aE1hdGNoKC4qKSpcIixcclxuICAgICAgbmFtZTogXCJub3QtZm91bmRcIixcclxuICAgICAgY29tcG9uZW50OiAoKSA9PiBpbXBvcnQoXCIuLi92aWV3cy80MDRQYWdlLnZ1ZVwiKSxcclxuICAgIH0sXHJcbiAgXSxcclxufSlcclxuXHJcbnJvdXRlci5iZWZvcmVFYWNoKGFzeW5jICh0bywgZnJvbSwgbmV4dCkgPT4ge1xyXG4gIGNvbnN0IHsgZmlyZWJhc2VVc2VyIH0gPSB1c2VGaXJlYmFzZSgpXHJcblxyXG4gIGlmICh0by5tZXRhLnNob3VsZEJlQXV0aGVudGljYXRlZCAmJiAhZmlyZWJhc2VVc2VyLnZhbHVlKSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIkhBQ0tFUlwiKVxyXG4gICAgbmV4dCh7IHBhdGg6IFwiL2F1dGgvbG9naW5cIiB9KVxyXG4gIH0gZWxzZSB7XHJcbiAgICBuZXh0KClcclxuICB9XHJcbn0pXHJcblxyXG5leHBvcnQgZGVmYXVsdCByb3V0ZXJcclxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGNBQWMsd0JBQXdCO0FBRS9DLE9BQU8saUJBQWlCO0FBRXhCLE1BQU0sU0FBUyxhQUFhO0FBQUEsRUFDMUIsU0FBUyxpQkFBaUIsWUFBWSxJQUFJLFFBQVE7QUFBQSxFQUNsRCxRQUFRO0FBQUE7QUFBQSxJQUVOO0FBQUEsTUFDRSxNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixXQUFXLE1BQU0sT0FBTyxtQkFBbUI7QUFBQSxJQUM3QztBQUFBO0FBQUEsSUFFQTtBQUFBLE1BQ0UsTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sV0FBVyxNQUFNLE9BQU8sNEJBQTRCO0FBQUEsSUFDdEQ7QUFBQSxJQUNBO0FBQUEsTUFDRSxNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixXQUFXLE1BQU0sT0FBTywrQkFBK0I7QUFBQSxJQUN6RDtBQUFBLElBQ0E7QUFBQSxNQUNFLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLFdBQVcsTUFBTSxPQUFPLDhCQUE4QjtBQUFBLElBQ3hEO0FBQUEsSUFDQTtBQUFBLE1BQ0UsTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sV0FBVyxNQUFNLE9BQU8seUJBQXlCO0FBQUEsSUFDbkQ7QUFBQSxJQUNBO0FBQUEsTUFDRSxNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixXQUFXLE1BQU0sT0FBTyxnQ0FBZ0M7QUFBQSxJQUMxRDtBQUFBO0FBQUEsSUFFQTtBQUFBLE1BQ0UsTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sV0FBVyxNQUFNLE9BQU8sOEJBQThCO0FBQUE7QUFBQSxJQUV4RDtBQUFBLElBQ0E7QUFBQSxNQUNFLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLFdBQVcsTUFBTSxPQUFPLDhCQUE4QjtBQUFBLE1BQ3RELE1BQU0sRUFBRSx1QkFBdUIsS0FBSztBQUFBLElBQ3RDO0FBQUEsSUFDQTtBQUFBLE1BQ0UsTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sV0FBVyxNQUFNLE9BQU8sK0JBQStCO0FBQUE7QUFBQSxJQUV6RDtBQUFBLElBQ0E7QUFBQSxNQUNFLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLFdBQVcsTUFBTSxPQUFPLHlCQUF5QjtBQUFBLE1BQ2pELE1BQU0sRUFBRSx1QkFBdUIsS0FBSztBQUFBLElBQ3RDO0FBQUE7QUFBQSxJQUVBO0FBQUEsTUFDRSxNQUFNO0FBQUEsTUFDTixXQUFXLE1BQU0sT0FBTyxxQ0FBcUM7QUFBQSxJQUMvRDtBQUFBLElBQ0E7QUFBQSxNQUNFLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLFdBQVcsTUFBTSxPQUFPLHlCQUF5QjtBQUFBLElBQ25EO0FBQUEsSUFDQTtBQUFBLE1BQ0UsTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sV0FBVyxNQUFNLE9BQU8sNEJBQTRCO0FBQUEsSUFDdEQ7QUFBQSxJQUNBO0FBQUEsTUFDRSxNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixXQUFXLE1BQU0sT0FBTyxrQ0FBa0M7QUFBQSxJQUM1RDtBQUFBLElBQ0E7QUFBQSxNQUNFLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLFdBQVcsTUFBTSxPQUFPLHNCQUFzQjtBQUFBLElBQ2hEO0FBQUE7QUFBQSxJQUVBO0FBQUEsTUFDRSxNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixXQUFXLE1BQU0sT0FBTyxzQkFBc0I7QUFBQSxJQUNoRDtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBRUQsT0FBTyxXQUFXLE9BQU8sSUFBSSxNQUFNLFNBQVM7QUFDMUMsUUFBTSxFQUFFLGFBQWEsSUFBSSxZQUFZO0FBRXJDLE1BQUksR0FBRyxLQUFLLHlCQUF5QixDQUFDLGFBQWEsT0FBTztBQUN4RCxZQUFRLElBQUksUUFBUTtBQUNwQixTQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFBQSxFQUM5QixPQUFPO0FBQ0wsU0FBSztBQUFBLEVBQ1A7QUFDRixDQUFDO0FBRUQsZUFBZTsiLCJuYW1lcyI6W119